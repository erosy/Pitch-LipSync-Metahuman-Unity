using System;
using System.Collections.Generic;
using Unity.DemoTeam.Hair;
using UnityEngine;
using UnityEngine.Rendering;

/// <summary>Moves facial strand roots with the skinned, blendshaped face surface.</summary>
[DisallowMultipleComponent, DefaultExecutionOrder(1100)]
public sealed class FacialGroomSurfaceBinding : MonoBehaviour
{
    [Serializable]
    public struct RootBinding
    {
        public int a, b, c;
        public Vector3 barycentric;
        public Vector3 offset, direction, tangent;
    }

    [Serializable]
    public sealed class GroomBinding
    {
        public HairInstance groom;
        [HideInInspector] public RootBinding[] roots;
        [NonSerialized] internal MeshFilter filter;
        [NonSerialized] internal Mesh original, dynamic;
        [NonSerialized] internal Vector3[] positions, normals;
        [NonSerialized] internal Vector4[] tangents;
        [NonSerialized] internal HairInstance.SettingsExecutive.UpdateMode previousMode;
        [NonSerialized] internal ComputeBuffer frames;
        [NonSerialized] internal SurfaceFrame[] frameData;
    }

    internal struct SurfaceFrame { public Vector4 position, rotation; }

    [SerializeField] SkinnedMeshRenderer face;
    [SerializeField] Mesh referenceMesh;
    [SerializeField] GroomBinding[] grooms = Array.Empty<GroomBinding>();
    [SerializeField] ComputeShader kinematics;
    Mesh baked;
    bool ownsScheduling;
    readonly List<Vector3> vertices = new List<Vector3>();

    public static bool TryFrame(Vector3 a, Vector3 b, Vector3 c, out Quaternion rotation)
    {
        Vector3 edge = b - a, normal = Vector3.Cross(edge, c - a);
        if (edge.sqrMagnitude < 1e-16f || normal.sqrMagnitude < 1e-20f)
        { rotation = Quaternion.identity; return false; }
        normal.Normalize(); edge.Normalize();
        rotation = Quaternion.LookRotation(normal, Vector3.Cross(normal, edge));
        return true;
    }

#if UNITY_EDITOR
    // Authoring only; runtime never searches for nearest triangles.
    public void Configure(SkinnedMeshRenderer renderer, GroomBinding[] bindings, ComputeShader shader)
    { face = renderer; referenceMesh = renderer.sharedMesh; grooms = bindings; kinematics = shader; }
#endif

    void OnEnable()
    {
        if (!Application.IsPlaying(gameObject)) return;
        if (!SystemInfo.supportsComputeShaders) return;
        if (!face || face.sharedMesh != referenceMesh || grooms == null || !kinematics)
        { Debug.LogError("Facial groom binding must be rebuilt for the assigned face mesh.", this); return; }
        foreach (var binding in grooms)
        {
            if (!binding.groom) continue;
            binding.previousMode = binding.groom.settingsExecutive.updateMode;
            // Dispatch once after ExpressionModule's LateUpdate, rather than
            // allowing the hair package to read last frame's facial roots.
            binding.groom.settingsExecutive.updateMode = HairInstance.SettingsExecutive.UpdateMode.ExternalCall;
        }
        ownsScheduling = true;
        baked = new Mesh { name = "Facial groom surface sample", hideFlags = HideFlags.DontSave };
        baked.MarkDynamic();
    }

    bool Prepare(GroomBinding binding)
    {
        var instances = binding.groom.strandGroupInstances;
        if (instances == null || instances.Length != 1) return false;
        var filter = instances[0].sceneObjects.rootMeshFilter;
        if (!filter || !filter.sharedMesh || filter.sharedMesh.vertexCount != binding.roots.Length) return false;
        if (filter == binding.filter && filter.sharedMesh == binding.dynamic) return true;
        ReleaseMesh(binding);
        binding.filter = filter; binding.original = filter.sharedMesh;
        binding.dynamic = Instantiate(binding.original);
        binding.dynamic.name = binding.groom.name + " surface-bound roots";
        binding.dynamic.hideFlags = HideFlags.DontSave;
        binding.dynamic.MarkDynamic();
        binding.positions = binding.dynamic.vertices;
        binding.normals = binding.dynamic.normals;
        binding.tangents = binding.dynamic.tangents;
        binding.frames = new ComputeBuffer(binding.roots.Length, 32);
        binding.frameData = new SurfaceFrame[binding.roots.Length];
        filter.sharedMesh = binding.dynamic;
        return true;
    }

    void LateUpdate()
    {
        if (!Application.IsPlaying(gameObject) || !baked || !face || face.sharedMesh != referenceMesh) return;
        bool any = false;
        foreach (var binding in grooms)
            if (binding.groom && binding.groom.isActiveAndEnabled) { any = true; break; }
        if (!any) return;
        face.BakeMesh(baked, false);
        baked.GetVertices(vertices);
        foreach (var binding in grooms)
        {
            if (!binding.groom || !binding.groom.isActiveAndEnabled || !Prepare(binding)) continue;
            Matrix4x4 conversion = binding.filter.transform.worldToLocalMatrix * face.transform.localToWorldMatrix;
            for (int i = 0; i < binding.roots.Length; i++)
            {
                var root = binding.roots[i];
                if ((uint)root.a >= vertices.Count || (uint)root.b >= vertices.Count || (uint)root.c >= vertices.Count) continue;
                Vector3 a = vertices[root.a], b = vertices[root.b], c = vertices[root.c];
                if (!TryFrame(a, b, c, out var frame)) continue;
                Vector3 position = a * root.barycentric.x + b * root.barycentric.y + c * root.barycentric.z + frame * root.offset;
                Vector3 normal = conversion.MultiplyVector(frame * root.direction).normalized;
                Vector3 tangent = conversion.MultiplyVector(frame * root.tangent);
                tangent = (tangent - normal * Vector3.Dot(tangent, normal)).normalized;
                binding.positions[i] = conversion.MultiplyPoint3x4(position);
                binding.normals[i] = normal;
                binding.tangents[i] = new Vector4(tangent.x, tangent.y, tangent.z, 1);
                Vector3 worldPosition = binding.filter.transform.TransformPoint(binding.positions[i]);
                Vector3 worldDirection = binding.filter.transform.TransformDirection(normal);
                Vector3 worldTangent = binding.filter.transform.TransformDirection(tangent);
                Quaternion worldFrame = Quaternion.LookRotation(Vector3.Cross(worldTangent, worldDirection), worldDirection);
                binding.frameData[i] = new SurfaceFrame {
                    position = new Vector4(worldPosition.x, worldPosition.y, worldPosition.z, 1),
                    rotation = new Vector4(worldFrame.x, worldFrame.y, worldFrame.z, worldFrame.w) };
            }
            // Preserve the hair package's three-stream root mesh layout.
            const MeshUpdateFlags flags = MeshUpdateFlags.DontRecalculateBounds;
            binding.dynamic.SetVertexBufferData(binding.positions, 0, 0, binding.positions.Length, 0, flags);
            binding.dynamic.SetVertexBufferData(binding.normals, 0, 0, binding.normals.Length, 1, flags);
            binding.dynamic.SetVertexBufferData(binding.tangents, 0, 0, binding.tangents.Length, 2, flags);
            binding.dynamic.RecalculateBounds();
            UpdateKinematicStrands(binding);
        }
    }

    void UpdateKinematicStrands(GroomBinding binding)
    {
        // Facial hairs follow their rest curves rigidly at each surface root.
        // Updating roots alone is insufficient when hair simulation is disabled:
        // update particle positions explicitly, without enabling gravity/physics.
        var hair = binding.groom;
        var cmd = CommandBufferPool.Get("Facial groom surface kinematics");
        try
        {
            if (hair.solverData == null || hair.solverData.Length != 1)
                if (!hair.DispatchUpdate(cmd, CommandBufferExecutionFlags.None, 0)) return;
            ref var solver = ref hair.solverData[0];
            int count = (int)solver.constants._StrandCount * (int)solver.constants._StrandParticleCount;
            int kernel = kinematics.FindKernel("FollowSurface");
            cmd.SetBufferData(binding.frames, binding.frameData);
            cmd.SetComputeIntParam(kinematics, "ParticleCount", count);
            cmd.SetComputeIntParam(kinematics, "StrandCount", (int)solver.constants._StrandCount);
            cmd.SetComputeIntParam(kinematics, "ParticlesPerStrand", (int)solver.constants._StrandParticleCount);
            cmd.SetComputeIntParam(kinematics, "Interleaved", hair.strandGroupProviders[0].hairAsset.strandGroups[0].particleMemoryLayout == HairAsset.MemoryLayout.Interleaved ? 1 : 0);
            cmd.SetComputeFloatParam(kinematics, "GroupScale", solver.constants._GroupScale);
            cmd.SetComputeBufferParam(kinematics, kernel, "SurfaceFrames", binding.frames);
            cmd.SetComputeBufferParam(kinematics, kernel, "InitialOffsets", solver.buffers._InitialParticleOffset);
            cmd.SetComputeBufferParam(kinematics, kernel, "Positions", solver.buffers._ParticlePosition);
            cmd.SetComputeBufferParam(kinematics, kernel, "PreviousPositions", solver.buffers._ParticlePositionPrev);
            cmd.DispatchCompute(kinematics, kernel, (count + 63) / 64, 1, 1);
            hair.DispatchUpdate(cmd, CommandBufferExecutionFlags.None, 0);
            Graphics.ExecuteCommandBuffer(cmd);
        }
        finally { CommandBufferPool.Release(cmd); }
    }

    static void ReleaseMesh(GroomBinding binding)
    {
        if (binding.filter && binding.filter.sharedMesh == binding.dynamic) binding.filter.sharedMesh = binding.original;
        if (binding.dynamic) Destroy(binding.dynamic);
        binding.dynamic = null; binding.original = null; binding.filter = null;
        binding.positions = null; binding.normals = null; binding.tangents = null;
        binding.frames?.Release(); binding.frames = null; binding.frameData = null;
    }

    void OnDisable()
    {
        if (grooms != null)
            foreach (var binding in grooms)
            {
                ReleaseMesh(binding);
                if (ownsScheduling && binding.groom && Application.IsPlaying(gameObject) && binding.groom.settingsExecutive.updateMode == HairInstance.SettingsExecutive.UpdateMode.ExternalCall)
                    binding.groom.settingsExecutive.updateMode = binding.previousMode;
            }
        if (baked) Destroy(baked);
        baked = null;
        ownsScheduling = false;
    }
}
