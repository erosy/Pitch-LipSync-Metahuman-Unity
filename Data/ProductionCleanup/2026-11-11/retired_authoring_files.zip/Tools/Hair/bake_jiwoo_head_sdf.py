"""Bake a closed, head-local collision SDF from the current Unity head mesh.
Run with Blender --background --factory-startup --disable-autoexec.
Only writes derived files under Data; never modifies character geometry.
"""
import bpy, bmesh, numpy as np, json
from pathlib import Path
from mathutils.bvhtree import BVHTree
from mathutils import Vector
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'Data/JiwooRigged/ScalpBoundaryRepair'
p=np.fromfile(OUT/'head_vertices.bin',dtype='<f4').reshape(-1,3)
tri=np.fromfile(OUT/'head_triangles.bin',dtype='<i4').reshape(-1,3)
indices,remap=np.unique(tri,return_inverse=True);p=p[indices];tri=remap.reshape(-1,3)
mesh=bpy.data.meshes.new('CollisionOnly');mesh.from_pydata(p.tolist(),[],tri.tolist());mesh.update()
bm=bmesh.new();bm.from_mesh(mesh)
bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=1e-6)
edges=[e for e in bm.edges if e.is_boundary]
filled=bmesh.ops.holes_fill(bm,edges=edges,sides=0)
bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces))
if bm.calc_volume(signed=True)<0:bmesh.ops.reverse_faces(bm,faces=list(bm.faces))
assert not any(e.is_boundary for e in bm.edges),'Head collision proxy must be closed'
bm.verts.ensure_lookup_table();bm.verts.index_update()
verts=np.array([v.co[:] for v in bm.verts]);faces=[[v.index for v in f.verts] for f in bm.faces]
bvh=BVHTree.FromPolygons(verts.tolist(),faces)
n=96;lo=verts.min(0)-.035;hi=verts.max(0)+.035;size=hi-lo
config=dict(resolution=n,center=((hi+lo)*.5).tolist(),size=size.tolist(),minimum=lo.tolist(),maximum=hi.tolist(),voxel_size_m=(size/n).tolist())
(OUT/'sdf_config.json').write_text(json.dumps(config,indent=2))
# X is the fastest axis, matching Unity Texture3D.SetPixelData.
field=np.empty((n,n,n),np.float32)
for z in range(n):
    for y in range(n):
        base=lo+(np.array([0,y,z])+.5)*size/n
        origin=Vector((lo[0]-.01,base[1],base[2]));hits=[]
        for _ in range(128):
            hit,normal,index,distance=bvh.ray_cast(origin,Vector((1,0,0)))
            if hit is None:break
            hits.append(hit.x);origin=hit+Vector((1e-6,0,0))
        for x in range(n):
            point=lo+(np.array([x,y,z])+.5)*size/n
            distance=bvh.find_nearest(point)[3]
            field[z,y,x]=-distance if sum(h>point[0] for h in hits)%2 else distance
    if z%24==0:print('SDF slice',z,flush=True)
field.tofile(OUT/'head_sdf.f32')
roots=np.fromfile(OUT/'roots.bin',dtype='<f4').reshape(-1,3)
def sample(points):
    q=np.clip((points-lo)/size*n-.5,0,n-1.000001)
    a=np.floor(q).astype(int);b=a+1;f=q-a
    out=np.zeros(len(q))
    for dz in (0,1):
        for dy in (0,1):
            for dx in (0,1):
                ix=b[:,0] if dx else a[:,0];iy=b[:,1] if dy else a[:,1];iz=b[:,2] if dz else a[:,2]
                weight=(f[:,0] if dx else 1-f[:,0])*(f[:,1] if dy else 1-f[:,1])*(f[:,2] if dz else 1-f[:,2])
                out+=field[iz,iy,ix]*weight
    return out
root_values=sample(roots)
probe=roots[np.linspace(0,len(roots)-1,4096,dtype=int)]
normals=np.array([bvh.find_nearest(p)[1] for p in probe])
outside=sample(probe+normals*.006);inside=sample(probe-normals*.006)
border=np.concatenate([field[0].ravel(),field[-1].ravel(),field[:,0].ravel(),field[:,-1].ravel(),field[:,:,0].ravel(),field[:,:,-1].ravel()])
# Quantify the gap left by the former capsule against these exact scalp roots.
head=np.array(json.loads((OUT/'before.json').read_text())['headPosition']);old=roots+head-[0,1.655,-.005]
old[:,1]-=np.clip(old[:,1],-.022,.022);oldgap=np.linalg.norm(old,axis=1)-.073
result=dict(passed=bool(np.max(np.abs(root_values))<.002 and np.all(outside>0) and np.all(inside<0) and border.min()>0),
    resolution=n,closed_proxy_vertices=len(verts),closed_proxy_faces=len(faces),filled_holes=len(filled['faces']),
    root_sdf_percentiles_m=np.percentile(root_values,[0,50,95,100]).tolist(),root_max_abs_sdf_m=float(np.abs(root_values).max()),
    outside_6mm_min_m=float(outside.min()),inside_6mm_max_m=float(inside.max()),positive_border_min_m=float(border.min()),
    old_capsule_gap_percentiles_m=np.percentile(oldgap,[0,50,95,100]).tolist(),probe_count=len(probe),
    format='RFloat',byte_count=field.nbytes)
(OUT/'sdf_verification.json').write_text(json.dumps(result,indent=2))
# Actual probe locations and expected distances also exercise Unity's sampling/frame.
(OUT/'unity_probes.json').write_text(json.dumps([dict(point=p.tolist(),expected=float(v)) for p,v in zip(np.r_[probe[:64],probe[:64]+normals[:64]*.006,probe[:64]-normals[:64]*.006],np.r_[sample(probe[:64]),outside[:64],inside[:64]])]))
print(json.dumps(result),flush=True)
assert result['passed'],result
