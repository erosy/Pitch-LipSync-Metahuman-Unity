"""Endpoint-preserving 32-point variant of the verified scalp curve data."""
import bpy, numpy as np, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'Data/JiwooRigged/HairOptimization32'
target=ROOT/'Assets/_Sandbox/Characters/Jiwoo New/Groom/Jiwoo_Scalp_32_HeadLocal.abc'
assert not target.exists(),'Do not overwrite reviewed Alembic'
old=np.load(ROOT/'Data/JiwooRigged/Batch02/Scalp_head_local.npy')
new=np.empty((len(old),32,3),np.float32)
for i,c in enumerate(old):
    cumulative=np.r_[0,np.cumsum(np.linalg.norm(np.diff(c,axis=0),axis=1))]
    new[i]=np.column_stack([np.interp(np.linspace(0,cumulative[-1],32),cumulative,c[:,j]) for j in range(3)])
    new[i,0]=c[0];new[i,-1]=c[-1]
abc=new.reshape(-1,3)[:,[0,2,1]].copy();abc[:,0]*=-1
curves=bpy.data.hair_curves.new('Jiwoo_Scalp_32');curves.add_curves([32]*len(new));curves.attributes['position'].data.foreach_set('vector',abc.ravel());curves.set_types(type='POLY')
radius=curves.attributes.new('radius','FLOAT','POINT');radius.data.foreach_set('value',np.full(len(abc),.00005,np.float32))
obj=bpy.data.objects.new('Jiwoo_Scalp_32_HeadLocal',curves);bpy.context.scene.collection.objects.link(obj);obj.select_set(True);bpy.context.view_layer.objects.active=obj
bpy.ops.wm.alembic_export(filepath=str(target),start=1,end=1,selected=True,flatten=True,global_scale=1,curves_as_mesh=False,export_hair=True,export_particles=False,as_background_job=False,init_scene_frame_range=False)
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.wm.alembic_import(filepath=str(target),scale=1,set_frame_range=False,as_background_job=False);bpy.context.view_layer.update()
o=next(o for o in bpy.data.objects if o.type=='CURVES');d=o.evaluated_get(bpy.context.evaluated_depsgraph_get()).data
actual=np.empty(len(d.points)*3,np.float32);d.attributes['position'].data.foreach_get('vector',actual);actual=actual.reshape(-1,3)
error=float(np.linalg.norm(actual-abc,axis=1).max());assert error<1e-7 and len(d.curves)==len(new)
(OUT/'alembic_readback.json').write_text(json.dumps(dict(passed=True,strands=len(new),points=32,max_error_m=error,roots_preserved=bool(np.array_equal(new[:,0],old[:,0])),tips_preserved=bool(np.array_equal(new[:,-1],old[:,-1]))),indent=2))
print('SCALP32_VERIFIED',len(new),error,flush=True)
