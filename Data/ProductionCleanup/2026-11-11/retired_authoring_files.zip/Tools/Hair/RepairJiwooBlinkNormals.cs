using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using Newtonsoft.Json;

public static class RepairJiwooBlinkNormals
{
    const string Model="Assets/_Sandbox/Characters/Jiwoo New/Jiwoo_EthanSetup.fbx";
    const string Output="Data/JiwooRigged/BlinkAudit";
    public static object ImportAuthored()
    {
        if(EditorApplication.isPlayingOrWillChangePlaymode)throw new Exception("Edit Mode required; user controls Play Mode.");
        Directory.CreateDirectory(Output+"/Before");
        if(!File.Exists(Output+"/Before/Jiwoo_EthanSetup.fbx.meta"))File.Copy(Model+".meta",Output+"/Before/Jiwoo_EthanSetup.fbx.meta");
        var importer=(ModelImporter)AssetImporter.GetAtPath(Model);
        var previous=importer.importBlendShapeNormals;
        importer.importBlendShapeNormals=ModelImporterNormals.Import;
        importer.SaveAndReimport();
        var result=new {previous=previous.ToString(),current=importer.importBlendShapeNormals.ToString(),baseNormals=importer.importNormals.ToString()};
        File.WriteAllText(Output+"/normal_import_change.json",JsonConvert.SerializeObject(result,Formatting.Indented));
        return result;
    }
}
