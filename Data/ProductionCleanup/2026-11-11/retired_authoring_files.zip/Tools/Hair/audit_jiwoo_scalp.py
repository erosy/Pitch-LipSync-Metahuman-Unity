"""Read-only current-source/old-groom comparison. Run in Blender background."""
import bpy, numpy as np, json, hashlib
from pathlib import Path
from mathutils.bvhtree import BVHTree
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'Data/JiwooRigged/ScalpRestore'
OUT.mkdir(parents=True,exist_ok=True)
SOURCE=ROOT/'Data/JiwooRigged/ClothingWeightRepair/Jiwoo_EthanSetup_WeightsFixed.blend'
def arr(data,field='co'):
    a=np.empty(len(data)*3,np.float32);data.foreach_get(field,a);return a.reshape(-1,3)
def world(p,m):
    m=np.array(m);return p@m[:3,:3].T+m[:3,3]
def bounds(p):return [p.min(axis=0).tolist(),p.max(axis=0).tolist()]
bpy.ops.wm.open_mainfile(filepath=str(SOURCE))
rig=bpy.data.objects['Jiwoo_Armature']
head=rig.matrix_world@rig.data.bones['DEF-spine.006'].matrix_local
(OUT/'source_bones.json').write_text(json.dumps({b.name:list(rig.matrix_world@b.head_local) for b in rig.data.bones},indent=2))
scalp=bpy.data.objects['Jiwoo_ScalpGroom']
bpy.context.view_layer.update()
ev=scalp.evaluated_get(bpy.context.evaluated_depsgraph_get());d=ev.data
p=world(world(arr(d.attributes['position'].data,'vector'),ev.matrix_world),head.inverted())
offsets=[c.first_point_index for c in d.curves]+[len(d.points)]
samples=[]
for a,b in zip(offsets[:-1],offsets[1:]):
    c=p[a:b];dist=np.r_[0,np.cumsum(np.linalg.norm(np.diff(c,axis=0),axis=1))]
    assert dist[-1]>0
    samples.append(np.column_stack([np.interp(np.linspace(0,dist[-1],64),dist,c[:,j]) for j in range(3)]))
samples=np.array(samples,dtype=np.float32)
old=np.load(ROOT/'Data/JiwooRigged/Batch02/Scalp_head_local.npy')
face=bpy.data.objects['Face'];fp=world(world(arr(face.data.vertices),face.matrix_world),head.inverted())
bvh=BVHTree.FromPolygons(fp.tolist(),[list(p.vertices) for p in face.data.polygons])
rootdist=np.array([bvh.find_nearest(p)[3] for p in samples[:,0]])
tipdist=np.array([bvh.find_nearest(p)[3] for p in samples[:,-1]])
error=float(np.linalg.norm(samples-old,axis=2).max()) if samples.shape==old.shape else None
np.save(OUT/'current_scalp_head_local.npy',samples)
# Verify the actual old ABC independently, rather than trusting its baseline.
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.wm.alembic_import(filepath=str(ROOT/'Assets/_Sandbox/Characters/Jiwoo/Groom/Rigged/Jiwoo_Scalp_HeadLocal.abc'),scale=1,set_frame_range=False,as_background_job=False)
bpy.context.view_layer.update()
abc=next(o for o in bpy.data.objects if o.type=='CURVES');ad=abc.evaluated_get(bpy.context.evaluated_depsgraph_get()).data
actual=arr(ad.attributes['position'].data,'vector')
expected=old.reshape(-1,3)[:,[0,2,1]].copy();expected[:,0]*=-1
abc_error=float(np.linalg.norm(actual-expected,axis=1).max())
width=np.empty(len(ad.points),np.float32);ad.attributes['radius'].data.foreach_get('value',width);width*=2
report=dict(source=str(SOURCE.relative_to(ROOT)),source_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),strands=len(samples),points_per_strand=64,
 head_matrix_blender=np.array(head).tolist(),current_bounds=bounds(samples.reshape(-1,3)),old_bounds=bounds(old.reshape(-1,3)),
 max_current_vs_old_m=error,abc_readback_max_error_m=abc_error,width_min_m=float(width.min()),width_max_m=float(width.max()),
 root_surface_distance_percentiles_m=np.percentile(rootdist,[0,50,95,100]).tolist(),tip_surface_distance_median_m=float(np.median(tipdist)),
 roots_nearer_than_tips_fraction=float(np.mean(rootdist<tipdist)),
 reuse_passed=bool(error is not None and error<2e-5 and abc_error<2e-6 and width.min()>0 and np.percentile(rootdist,95)<.006))
(OUT/'blender_fit.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report),flush=True)
