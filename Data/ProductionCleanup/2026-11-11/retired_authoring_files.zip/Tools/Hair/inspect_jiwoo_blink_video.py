"""Extract review frames from the user-provided recording, without editing it."""
import json
from pathlib import Path
import cv2
from PIL import Image,ImageDraw
source=Path(r'C:\Users\ina17\Videos\Captures\MetahumanTemplate - CharacterTesting - Windows, Mac, Linux - Unity 6.5 (6000.5.9f1)_ _DX12_ 2026-11-09 16-37-17.mp4')
out=Path(__file__).resolve().parents[2]/'Data/JiwooRigged/BlinkAudit'
out.mkdir(exist_ok=True)
c=cv2.VideoCapture(str(source))
n=c.get(cv2.CAP_PROP_FRAME_COUNT);fps=c.get(cv2.CAP_PROP_FPS);duration=n/fps
metadata={'frames':n,'fps':fps,'seconds':duration,'width':c.get(3),'height':c.get(4)}
print(json.dumps(metadata))
(out/'video_metadata.json').write_text(json.dumps(metadata,indent=2))
sheet=Image.new('RGB',(1280,1040),(30,30,30));draw=ImageDraw.Draw(sheet)
for i in range(12):
    t=duration*i/12;c.set(cv2.CAP_PROP_POS_MSEC,t*1000);ok,f=c.read()
    if not ok:continue
    cv2.imwrite(str(out/f'frame_{i:02d}.png'),f)
    im=Image.fromarray(cv2.cvtColor(f,cv2.COLOR_BGR2RGB));im.thumbnail((426,240))
    sheet.paste(im,((i%3)*426,(i//3)*260))
    draw.text(((i%3)*426+5,(i//3)*260+240),f'{t:.2f} s',fill='white')
sheet.save(out/'contact_sheet.jpg');c.release()
