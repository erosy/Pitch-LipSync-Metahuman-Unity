using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public static class AssignJiwooNewMaterials
{
    public static object Main()
    {
        if (EditorApplication.isPlayingOrWillChangePlaymode)
            throw new Exception("Edit Mode required; Play Mode remains under user control.");
        const string folder = "Assets/_Sandbox/Characters/Jiwoo New";
        const string path = folder + "/Jiwoo_EthanSetup.fbx";
        const string existing = "Assets/_Sandbox/Characters/Jiwoo/Materials/";
        const string hairPath = folder + "/Materials/Jiwoo_FacialHair_Mesh.mat";
        var importer = AssetImporter.GetAtPath(path) as ModelImporter;
        if (!importer) throw new Exception("New Jiwoo FBX not found.");
        var mapping = new Dictionary<string,string>
        {
            ["MI_WI_SleevelessTurtleneck_SleevelessTurtleneck"] = existing + "Jiwoo_Outfit.mat",
            ["Jiwoo_MetaHumanCharacter_body_shader"] = existing + "Jiwoo_Body.mat",
            ["Jiwoo_MetaHumanCharacter_head_shader"] = existing + "Jiwoo_Head.mat",
            ["Jiwoo_MetaHumanCharacter_teeth_shader"] = existing + "Jiwoo_Teeth.mat",
            ["Jiwoo_MetaHumanCharacter_saliva_shader"] = existing + "Jiwoo_Saliva.mat",
            ["Jiwoo_MetaHumanCharacter_eyeLeft_shader"] = existing + "Jiwoo_Eyes.mat",
            ["Jiwoo_MetaHumanCharacter_eyeRight_shader"] = existing + "Jiwoo_Eyes.mat",
            ["Jiwoo_MetaHumanCharacter_eyeshell_shader"] = existing + "Jiwoo_EyeShell.mat",
            ["Jiwoo_MetaHumanCharacter_eyeEdge_shader"] = existing + "Jiwoo_EyeEdge.mat",
            ["Jiwoo_MetaHumanCharacter_cartilage_shader"] = existing + "Jiwoo_Cartilage.mat",
            ["Jiwoo_FacialHair_Mesh"] = hairPath
        };
        var model = AssetDatabase.LoadAssetAtPath<GameObject>(path);
        var originalNames = model.GetComponentsInChildren<Renderer>(true)
            .SelectMany(r => r.sharedMaterials).Select(m => m ? m.name : "<null>").Distinct().ToArray();
        if (originalNames.Any(n => !mapping.ContainsKey(n)))
            throw new Exception("Unexpected material names: " + string.Join(", ", originalNames));
        foreach (var entry in mapping.Where(p => p.Value != hairPath))
            if (!AssetDatabase.LoadAssetAtPath<Material>(entry.Value))
                throw new Exception("Missing material: " + entry.Value);
        var shader = Shader.Find("Universal Render Pipeline/Lit");
        if (!shader || !shader.isSupported) throw new Exception("URP Lit shader unavailable.");
        Directory.CreateDirectory("Data/JiwooRigged/EthanReference");
        const string backup = "Data/JiwooRigged/EthanReference/material_remap_before.meta";
        if (!File.Exists(backup)) File.Copy(path + ".meta", backup);
        if (!AssetDatabase.IsValidFolder(folder + "/Materials"))
            AssetDatabase.CreateFolder(folder, "Materials");
        var hair = AssetDatabase.LoadAssetAtPath<Material>(hairPath);
        if (!hair)
        {
            hair = new Material(shader) { name = "Jiwoo_FacialHair_Mesh" };
            hair.SetColor("_BaseColor", new Color(.025f, .012f, .008f, 1));
            hair.SetFloat("_Metallic", 0);
            hair.SetFloat("_Smoothness", .35f);
            hair.SetFloat("_Cull", 0);
            hair.enableInstancing = true;
            AssetDatabase.CreateAsset(hair, hairPath);
        }
        foreach (var entry in mapping)
            importer.AddRemap(new AssetImporter.SourceAssetIdentifier(typeof(Material), entry.Key),
                AssetDatabase.LoadAssetAtPath<Material>(entry.Value));
        importer.materialImportMode = ModelImporterMaterialImportMode.ImportStandard;
        AssetDatabase.SaveAssets();
        importer.SaveAndReimport();
        importer = (ModelImporter)AssetImporter.GetAtPath(path);
        var remaps = importer.GetExternalObjectMap();
        foreach (var entry in mapping)
        {
            var key = new AssetImporter.SourceAssetIdentifier(typeof(Material), entry.Key);
            if (!remaps.TryGetValue(key, out var actual) || actual != AssetDatabase.LoadAssetAtPath<Material>(entry.Value))
                throw new Exception("Remap did not persist: " + entry.Key);
        }
        model = AssetDatabase.LoadAssetAtPath<GameObject>(path);
        var slots = model.GetComponentsInChildren<Renderer>(true).Select(r => new {
            renderer = r.name,
            materials = r.sharedMaterials.Select(m => m ? AssetDatabase.GetAssetPath(m) : "<null>").ToArray()
        }).ToArray();
        if (model.GetComponentsInChildren<Renderer>(true).SelectMany(r => r.sharedMaterials)
            .Any(m => !m || !m.shader || !m.shader.isSupported))
            throw new Exception("A material slot or shader is invalid after import.");
        Selection.activeObject = model;
        EditorGUIUtility.PingObject(model);
        var result = new { passed = true, model = path, remapped = mapping.Count, slots };
        File.WriteAllText("Data/JiwooRigged/EthanReference/material_remap_report.json",
            Newtonsoft.Json.JsonConvert.SerializeObject(result, Newtonsoft.Json.Formatting.Indented));
        return result;
    }
}
