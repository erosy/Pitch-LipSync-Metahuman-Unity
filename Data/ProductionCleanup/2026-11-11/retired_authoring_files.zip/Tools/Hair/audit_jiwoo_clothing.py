"""Read-only clothing/rig audit. Never saves Blender files or poses animation."""
import json
from collections import defaultdict, Counter
from pathlib import Path
import bpy
import numpy as np
from mathutils.kdtree import KDTree
from mathutils.bvhtree import BVHTree
from mathutils import Vector

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'Data/JiwooRigged/ClothingAudit'
OUT.mkdir(exist_ok=True)

def points(obj):
    ev=obj.evaluated_get(bpy.context.evaluated_depsgraph_get())
    mesh=ev.to_mesh()
    try:return np.array([obj.matrix_world@v.co for v in mesh.vertices])
    finally:ev.to_mesh_clear()

def weights(obj):
    result=[]
    for vertex in obj.data.vertices:
        w={obj.vertex_groups[g.group].name:g.weight for g in vertex.groups
           if obj.vertex_groups[g.group].name.startswith('DEF-') and g.weight>1e-6}
        total=sum(w.values())
        result.append({k:v/total for k,v in w.items()} if total else {})
    return result

def l1(a,b):return sum(abs(a.get(k,0)-b.get(k,0)) for k in a.keys()|b.keys())

original=bpy.data.objects.get('Jiwoo_MetaHumanCharacter_Outfits')
if original is None:original=bpy.data.objects['Outfit']
cloth=original
cp=points(cloth);cw=weights(cloth)
edges=Counter()
neighbors=defaultdict(set)
for poly in cloth.data.polygons:
    v=list(poly.vertices)
    for a,b in zip(v,v[1:]+v[:1]):
        edges[tuple(sorted((a,b)))]+=1
        neighbors[a].add(b);neighbors[b].add(a)
boundary={v for edge,n in edges.items() if n==1 for v in edge}
tree=KDTree(len(cp))
for i,p in enumerate(cp):tree.insert(p,i)
tree.balance()
near=[]
for i in boundary:
    for _,j,d in tree.find_range(cp[i],.0001):
        if j<=i or j not in boundary:continue
        mismatch=l1(cw[i],cw[j])
        near.append({'a':i,'b':j,'gap_m':d,'weight_l1':mismatch,'position':cp[i].tolist(),
                     'a_weights':cw[i],'b_weights':cw[j]})
seen=set();components=[]
for i in range(len(cp)):
    if i in seen:continue
    stack=[i];seen.add(i);component=[]
    while stack:
        a=stack.pop();component.append(a)
        for b in neighbors[a]:
            if b not in seen:seen.add(b);stack.append(b)
    p=cp[component]
    components.append({'vertices':len(component),'bounds':[p.min(0).tolist(),p.max(0).tolist()]})
rig=bpy.data.objects.get('rig')
rigify={'rig_present':rig is not None,'rig_id':rig.data.get('rig_id') if rig else None,
        'rigify_control_bones':sum(b.name.startswith(('ORG-','MCH-','DEF-')) for b in rig.data.bones) if rig else 0,
        'rig_ui_text_present':'rig_ui.py' in bpy.data.texts,
        'metarigs':[o.name for o in bpy.data.objects if o.type=='ARMATURE' and any(b.get('rigify_type') for b in o.pose.bones)]}
used=defaultdict(lambda:{'vertices':0,'sum_weight':0.})
for w in cw:
    for name,value in w.items():used[name]['vertices']+=1;used[name]['sum_weight']+=value
result={'file':bpy.data.filepath,'rigify':rigify,
        'clothing':{'name':cloth.name,'vertices':len(cp),'faces':len(cloth.data.polygons),
            'modifiers':[{'name':m.name,'type':m.type,'armature':m.object.name if m.type=='ARMATURE' and m.object else None,
                'preserve_volume':m.use_deform_preserve_volume if m.type=='ARMATURE' else None} for m in cloth.modifiers],
            'boundary_edges':sum(v==1 for v in edges.values()),'nonmanifold_edges':sum(v>2 for v in edges.values()),
            'components':sorted(components,key=lambda x:-x['vertices']),
            'near_coincident_boundary_pairs':len(near),'mismatched_seam_pairs':sum(p['weight_l1']>.01 for p in near),
            'worst_seams':sorted(near,key=lambda p:-p['weight_l1'])[:25],
            'influence_count_max':max(map(len,cw)),
            'bones':dict(sorted(used.items(),key=lambda item:-item[1]['sum_weight']))}}
skin_objects=[bpy.data.objects[n] for n in ['Jiwoo_MetaHumanCharacter_body_lod0_mesh','Jiwoo_MetaHumanCharacter_head_lod0_mesh'] if n in bpy.data.objects]
if skin_objects:
    skin_points=[];skin_weights=[];triangles=[]
    for skin in skin_objects:
        offset=len(skin_points);skin_points.extend(points(skin));skin_weights.extend(weights(skin))
        skin.data.calc_loop_triangles()
        triangles.extend([tuple(offset+i for i in tri.vertices) for tri in skin.data.loop_triangles])
    sp=np.array(skin_points)
    bvh=BVHTree.FromPolygons(sp.tolist(),triangles,all_triangles=True)
    samples=[]
    for i,p in enumerate(cp):
        closest,normal,index,gap=bvh.find_nearest(Vector(p))
        ids=triangles[index];a,b,c=sp[list(ids)]
        vw=np.linalg.lstsq(np.column_stack((b-a,c-a)),np.array(closest)-a,rcond=None)[0]
        bary=[1-sum(vw),*vw];sw=defaultdict(float)
        for vertex,factor in zip(ids,bary):
            for k,w in skin_weights[vertex].items():sw[k]+=factor*w
        samples.append({'vertex':i,'gap_m':gap,'weight_l1':l1(cw[i],sw),'position':p.tolist(),
                        'cloth_weights':cw[i],'body_weights':dict(sw),
                        'signed_gap_m':float((Vector(p)-closest).dot(normal))})
    gaps=np.array([s['gap_m'] for s in samples]);diff=np.array([s['weight_l1'] for s in samples])
    result['skin_clearance']={'gap_percentiles_m':np.percentile(gaps,[0,5,50,95,100]).tolist(),
        'weight_l1_percentiles':np.percentile(diff,[0,50,95,100]).tolist(),
        'vertices_within_1mm':int(sum(gaps<.001)),
        'within_2mm_and_weight_difference_over_0_5':int(sum((gaps<.002)&(diff>.5))),
        'worst_near_skin':[s for s in sorted(samples,key=lambda s:-s['weight_l1']) if s['gap_m']<.002][:25]}
(OUT/'blender_source_audit.json').write_text(json.dumps(result,indent=2,default=float))
print('CLOTHING_AUDIT',json.dumps({'rigify':rigify,'mismatched_seam_pairs':result['clothing']['mismatched_seam_pairs'],
    'components':[c['vertices'] for c in result['clothing']['components']],
    'clearance':{k:v for k,v in result.get('skin_clearance',{}).items() if k!='worst_near_skin'}}),flush=True)
