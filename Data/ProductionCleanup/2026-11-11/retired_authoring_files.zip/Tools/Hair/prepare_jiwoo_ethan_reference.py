"""Bake Jiwoo's DNA controls to Ethan's shape interface, outside Unity Assets.

Run with Blender 5.2 --background --factory-startup --disable-autoexec and
the ORIGINAL Jiwoo_Rigged.blend open. Embedded text scripts are never executed.
The installed Character DNA SDK is used explicitly, with the saved legacy
joint conversion plan. No Unity assets or original deliveries are modified.
"""
import hashlib
import json
import os
import sys
from array import array
from collections import defaultdict
from pathlib import Path

import bpy
import numpy as np
from mathutils import Matrix, Vector
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'Data/JiwooRigged/EthanReference'
PREPARED = OUT / 'Jiwoo_EthanSetup.blend'
DNA = Path('C:/Users/ina17/Downloads/Jiwoo_DNA_MetaHumanCharacter/head.dna')
BINDINGS = Path('C:/Users/ina17/AppData/Roaming/Blender Foundation/Blender/4.5/extensions/api_portal_polyhammer_com/character_dna/bindings/windows/x64/py313')
PREFIX = 'Jiwoo_MetaHumanCharacter_'


def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def coords(data):
    a = np.empty(len(data)*3, np.float32)
    data.foreach_get('co', a)
    return a.reshape(-1, 3)


def world(points, matrix):
    m = np.array(matrix, np.float64)
    return (points @ m[:3, :3].T + m[:3, 3]).astype(np.float32)


def sample(obj):
    ev = obj.evaluated_get(bpy.context.evaluated_depsgraph_get())
    mesh = ev.to_mesh()
    try:
        assert len(mesh.vertices) == len(obj.data.vertices), obj.name
        return world(coords(mesh.vertices), obj.matrix_world)
    finally:
        ev.to_mesh_clear()


def mappings():
    """Explicit semantic poses, not recovered Ethan motion clips."""
    p = {}
    def put(name, **controls):
        p[name] = controls
    for side, word in [('L','Left'),('R','Right')]:
        for name, raw in [('eyeBlink','eyeBlink'),('eyeWide','eyeWiden'),
                          ('eyeSquint','eyeLidPress'),('browDown','browDown'),
                          ('browOuterUp','browRaiseOuter'),('cheekSquint','eyeCheekRaise'),
                          ('noseSneer','noseWrinkle'),('mouthSmile','mouthCornerPull'),
                          ('mouthFrown','mouthCornerDepress'),('mouthDimple','mouthDimple'),
                          ('mouthStretch','mouthStretch'),('mouthLowerDown','mouthLowerLipDepress'),
                          ('mouthUpperUp','mouthUpperLipRaise')]:
            put(name+word, **{raw+side:1.0})
        for name, raw in [('Up','Up'),('Down','Down'),
                          ('In','Right' if side=='L' else 'Left'),
                          ('Out','Left' if side=='L' else 'Right')]:
            put('eyeLook'+name+word, **{'eyeLook'+raw+side:1.0})
        put('mouthPress'+word, **{'mouthPressU'+side:1.,'mouthPressD'+side:1.})
        put('eyeSquint'+word, **{'eyeSquintInner'+side:.8,'eyeCheekRaise'+side:.6,'eyeBlink'+side:.2})
    put('browInnerUp', browRaiseInL=1., browRaiseInR=1.)
    put('cheekPuff', mouthCheekBlowL=1., mouthCheekBlowR=1.)
    for name, raw in [('jawOpen','jawOpen'),('jawForward','jawFwd'),('jawLeft','jawLeft'),('jawRight','jawRight'),('mouthLeft','mouthLeft'),('mouthRight','mouthRight'),('tongueOut','tongueOut')]:
        put(name, **{raw:1.})
    def quadrants(raw, level=1., parts=('U','D')):
        return {raw+part+side:level for part in parts for side in ('L','R')}
    put('mouthClose', **quadrants('mouthLipsTogether'), **quadrants('mouthPress',.5), mouthLipsPressL=.5,mouthLipsPressR=.5)
    put('mouthFunnel', **quadrants('mouthFunnel'))
    put('mouthPucker', **quadrants('mouthLipsPurse'))
    put('mouthRollLower', mouthLowerLipRollInL=1., mouthLowerLipRollInR=1.)
    put('mouthRollUpper', mouthUpperLipRollInL=1., mouthUpperLipRollInR=1.)
    put('mouthShrugLower', jawChinRaiseDL=1., jawChinRaiseDR=1.)
    put('mouthShrugUpper', jawChinRaiseUL=1., jawChinRaiseUR=1.)
    put('viseme_sil')
    put('viseme_PP', **quadrants('mouthLipsTogether',.8), **quadrants('mouthLipsPress',.6,parts=('',)))
    put('viseme_FF', jawOpen=.12, mouthLowerLipBiteL=.8, mouthLowerLipBiteR=.8)
    put('viseme_TH', jawOpen=.25, tongueOut=.45, tongueUp=.2)
    put('viseme_DD', jawOpen=.22, tongueTipUp=.8, tongueUp=.25)
    put('viseme_kk', jawOpen=.4, tongueBendUp=.65)
    put('viseme_CH', jawOpen=.2, **quadrants('mouthFunnel',.55))
    put('viseme_SS', jawOpen=.08, mouthStretchL=.45, mouthStretchR=.45)
    put('viseme_nn', jawOpen=.16, tongueTipUp=.75)
    put('viseme_RR', jawOpen=.25, tongueTipUp=.4, **quadrants('mouthLipsPurse',.4))
    put('viseme_aa', jawOpen=.75)
    put('viseme_E', jawOpen=.35, mouthStretchL=.6, mouthStretchR=.6)
    put('viseme_I', jawOpen=.15, mouthStretchL=.8, mouthStretchR=.8)
    put('viseme_O', jawOpen=.5, **quadrants('mouthFunnel',.8))
    put('viseme_U', jawOpen=.12, **quadrants('mouthLipsPurse',.85))
    combos = {'emo_joy':['mouthSmileLeft','mouthSmileRight','cheekSquintLeft','cheekSquintRight'],
              'emo_sadness':['mouthFrownLeft','mouthFrownRight','browInnerUp'],
              'emo_anger':['browDownLeft','browDownRight','mouthPressLeft','mouthPressRight'],
              'emo_surprise':['browInnerUp','browOuterUpLeft','browOuterUpRight','eyeWideLeft','eyeWideRight','jawOpen'],
              'emo_fear':['browInnerUp','eyeWideLeft','eyeWideRight','mouthStretchLeft','mouthStretchRight'],
              'emo_disgust':['noseSneerLeft','noseSneerRight','mouthUpperUpLeft','mouthUpperUpRight']}
    for name, parts in combos.items():
        p[name] = {k:v for part in parts for k,v in p[part].items()}
    return p


def boundary(obj):
    edges = defaultdict(int)
    for poly in obj.data.polygons:
        v = list(poly.vertices)
        for a,b in zip(v,v[1:]+v[:1]): edges[tuple(sorted((a,b)))] += 1
    return {v for edge,count in edges.items() if count==1 for v in edge}


def normalize_weights(obj, bones):
    for g in list(obj.vertex_groups):
        if g.name not in bones: obj.vertex_groups.remove(g)
    fallback = obj.vertex_groups.get('DEF-spine.006') or obj.vertex_groups.new(name='DEF-spine.006')
    for vertex in obj.data.vertices:
        weights = [(g.group,g.weight) for g in vertex.groups if g.weight>0]
        total = sum(w for _,w in weights)
        if total<1e-8:
            fallback.add([vertex.index],1.,'REPLACE')
        else:
            for index,w in weights: obj.vertex_groups[index].add([vertex.index],w/total,'REPLACE')


def make_groom(label, source, head, shaped, output_collection, names, radius):
    """Tapered mesh strands with every pose and weight bound to the head skin."""
    ev = source.evaluated_get(bpy.context.evaluated_depsgraph_get())
    a = np.empty(len(ev.data.points)*3,np.float32)
    ev.data.attributes['position'].data.foreach_get('vector',a)
    points = world(a.reshape(-1,3),ev.matrix_world)
    centerlines=[]
    for c in ev.data.curves:
        curve=points[c.first_point_index:c.first_point_index+c.points_length]
        dist=np.r_[0.,np.cumsum(np.linalg.norm(np.diff(curve,axis=0),axis=1))]
        assert dist[-1]>0
        centerlines.append(np.column_stack([np.interp(np.linspace(0,dist[-1],8),dist,curve[:,i]) for i in range(3)]))
    lines=np.asarray(centerlines)
    h=shaped[head.name]['Basis'].astype(np.float64)
    head.data.calc_loop_triangles()
    triangles=np.array([t.vertices[:] for t in head.data.loop_triangles],np.int32)
    bvh=BVHTree.FromPolygons(h.tolist(),triangles.tolist(),all_triangles=True)
    ids=[];barys=[];gaps=[]
    for root in lines[:,0]:
        closest,_,index,gap=bvh.find_nearest(Vector(root))
        tri=triangles[index]; a,b,c=h[tri]
        vw=np.linalg.lstsq(np.column_stack((b-a,c-a)),np.array(closest)-a,rcond=None)[0]
        ids.append(tri);barys.append([1.-sum(vw),*vw]);gaps.append(gap)
    ids=np.array(ids);barys=np.array(barys)
    def frames(vertices):
        t=vertices[ids]
        x=t[:,1]-t[:,0];x/=np.linalg.norm(x,axis=1)[:,None]
        z=np.cross(x,t[:,2]-t[:,0]);z/=np.linalg.norm(z,axis=1)[:,None]
        y=np.cross(z,x)
        return np.stack((x,y,z),axis=2)
    base_frames=frames(h)
    anchors=np.einsum('ni,nij->nj',barys,h[ids])
    # Smooth tube frames follow each strand's tangent, with a tapered tip.
    tangent=np.gradient(lines,axis=1); tangent/=np.linalg.norm(tangent,axis=2)[:,:,None]
    axis=np.broadcast_to([0.,0.,1.],tangent.shape).copy()
    axis[np.abs(tangent[:,:,2])>.9]=[1.,0.,0.]
    u=np.cross(tangent,axis);u/=np.linalg.norm(u,axis=2)[:,:,None]
    v=np.cross(tangent,u)
    angles=np.arange(3)*2*np.pi/3
    taper=np.linspace(1.,.12,8)*radius
    tubes=(lines[:,:,None,:]+taper[None,:,None,None]*(u[:,:,None,:]*np.cos(angles)[None,None,:,None]+v[:,:,None,:]*np.sin(angles)[None,None,:,None])).reshape(len(lines),24,3)
    offsets=np.einsum('nji,nkj->nki',base_frames,tubes-anchors[:,None,:])
    faces=[]
    for strand in range(len(lines)):
        start=strand*24
        for segment in range(7):
            for side in range(3):
                a=start+segment*3+side;b=start+segment*3+(side+1)%3
                faces.append((a,b,b+3,a+3))
        faces.append(tuple(start+i for i in reversed(range(3))))
        faces.append(tuple(start+21+i for i in range(3)))
    mesh=bpy.data.meshes.new(label)
    mesh.from_pydata(tubes.reshape(-1,3).tolist(),[],faces)
    obj=bpy.data.objects.new(label,mesh);output_collection.objects.link(obj)
    material=bpy.data.materials.get('Jiwoo_FacialHair_Mesh') or bpy.data.materials.new('Jiwoo_FacialHair_Mesh')
    material.diffuse_color=(.025,.012,.008,1.)
    material.use_nodes=True
    bsdf=material.node_tree.nodes.get('Principled BSDF')
    bsdf.inputs['Base Color'].default_value=material.diffuse_color
    bsdf.inputs['Roughness'].default_value=.65
    mesh.materials.append(material)
    for poly in mesh.polygons: poly.use_smooth=True
    arrays={}
    for name in ['Basis']+names:
        hp=shaped[head.name][name].astype(np.float64)
        anchor=np.einsum('ni,nij->nj',barys,hp[ids])
        posed=anchor[:,None,:]+np.einsum('nij,nkj->nki',frames(hp),offsets)
        arrays[name]=posed.reshape(-1,3).astype(np.float32)
        key=obj.shape_key_add(name=name,from_mix=False);key.value=0.;key.data.foreach_set('co',arrays[name].ravel())
    for strand, (tri,bary) in enumerate(zip(ids,barys)):
        weights=defaultdict(float)
        for vertex,factor in zip(tri,bary):
            for g in head.data.vertices[vertex].groups:
                weights[head.vertex_groups[g.group].name]+=g.weight*factor
        total=sum(weights.values());assert total>0
        for name,w in weights.items():
            if w>1e-7:
                group=obj.vertex_groups.get(name) or obj.vertex_groups.new(name=name)
                group.add(list(range(strand*24,(strand+1)*24)),w/total,'REPLACE')
    report={'strands':len(lines),'vertices':len(mesh.vertices),'sides':3,'samples_per_strand':8,
            'root_gap_max_m':max(gaps),'radius_m':radius,
            'binding':'Barycentric head surface anchors and triangle frames, identical normalized root weights; all 73 shapes baked into the same Face mesh.'}
    np.savez_compressed(OUT/(label+'_binding.npz'),triangles=ids,barycentric=barys,local_offsets=offsets)
    return obj, arrays, report


def main():
    assert Path(bpy.data.filepath).name=='Jiwoo_Rigged.blend'
    assert not PREPARED.exists() or '--rebuild-generated' in sys.argv, 'Refusing to overwrite a prepared artist file'
    OUT.mkdir(exist_ok=True)
    source=Path(bpy.data.filepath); source_hash=sha(source)
    originals=set(bpy.data.objects)
    ethan=ROOT/'Assets/_Sandbox/Characters/Ethan/Ethan_unity.fbx'
    bpy.ops.import_scene.fbx(filepath=str(ethan))
    reference=next(o for o in set(bpy.data.objects)-originals if o.type=='MESH' and o.data.shape_keys)
    names=[k.name for k in reference.data.shape_keys.key_blocks][1:]
    evidence={'source':str(ethan),'sha256':sha(ethan),'face_vertices':len(reference.data.vertices),
              'shape_names':names,'materials':[m.name for m in reference.data.materials]}
    assert names==json.loads(Path(__file__).with_name('jiwoo_shape_names.json').read_text())
    for o in set(bpy.data.objects)-originals: bpy.data.objects.remove(o,do_unlink=True)
    sys.path.insert(0,str(BINDINGS)); dll=os.add_dll_directory(str(BINDINGS))
    import dna
    import riglogic
    import _riglogic_blender as native
    stream=dna.FileStream(str(DNA),dna.FileStream.AccessMode_Read,dna.FileStream.OpenMode_Binary)
    reader=dna.BinaryStreamReader(stream,dna.DataLayer_All);reader.read()
    assert dna.Status.isOk(),dna.Status.get().message
    manager=riglogic.RigLogic(reader);state=riglogic.RigInstance(manager)
    raw_names=[reader.getRawControlName(i) for i in range(reader.getRawControlCount())]
    mapping=mappings();assert set(names)==set(mapping)
    for controls in mapping.values():
        assert all('CTRL_expressions.'+k in raw_names for k in controls),controls
    objects=sorted([o for o in originals if o.type=='MESH' and o.name.startswith(PREFIX)
                    and o.name in bpy.context.scene.objects],key=lambda o:o.name)
    raw={o.name:coords(o.data.vertices).copy() for o in objects}
    carrier=bpy.data.objects[PREFIX+'head_native'];head_rig=bpy.data.objects[PREFIX+'head_rig']
    # Only the native head's channel drivers are replaced by explicit SDK samples.
    for curve in head_rig.animation_data.drivers: curve.mute=True
    for curve in carrier.animation_data.drivers: curve.mute=True
    joints=[i['name'] for i in carrier['joints']]
    plan=array('f',carrier['plan']);local=array('d',[0.])* (len(joints)*9)
    assert len(plan)==27*len(joints)
    # Validate that this DNA belongs to every delivered facial mesh, including
    # the separated mouth/tongue pieces; no nearest-surface pose transfer is used.
    dna_meshes={reader.getMeshName(i):i for i in range(reader.getMeshCount())}
    corrections={}; correspondence=[]
    for obj in objects:
        suffix=obj.name.removeprefix(PREFIX).split('.')[0]
        if suffix not in dna_meshes: continue
        index=dna_meshes[suffix]
        points=np.column_stack([reader.getVertexPositionXs(index),reader.getVertexPositionYs(index),reader.getVertexPositionZs(index)])*.01
        points=points[:,[0,2,1]];points[:,1]*=-1
        tree=KDTree(len(points))
        for i,p in enumerate(points):tree.insert(p,i)
        tree.balance()
        matches=[tree.find(p) for p in world(raw[obj.name],obj.matrix_world)]
        error=max(m[2] for m in matches)
        # The modeller welded teeth and separated two inner-mouth pieces.
        # Retain those authored offsets; identify their DNA corrective vertices
        # within 0.2 mm. The main head must match within 0.01 mm.
        tolerance=.00001 if obj.name==PREFIX+'head_lod0_mesh' else .0002
        assert error<tolerance,(obj.name,error)
        ids=np.array([m[1] for m in matches],np.int32)
        targets=[]
        inverse=np.array(obj.matrix_world.to_3x3().inverted(),np.float64)
        for target in range(reader.getBlendShapeTargetCount(index)):
            delta=np.zeros((len(points),3),np.float32)
            values=np.column_stack([reader.getBlendShapeTargetDeltaXs(index,target),reader.getBlendShapeTargetDeltaYs(index,target),reader.getBlendShapeTargetDeltaZs(index,target)])*.01
            values=values[:,[0,2,1]];values[:,1]*=-1
            indices=np.array(reader.getBlendShapeTargetVertexIndices(index,target),np.int32)
            delta[indices]=values
            mapped=delta[ids]@inverse.T
            active=np.flatnonzero(np.any(mapped!=0,axis=1))
            if len(active):targets.append((reader.getBlendShapeChannelIndex(index,target),active,mapped[active]))
        corrections[obj.name]=targets
        correspondence.append({'source_mesh':obj.name,'dna_mesh':suffix,'max_position_error_m':error,'corrective_targets':len(targets),'correspondence_tolerance_m':tolerance})
    def pose(controls):
        for i,name in enumerate(raw_names):state.setRawControl(i,float(name.endswith('.qw')))
        for name,value in controls.items():state.setRawControl(raw_names.index('CTRL_expressions.'+name),value)
        manager.calculate(state)
        native.transform_into(plan,array('d',state.getJointOutputs()),local,False)
        for i,name in enumerate(joints):
            bone=head_rig.pose.bones[name]; bone.rotation_mode='XYZ'
            bone.location=local[i*9:i*9+3];bone.rotation_euler=local[i*9+3:i*9+6];bone.scale=local[i*9+6:i*9+9]
        outputs=np.asarray(state.getBlendShapeOutputs())
        for obj in objects:
            p=raw[obj.name].copy()
            for channel,indices,delta in corrections.get(obj.name,[]):
                if outputs[channel]:p[indices]+=delta*outputs[channel]
            obj.data.vertices.foreach_set('co',p.ravel());obj.data.update()
        bpy.context.view_layer.update()
    pose({})
    shapes={o.name:{'Basis':sample(o)} for o in objects}
    print('DNA_VALIDATED',len(correspondence),'meshes',flush=True)
    movement=[]
    for name in names:
        pose(mapping[name])
        maxima={}
        for obj in objects:
            a=sample(obj);shapes[obj.name][name]=a
            maxima[obj.name]=float(np.linalg.norm(a-shapes[obj.name]['Basis'],axis=1).max())
        maximum=max(maxima.values())
        assert name=='viseme_sil' or maximum>1e-6,(name,maximum)
        movement.append({'name':name,'max_displacement_m':maximum,'per_mesh_m':maxima})
        print('NATIVE_BAKED',name,round(maximum*1000,3),'mm',flush=True)
    pose({})
    # Consolidate to a plain deform skeleton in its evaluated neutral bind frame.
    src_rig=bpy.data.objects['rig']
    neutral_rig=src_rig.evaluated_get(bpy.context.evaluated_depsgraph_get())
    bone_names={b.name for b in src_rig.data.bones if b.use_deform}
    matrices={n:src_rig.matrix_world@neutral_rig.pose.bones[n].matrix for n in bone_names}
    authoring=bpy.data.collections.new('SOURCE_AUTHORING - preserved, hidden')
    bpy.context.scene.collection.children.link(authoring)
    for obj in list(bpy.context.scene.objects):
        for c in list(obj.users_collection):c.objects.unlink(obj)
        authoring.objects.link(obj)
    output=bpy.data.collections.new('JIWOO_ETHAN_SETUP - Face and mesh eyebrows')
    bpy.context.scene.collection.children.link(output)
    rig=bpy.data.objects.new('Jiwoo_Armature',bpy.data.armatures.new('Jiwoo_Deform'))
    output.objects.link(rig)
    bpy.ops.object.select_all(action='DESELECT');rig.select_set(True);bpy.context.view_layer.objects.active=rig
    bpy.ops.object.mode_set(mode='EDIT')
    for name in sorted(bone_names):
        b=rig.data.edit_bones.new(name);b.matrix=matrices[name];b.length=max(src_rig.data.bones[name].length,.001)
    for name in bone_names:
        ancestor=src_rig.data.bones[name].parent; parent=None
        while ancestor:
            candidate=ancestor.name if ancestor.name in bone_names else 'DEF-'+ancestor.name.removeprefix('ORG-')
            if candidate in bone_names and candidate!=name:parent=candidate;break
            ancestor=ancestor.parent
        if parent is None and name!='DEF-spine':parent='DEF-spine.006' if matrices[name].translation.z>1.5 else 'DEF-spine'
        if parent:rig.data.edit_bones[name].parent=rig.data.edit_bones[parent]
    bpy.ops.object.mode_set(mode='OBJECT')
    meshes={}
    for source_obj in objects:
        obj=source_obj.copy();obj.data=source_obj.data.copy();obj.name='Prepared_'+source_obj.name.removeprefix(PREFIX)
        obj.animation_data_clear();obj.parent=None;obj.matrix_world=Matrix.Identity(4)
        for m in list(obj.modifiers):obj.modifiers.remove(m)
        output.objects.link(obj);obj.hide_set(False)
        obj.data.vertices.foreach_set('co',shapes[source_obj.name]['Basis'].ravel())
        for name in ['Basis']+names:
            key=obj.shape_key_add(name=name,from_mix=False);key.value=0.;key.data.foreach_set('co',shapes[source_obj.name][name].ravel())
        normalize_weights(obj,bone_names);meshes[source_obj.name]=obj
    head=meshes[PREFIX+'head_lod0_mesh'];body=meshes[PREFIX+'body_lod0_mesh']
    tree=KDTree(len(body.data.vertices))
    for i in boundary(body):tree.insert(body.data.vertices[i].co,i)
    tree.balance();pairs=[];seam_adjustment=0.
    for i in boundary(head):
        _,j,gap=tree.find(head.data.vertices[i].co)
        if gap>.00005:continue
        for g in list(head.data.vertices[i].groups):head.vertex_groups[g.group].remove([i])
        for g in body.data.vertices[j].groups:
            name=body.vertex_groups[g.group].name
            group=head.vertex_groups.get(name) or head.vertex_groups.new(name=name);group.add([i],g.weight,'REPLACE')
        for name in ['Basis']+names:
            target=body.data.shape_keys.key_blocks[name].data[j].co
            seam_adjustment=max(seam_adjustment,(head.data.shape_keys.key_blocks[name].data[i].co-target).length)
            head.data.shape_keys.key_blocks[name].data[i].co=target
            shapes[PREFIX+'head_lod0_mesh'][name][i]=target
        head.data.vertices[i].co=body.data.vertices[j].co
        pairs.append((i,j))
    assert len(pairs)>=80,len(pairs)
    facial_hair=[];grooms=[]
    for label,source_name,radius in [('Eyebrows','main.001',.000035),('Eyelashes','Group_0.001',.000025)]:
        obj,arrays,report=make_groom(label,bpy.data.objects[source_name],head,
            {head.name:shapes[PREFIX+'head_lod0_mesh']},output,names,radius)
        facial_hair.append(obj);grooms.append({'label':label,**report})
        print('MESH_GROOM',label,report['strands'],report['vertices'],flush=True)
    # Scalp remains a separate groom. Only facial hair is folded into Face.
    scalp_source=bpy.data.objects['Group_0_001']
    scalp_ev=scalp_source.evaluated_get(bpy.context.evaluated_depsgraph_get())
    scalp=bpy.data.objects.new('Jiwoo_ScalpGroom',scalp_ev.data.copy());output.objects.link(scalp)
    scalp.matrix_world=scalp_ev.matrix_world.copy()
    scalp.parent=rig;scalp.parent_type='BONE';scalp.parent_bone='DEF-spine.006'
    scalp.matrix_world=scalp_ev.matrix_world.copy()
    if hasattr(scalp.data,'surface'):scalp.data.surface=None
    outfit=meshes.pop(PREFIX+'Outfits');outfit.name='Outfit'
    bpy.ops.object.select_all(action='DESELECT')
    parts=list(meshes.values())+facial_hair
    # Keep deterministic vertex ranges for independent checks of all sections.
    parts=[head]+[o for o in parts if o!=head]
    ranges=[];offset=0
    for part in parts:
        ranges.append({'name':part.name,'start':offset,'count':len(part.data.vertices)})
        offset+=len(part.data.vertices);part.select_set(True)
    bpy.context.view_layer.objects.active=head;bpy.ops.object.join()
    face=bpy.context.object;face.name='Face';face.data.name='Jiwoo_Face_WithEyebrows'
    for obj in (face,outfit):
        obj.parent=rig;obj.matrix_world=Matrix.Identity(4)
        modifier=obj.modifiers.new('Armature','ARMATURE');modifier.object=rig
    authoring.hide_viewport=True;authoring.hide_render=True
    for obj in authoring.objects:
        if obj.animation_data:
            for driver in obj.animation_data.drivers:driver.mute=True
    for text in bpy.data.texts:text.use_module=False
    for obj in bpy.context.selected_objects:obj.select_set(False)
    face.select_set(True);bpy.context.view_layer.objects.active=face
    bpy.context.scene.unit_settings.system='METRIC';bpy.context.scene.unit_settings.scale_length=1.
    # Pack existing delivery images into the review file so it opens elsewhere.
    for image in bpy.data.images:
        if image.source=='FILE' and not image.packed_file and image.has_data:
            image.pack()
    np.savez_compressed(OUT/'face_baseline.npz',**{k.name:coords(k.data) for k in face.data.shape_keys.key_blocks})
    np.savez_compressed(OUT/'outfit_baseline.npz',**{k.name:coords(k.data) for k in outfit.data.shape_keys.key_blocks})
    report={'source':str(source),'source_sha256':source_hash,'dna':str(DNA),'dna_sha256':sha(DNA),
            'reference':evidence,'method':'Jiwoo DNA RigLogic raw controls, joint outputs converted using delivered legacy plan, DNA corrective shapes mapped by exact neutral vertex correspondence; evaluated world-space geometry baked onto a neutral deform rig.',
            'pose_mapping':mapping,'dna_correspondence':correspondence,'shapes':movement,
            'grooms':grooms,'face_vertices':len(face.data.vertices),'face_sections':ranges,
            'bones':len(bone_names),'seam_pairs':pairs,'seam_max_correction_m':seam_adjustment,
            'limitations':['73 semantic poses are mapped to Jiwoo controls; Ethan original control values and animation clips cannot be recovered from the FBX.',
                'Visemes and emotion combinations are authored native-control recipes, requiring artistic review.',
                'A linear shape combination approximates nonlinear DNA evaluation between the sampled endpoints.',
                'Scalp remains separate curves and is not part of the FBX; facial hair is mesh geometry inside Face.',
                'Baked facial bone motion must not also be applied as facial skeletal animation.',
                'Visual expression/contact quality and Unity reimport have not been approved or tested in Play Mode.']}
    (OUT/'preparation_report.json').write_text(json.dumps(report,indent=2))
    bpy.context.preferences.filepaths.save_version=0
    bpy.ops.wm.save_as_mainfile(filepath=str(PREPARED))
    bpy.ops.object.select_all(action='DESELECT')
    for obj in (rig,face,outfit):obj.select_set(True)
    bpy.context.view_layer.objects.active=rig
    bpy.ops.export_scene.fbx(filepath=str(OUT/'Jiwoo_EthanSetup.fbx'),use_selection=True,
        object_types={'ARMATURE','MESH'},global_scale=1,apply_unit_scale=True,
        apply_scale_options='FBX_SCALE_UNITS',axis_forward='-Z',axis_up='Y',
        use_space_transform=True,bake_space_transform=False,use_mesh_modifiers=False,
        add_leaf_bones=False,primary_bone_axis='Y',secondary_bone_axis='X',
        use_armature_deform_only=False,bake_anim=False,mesh_smooth_type='FACE',
        path_mode='AUTO',embed_textures=False,use_custom_props=False)
    assert sha(source)==source_hash
    print('PREPARED',str(PREPARED),flush=True)


if __name__=='__main__':
    main()
