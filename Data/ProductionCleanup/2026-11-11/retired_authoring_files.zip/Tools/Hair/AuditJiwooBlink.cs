using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using Newtonsoft.Json;

public static class AuditJiwooBlink
{
    const string Model="Assets/_Sandbox/Characters/Jiwoo New/Jiwoo_EthanSetup.fbx";
    const string Output="Data/JiwooRigged/BlinkAudit";
    public static object Main()
    {
        if(EditorApplication.isPlayingOrWillChangePlaymode)throw new Exception("Edit Mode diagnostic only; leave Play Mode under user control.");
        Directory.CreateDirectory(Output);
        var preview=new PreviewRenderUtility();
        var model=UnityEngine.Object.Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>(Model));
        model.hideFlags=HideFlags.HideAndDontSave;model.GetComponent<Animator>().enabled=false;
        var face=model.GetComponentsInChildren<SkinnedMeshRenderer>(true).Single(r=>r.name=="Face");
        var mesh=UnityEngine.Object.Instantiate(face.sharedMesh);face.sharedMesh=mesh;
        var originals=face.sharedMaterials;var triangles=Enumerable.Range(0,mesh.subMeshCount).Select(mesh.GetTriangles).ToArray();
        var created=new System.Collections.Generic.List<Material>();
        var displacements=new System.Collections.Generic.Dictionary<string,float>();
        try {
            preview.AddSingleGO(model);
            var baked=new Mesh();face.BakeMesh(baked,false);
            var skin=Array.FindIndex(originals,m=>m.name=="Jiwoo_Head");
            var indices=mesh.GetTriangles(skin).Distinct().ToArray();
            var bakedVertices=baked.vertices;
            var points=indices.Select(i=>face.transform.TransformPoint(bakedVertices[i])).ToArray();
            var center=new Vector3(points.Average(p=>p.x),1.615f,0);
            var head=model.GetComponent<Animator>().GetBoneTransform(HumanBodyBones.Head);
            center.x=head.position.x;center.z=head.position.z;
            preview.camera.transform.position=center+new Vector3(0,.02f,-1.5f);
            preview.camera.transform.LookAt(center);
            preview.camera.orthographic=true;preview.camera.orthographicSize=.13f;
            preview.camera.nearClipPlane=.01f;preview.camera.farClipPlane=10;
            preview.camera.clearFlags=CameraClearFlags.Color;preview.camera.backgroundColor=new Color(.18f,.18f,.18f,1);
            preview.lights[0].intensity=1.3f;preview.lights[0].transform.rotation=Quaternion.Euler(35,20,0);
            preview.lights[1].intensity=.8f;preview.lights[1].transform.rotation=Quaternion.Euler(330,-40,0);
            UnityEngine.Object.DestroyImmediate(baked);
            var unlit=Shader.Find("Universal Render Pipeline/Unlit");
            var flat=originals.Select(source=>{
                var m=new Material(unlit);m.name=source.name+"_Diagnostic";
                if(source.HasProperty("_BaseMap"))m.SetTexture("_BaseMap",source.GetTexture("_BaseMap"));
                if(source.HasProperty("_BaseColor"))m.SetColor("_BaseColor",source.GetColor("_BaseColor"));
                // Skip transparent overlays in flat tests; opaque would change
                // their meaning and conceal the skin rather than test shading.
                created.Add(m);return m;
            }).ToArray();
            var noNormalMap=originals.Select(source=>{
                var m=new Material(source);m.DisableKeyword("_NORMALMAP");
                if(m.HasProperty("_BumpScale"))m.SetFloat("_BumpScale",0);
                created.Add(m);return m;
            }).ToArray();
            var display=new GameObject("Static blink diagnostic");display.transform.SetParent(face.transform,false);
            var filter=display.AddComponent<MeshFilter>();var staticRenderer=display.AddComponent<MeshRenderer>();
            face.enabled=false;
            Vector3[] neutralPositions=null;
            foreach(var shape in new[]{"neutral","eyeBlinkLeft","eyeBlinkRight"})
            {
                for(int i=0;i<mesh.blendShapeCount;i++)face.SetBlendShapeWeight(i,mesh.GetBlendShapeName(i)==shape?100:0);
                var posed=new Mesh();face.BakeMesh(posed,false);filter.sharedMesh=posed;
                var positions=posed.vertices;
                var bakedNormals=posed.normals;var bakedTangents=posed.tangents;
                if(neutralPositions==null)neutralPositions=positions;
                displacements[shape]=positions.Select((p,i)=>Vector3.Distance(p,neutralPositions[i])).Max();
                foreach(var mode in new[]{"full_lit","no_hair_lit","no_overlays_lit","skin_eyes_unlit","skin_no_normalmap","skin_recalc_normals","skin_recalc_no_normalmap"})
                {
                    posed.normals=bakedNormals;posed.tangents=bakedTangents;
                    for(int i=0;i<mesh.subMeshCount;i++) {
                        var name=originals[i].name;
                        bool omitHair=mode=="no_hair_lit" || mode.StartsWith("skin_");
                        bool omitOverlay=mode=="no_overlays_lit" || mode.StartsWith("skin_");
                        var omit=omitHair&&name=="Jiwoo_FacialHair_Mesh" || omitOverlay&&(name=="Jiwoo_EyeShell" || name=="Jiwoo_EyeEdge" || name=="Jiwoo_Cartilage");
                        posed.SetTriangles(omit?Array.Empty<int>():triangles[i],i,false);
                    }
                    if(mode.Contains("recalc")){posed.RecalculateNormals();posed.RecalculateTangents();}
                    staticRenderer.sharedMaterials=mode=="skin_eyes_unlit"?flat:mode.Contains("no_normalmap")?noNormalMap:originals;
                    preview.BeginStaticPreview(new Rect(0,0,700,700));preview.Render(true);
                    var image=preview.EndStaticPreview();File.WriteAllBytes(Output+"/"+shape+"_"+mode+".png",image.EncodeToPNG());
                    UnityEngine.Object.DestroyImmediate(image);
                }
                filter.sharedMesh=null;UnityEngine.Object.DestroyImmediate(posed);
            }
            var report=new {passed=true,displacements,materials=originals.Select(m=>new {m.name,shader=m.shader.name,
                shadowCasterPass=m.GetShaderPassEnabled("ShadowCaster"),
                alpha=m.HasProperty("_BaseColor")?m.GetColor("_BaseColor").a:1}).ToArray(),
                assetsModified=false,livePoseModified=false,playModeChanged=false};
            File.WriteAllText(Output+"/render_diagnosis.json",JsonConvert.SerializeObject(report,Formatting.Indented));return report;
        } finally {foreach(var m in created)UnityEngine.Object.DestroyImmediate(m);preview.Cleanup();UnityEngine.Object.DestroyImmediate(mesh);}
    }
}
