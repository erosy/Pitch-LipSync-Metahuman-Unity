"""Compare Unity imported asset geometry with Blender exports; no live testing."""
import json
from pathlib import Path
import numpy as np
from mathutils.kdtree import KDTree
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'Data/JiwooRigged/Batch02'
source=json.loads((OUT/'export_report.json').read_text())
unity=json.loads((OUT/'unity_geometry.json').read_text())
def xyz(v):return np.array([v['x'],v['y'],v['z']])
bones={b['name']:b for b in unity['bones']}
names=sorted(source['bone_positions'].keys()&bones.keys())
src=np.array([source['bone_positions'][n] for n in names])
dst=np.array([xyz(bones[n]['position']) for n in names])
design=np.c_[src,np.ones(len(src))]
conversion=np.linalg.lstsq(design,dst,rcond=None)[0]
bone_error=float(np.max(np.linalg.norm(design@conversion-dst,axis=1)))
convert=np.eye(4);convert[:3,:]=conversion.T
head_unity=np.array(bones['DEF-spine.006']['matrix']).reshape(4,4)
head_conversion=np.linalg.inv(head_unity)@convert@np.array(source['head_matrix_blender'])
grooms=[]
for s,u in zip(source['grooms'],unity['grooms']):
    local=np.load(OUT/(s['label']+'_head_local.npy')).reshape(-1,3)
    errors=[]
    for sample in u['samples']:
        expected=(head_conversion@np.r_[local[sample['index']],1])[:3]
        errors.append(np.linalg.norm(expected-xyz(sample['position'])))
    result={'label':s['label'],'strands':u['strands'],'max_alignment_error_m':float(max(errors)),
            'width_error_m':max(abs(u[k]-s['diameter_m']) for k in ['widthMin','widthMax'])}
    grooms.append(result)

baseline=np.load(OUT/'combined_blender_baseline.npz')
actual=np.fromfile(OUT/'unity_shape_positions.bin',dtype=np.float32).reshape(74,unity['vertices'],3)
expected={n:np.c_[baseline[n],np.ones(len(baseline[n]))]@conversion for n in baseline.files}
tree=KDTree(len(expected['Basis']))
for i,p in enumerate(expected['Basis']):tree.insert(p,i)
tree.balance()
mapping=[]
probes=['jawOpen','eyeBlinkLeft','eyeBlinkRight','mouthPucker']
for i,p in enumerate(actual[0]):
    candidates=tree.find_range(p,5e-6)
    if not candidates: candidates=[tree.find(p)]
    indices=[c[1] for c in candidates]
    if len(indices)>1:
        scores=[sum(np.linalg.norm(actual[unity['shapeNames'].index(n)+1,i]-expected[n][j]) for n in probes) for j in indices]
        mapping.append(indices[int(np.argmin(scores))])
    else:mapping.append(indices[0])
mapping=np.array(mapping)
shape_errors={n:float(np.max(np.linalg.norm(actual[i]-expected[n][mapping],axis=1)))
    for i,n in enumerate(['Basis']+unity['shapeNames'])}
scale_error=max(float(np.max(np.abs(xyz(unity[n])-1))) for n in ['headScale','rootScale'])
passed=(unity['shapeNames']==source['shape_names'] and bone_error<2e-5 and scale_error<1e-4
    and max(shape_errors.values())<2e-5 and all(g['max_alignment_error_m']<2e-5 and g['width_error_m']<1e-8 for g in grooms)
    and all(s['strands']==u['strands'] for s,u in zip(source['grooms'],unity['grooms'])))
result={'passed':passed,'matching_bones':len(names),'bone_max_error_m':bone_error,
        'mesh_and_shape_max_error_m':max(shape_errors.values()),'shape_errors_m':shape_errors,
        'unit_scale_max_error':scale_error,'world_conversion':convert.tolist(),
        'head_local_conversion':head_conversion.tolist(),'grooms':grooms,'live_testing_performed':False}
(OUT/'unity_geometry_verification.json').write_text(json.dumps(result,indent=2))
print('UNITY_STATIC_VERIFICATION '+json.dumps({k:v for k,v in result.items() if k!='shape_errors_m'}),flush=True)
assert passed,'Unity geometry differs; inspect unity_geometry_verification.json before installation'
