"""Batch 2: consolidate approved baked meshes into a neutral deform rig + Face.
Run against Batch01/Jiwoo_Rigged_Baked.blend with --disable-autoexec.
No Unity assets or source blend files are written by this exporter.
"""
import hashlib
import json
from pathlib import Path
import bpy
import numpy as np
from mathutils import Matrix
from mathutils.kdtree import KDTree
from collections import defaultdict

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'Data/JiwooRigged/Batch02'
OUT.mkdir(parents=True, exist_ok=True)
source = Path(bpy.data.filepath)
source_hash = hashlib.sha256(source.read_bytes()).hexdigest()
checkpoint = json.loads((ROOT / 'Data/JiwooRigged/Batch01/reopen_verification.json').read_text())
assert source_hash == checkpoint['prepared_sha256'], 'Prepared Blender file changed: regenerate shape baselines before exporting artist edits.'
report1 = json.loads((ROOT / 'Data/JiwooRigged/Batch01/bake_report.json').read_text(encoding='utf-8-sig'))
baseline = np.load(ROOT / 'Data/JiwooRigged/Batch01/evaluated_baselines.npz')
names = report1['shape_names']
assert len(names) == 73


def array(data, field, width=3):
    a = np.empty(len(data) * width, np.float32)
    data.foreach_get(field, a)
    return a.reshape(-1, width)


def world(points, matrix):
    m = np.array(matrix, np.float64)
    return points @ m[:3, :3].T + m[:3, 3]


src_rig = bpy.data.objects['BAKED_rig']
bone_names = {b.name for b in src_rig.data.bones if b.use_deform}
rigdata = bpy.data.armatures.new('Jiwoo_Rigged_Deform')
rig = bpy.data.objects.new('Jiwoo_Armature', rigdata)
bpy.context.scene.collection.objects.link(rig)
bpy.ops.object.select_all(action='DESELECT')
rig.select_set(True)
bpy.context.view_layer.objects.active = rig
bpy.ops.object.mode_set(mode='EDIT')
for name in bone_names:
    original = src_rig.pose.bones[name]
    b = rigdata.edit_bones.new(name)
    b.matrix = src_rig.matrix_world @ original.matrix
    b.length = max(original.bone.length, .001)


def parent_for(name):
    b = src_rig.data.bones[name].parent
    while b:
        if b.name in bone_names and b.name != name:
            return b.name
        candidate = 'DEF-' + b.name.removeprefix('ORG-')
        if candidate in bone_names and candidate != name:
            return candidate
        b = b.parent
    return 'DEF-spine.006' if src_rig.data.bones[name].head_local.z > 1.5 else 'DEF-spine'


for name in bone_names:
    parent = parent_for(name)
    if name != 'DEF-spine' and name != parent:
        rigdata.edit_bones[name].parent = rigdata.edit_bones[parent]
bpy.ops.object.mode_set(mode='OBJECT')
head = rig.matrix_world @ rigdata.bones['DEF-spine.006'].matrix_local

meshes = []
mesh_report = []
for item in report1['meshes']:
    original = bpy.data.objects[item['baked']]
    obj = original.copy()
    obj.data = original.data.copy()
    obj.name = 'Export_' + original.name
    obj.shape_key_clear()
    obj.animation_data_clear()
    for modifier in list(obj.modifiers):
        obj.modifiers.remove(modifier)
    obj.parent = None
    obj.matrix_world = Matrix.Identity(4)
    bpy.context.scene.collection.objects.link(obj)
    points = world(baseline[original.name + '|Basis'], original.matrix_world).astype(np.float32)
    obj.data.vertices.foreach_set('co', points.ravel())
    for name in ['Basis'] + names:
        key = obj.shape_key_add(name=name, from_mix=False)
        key.value = 0
        p = world(baseline[original.name + '|' + name], original.matrix_world).astype(np.float32)
        key.data.foreach_set('co', p.ravel())
    for group in list(obj.vertex_groups):
        if group.name not in bone_names:
            obj.vertex_groups.remove(group)
    head_group = obj.vertex_groups.get('DEF-spine.006') or obj.vertex_groups.new(name='DEF-spine.006')
    fallback = 0
    for vertex in obj.data.vertices:
        weights = [(g.group, g.weight) for g in vertex.groups if g.weight > 0]
        total = sum(w for _, w in weights)
        if total < 1e-8:
            head_group.add([vertex.index], 1, 'REPLACE')
            fallback += 1
        else:
            for index, weight in weights:
                obj.vertex_groups[index].add([vertex.index], weight / total, 'REPLACE')
    assert fallback == 0 or 'eyeEdge' in original.name or 'cartilage' in original.name, (original.name, fallback)
    obj.data.update()
    meshes.append(obj)
    mesh_report.append({'source':original.name,'vertices':len(obj.data.vertices),'rigid_head_vertices':fallback,
                        'weight_policy':'Retain and normalize delivered Rigify deform weights; old-rig-only eye-edge/cartilage attached to head.'})
    print('MESH', original.name, len(obj.data.vertices), 'head_fallback', fallback, flush=True)

# The delivered body and head were weighted separately. Their coincident open
# boundaries must have identical positions AND influences under every bone pose.
body = next(o for o in meshes if o.name == 'Export_BAKED_body_lod0_mesh')
head_mesh = next(o for o in meshes if o.name == 'Export_BAKED_head_lod0_mesh')
def boundary_vertices(obj):
    counts = defaultdict(int)
    for polygon in obj.data.polygons:
        vs = list(polygon.vertices)
        for a, b in zip(vs, vs[1:] + vs[:1]): counts[tuple(sorted((a, b)))] += 1
    return {i for edge, count in counts.items() if count == 1 for i in edge}
body_boundary = boundary_vertices(body)
tree = KDTree(len(body_boundary))
for index in body_boundary: tree.insert(body.data.shape_keys.key_blocks['Basis'].data[index].co, index)
tree.balance()
seam_pairs = []
max_shape_correction = 0.0
for target_index in boundary_vertices(head_mesh):
    target = head_mesh.data.shape_keys.key_blocks['Basis'].data[target_index].co
    _, source_index, distance = tree.find(target)
    if distance > .00005: continue
    source_vertex = body.data.vertices[source_index]
    source_weights = [(body.vertex_groups[g.group].name, g.weight) for g in source_vertex.groups]
    for group in list(head_mesh.data.vertices[target_index].groups):
        head_mesh.vertex_groups[group.group].remove([target_index])
    for name, weight in source_weights:
        group = head_mesh.vertex_groups.get(name) or head_mesh.vertex_groups.new(name=name)
        group.add([target_index], weight, 'REPLACE')
    for key in head_mesh.data.shape_keys.key_blocks:
        point = body.data.shape_keys.key_blocks[key.name].data[source_index].co
        max_shape_correction = max(max_shape_correction, (key.data[target_index].co - point).length)
        key.data[target_index].co = point
    head_mesh.data.vertices[target_index].co = body.data.shape_keys.key_blocks['Basis'].data[source_index].co
    seam_pairs.append({'body_vertex': source_index, 'head_vertex': target_index,
                       'position_blender': list(map(float, source_vertex.co)), 'original_gap_m': distance})
assert len(seam_pairs) >= 80, 'Expected body/head boundary was not found'
head_mesh.data.update()
seam_report = {'matched_vertices': len(seam_pairs), 'max_shape_correction_m': max_shape_correction,
               'policy': 'Body boundary positions, all shape positions, and normalized weights copied to matching head boundary.',
               'pairs': seam_pairs}
(OUT / 'seam_repair.json').write_text(json.dumps(seam_report, indent=2))
print('SEAM_REPAIRED', len(seam_pairs), 'max_shape_correction_m', max_shape_correction, flush=True)

bpy.ops.object.select_all(action='DESELECT')
for obj in meshes:
    obj.select_set(True)
bpy.context.view_layer.objects.active = meshes[0]
bpy.ops.object.join()
face = bpy.context.object
face.name = 'Face'
face.data.name = 'Face'
face.parent = rig
face.matrix_world = Matrix.Identity(4)
modifier = face.modifiers.new('Armature', 'ARMATURE')
modifier.object = rig
face.data.update()
assert [k.name for k in face.data.shape_keys.key_blocks] == ['Basis'] + names
assert len(face.data.vertices) == sum(m['vertices'] for m in mesh_report)
np.savez_compressed(OUT / 'combined_blender_baseline.npz',
    **{k.name:array(k.data,'co') for k in face.data.shape_keys.key_blocks})

# FBX retains skin weights and all 73 named shape keys. One standard deform
# skeleton replaces the author's stacked original/Rigify modifiers and controls.
bpy.ops.object.select_all(action='DESELECT')
rig.select_set(True)
face.select_set(True)
bpy.context.view_layer.objects.active = rig
bpy.ops.export_scene.fbx(filepath=str(OUT / 'Jiwoo_Rigged.fbx'), use_selection=True,
    object_types={'ARMATURE','MESH'}, global_scale=1, apply_unit_scale=True,
    apply_scale_options='FBX_SCALE_UNITS', axis_forward='-Z', axis_up='Y',
    use_space_transform=True, bake_space_transform=False, use_mesh_modifiers=False,
    add_leaf_bones=False, primary_bone_axis='Y', secondary_bone_axis='X',
    use_armature_deform_only=False, bake_anim=False, mesh_smooth_type='FACE',
    path_mode='AUTO', embed_textures=False, use_custom_props=False)

grooms = []
for label, object_name, resolution, diameter in [('Scalp','BAKED_ScalpGroom',64,.0001),
    ('Eyebrows','BAKED_EyelashGroom',32,.00007),('Eyelashes','BAKED_EyebrowGroom',32,.00005)]:
    obj = bpy.data.objects[object_name]
    evaluated = obj.evaluated_get(bpy.context.evaluated_depsgraph_get())
    data = evaluated.data
    positions = world(array(data.attributes['position'].data, 'vector'), evaluated.matrix_world)
    local = world(positions, head.inverted())
    offsets = [c.first_point_index for c in data.curves] + [len(data.points)]
    sampled = np.empty((len(data.curves),resolution,3),np.float32)
    lengths = []
    for i, (a,b) in enumerate(zip(offsets[:-1],offsets[1:])):
        curve = local[a:b]
        cumulative = np.r_[0,np.cumsum(np.linalg.norm(np.diff(curve,axis=0),axis=1))]
        assert cumulative[-1] > 0
        sampled[i] = np.column_stack([np.interp(np.linspace(0,cumulative[-1],resolution),cumulative,curve[:,j]) for j in range(3)])
        lengths.append(cumulative[-1])
    assert np.isfinite(sampled).all()
    assert max(lengths) < (1 if label=='Scalp' else .06), (label,max(lengths))
    np.save(OUT / (label + '_head_local.npy'),sampled)
    # Blender ABC Z-up->Y-up and Unity ABC handedness conversion paired with
    # the FBX bake-axis profile. Imported Unity positions are head-local XYZ.
    abc = sampled.reshape(-1,3)[:,[0,2,1]].copy()
    abc[:,0] *= -1
    curves = bpy.data.hair_curves.new('Jiwoo_' + label)
    curves.add_curves([resolution]*len(sampled))
    curves.attributes['position'].data.foreach_set('vector',abc.ravel())
    curves.set_types(type='POLY')
    radius = curves.attributes.get('radius') or curves.attributes.new('radius','FLOAT','POINT')
    radius.data.foreach_set('value',np.full(len(abc),diameter*.5,np.float32))
    export = bpy.data.objects.new('Jiwoo_'+label+'_HeadLocal',curves)
    bpy.context.scene.collection.objects.link(export)
    bpy.ops.object.select_all(action='DESELECT')
    export.select_set(True)
    bpy.context.view_layer.objects.active = export
    filename = 'Jiwoo_' + label + '_HeadLocal.abc'
    bpy.ops.wm.alembic_export(filepath=str(OUT/filename),start=1,end=1,selected=True,
        flatten=True,global_scale=1,curves_as_mesh=False,export_hair=True,
        export_particles=False,as_background_job=False,init_scene_frame_range=False)
    # Distributed curve points support an independent Unity import comparison.
    flat = sampled.reshape(-1,3)
    indices = np.linspace(0,len(flat)-1,min(2048,len(flat)),dtype=int)
    grooms.append({'label':label,'filename':filename,'strands':len(sampled),'points_per_strand':resolution,
        'diameter_m':diameter,'max_length_m':float(max(lengths)),
        'sample_indices':indices.tolist(),'head_local_samples':flat[indices].tolist(),
        'bounds':[sampled.min((0,1)).tolist(),sampled.max((0,1)).tolist()]})
    print('GROOM',label,len(sampled),max(lengths),flush=True)

textures = OUT/'Textures'
textures.mkdir(exist_ok=True)
images = []
for material in face.data.materials:
    if material and material.node_tree:
        for node in material.node_tree.nodes:
            if node.type=='TEX_IMAGE' and node.image:
                image=node.image
                if image.name in [i['image'] for i in images]: continue
                if image.packed_file:
                    filename=Path(image.filepath).name or (image.name+'.png')
                    target=textures/filename
                    if not target.suffix: target=target.with_suffix('.png')
                    target.write_bytes(bytes(image.packed_file.data))
                    images.append({'image':image.name,'filename':target.name})

report={'source':str(source),'source_sha256':source_hash,'shape_names':names,
    'vertices':len(face.data.vertices),'bones':len(rigdata.bones),'meshes':mesh_report,
    'material_names':[m.name if m else None for m in face.data.materials],
    'head_matrix_blender':np.array(head).tolist(),'grooms':grooms,'textures':images,
    'body_bounds':[np.min(array(face.data.vertices,'co'),axis=0).tolist(),np.max(array(face.data.vertices,'co'),axis=0).tolist()],
    'bone_positions':{b.name:list(b.head_local) for b in rigdata.bones},
    'status':'Exported; Blender readback and Unity static verification required.'}
report['groom_label_correction'] = 'Batch01 review object labels were reversed: main.001 (1915, higher roots) is eyebrows; Group_0.001 (787, lower roots) is eyelashes. Geometry is unchanged.'
(OUT/'export_report.json').write_text(json.dumps(report,indent=2))
assert hashlib.sha256(source.read_bytes()).hexdigest()==source_hash
print('EXPORT_COMPLETE',len(face.data.vertices),len(rigdata.bones),flush=True)
