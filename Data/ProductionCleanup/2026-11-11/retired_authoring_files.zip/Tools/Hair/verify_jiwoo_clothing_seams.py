"""Independent FBX readback: seam weights and unchanged meshes/UVs/shapes."""
import json
import sys
from pathlib import Path
import bpy
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'Data/JiwooRigged/ClothingSeamRepair'
if '--repair-root' in sys.argv:
    OUT=ROOT/sys.argv[sys.argv.index('--repair-root')+1]
def coords(data):
    a=np.empty(len(data)*3,np.float32);data.foreach_get('co',a);return a.reshape(-1,3)
def weights(obj):return [{obj.vertex_groups[g.group].name:g.weight for g in v.groups if g.weight>0} for v in obj.data.vertices]
def capture():
    result={}
    for name in ('Face','Outfit'):
        obj=bpy.data.objects[name];mesh=obj.data
        result[name]={'positions':coords(mesh.vertices),'shapes':{k.name:coords(k.data) for k in mesh.shape_keys.key_blocks},
            'topology':[tuple(p.vertices) for p in mesh.polygons],
            'materials':[m.name for m in mesh.materials],
            'uv':{uv.name:np.array([loop.uv[:] for loop in uv.data],np.float32) for uv in mesh.uv_layers},
            'weights':weights(obj)}
    return result
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.fbx(filepath=str(ROOT/'Assets/_Sandbox/Characters/Jiwoo New/Jiwoo_EthanSetup.fbx'),use_anim=False)
before=capture()
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.fbx(filepath=str(OUT/'Jiwoo_EthanSetup.fbx'),use_anim=False)
after=capture();errors={}
for name in before:
    a=before[name];b=after[name]
    assert a['topology']==b['topology'],name+' topology'
    assert a['materials']==b['materials'],name+' material slots'
    assert list(a['shapes'])==list(b['shapes']),name+' shape names'
    assert list(a['uv'])==list(b['uv']),name+' UV names'
    assert all(np.array_equal(a['uv'][key],b['uv'][key]) for key in a['uv']),name+' UVs'
    maximum=max(float(np.linalg.norm(a['shapes'][key]-b['shapes'][key],axis=1).max()) for key in a['shapes'])
    assert maximum<2e-6,(name,maximum)
    errors[name]=maximum
    if name=='Face':
        maximum_weight_error=max(abs(x.get(k,0)-y.get(k,0)) for x,y in zip(a['weights'],b['weights']) for k in x.keys()|y.keys())
        assert maximum_weight_error<2e-6,maximum_weight_error
obj=bpy.data.objects['Outfit'];w=after['Outfit']['weights']
repair=json.loads((OUT/'repair_report.json').read_text())
# FBX vertex order differs from Blender but is stable across the two exports.
# Map Blender repair points to imported geometry by neutral positions.
baseline=np.load(OUT/'outfit_weights_baseline.npz')
from mathutils.kdtree import KDTree
tree=KDTree(len(baseline['positions']))
for i,p in enumerate(baseline['positions']):tree.insert(p,i)
tree.balance()
matrix=np.array(obj.matrix_world);p=after['Outfit']['positions']@matrix[:3,:3].T+matrix[:3,3]
mapping=[tree.find(point) for point in p]
assert max(item[2] for item in mapping)<2e-6
weight_error=0.
for i,(_,j,_) in enumerate(mapping):
    expected={str(name):float(value) for name,value in zip(baseline['bones'],baseline['weights'][j]) if value>0}
    weight_error=max(weight_error,max(abs(w[i].get(k,0)-expected.get(k,0)) for k in w[i].keys()|expected.keys()))
assert weight_error<2e-6,weight_error
# Check every close imported pair directly and independently of nearest matches.
bad=0;close=0
for i in range(len(p)):
    distances=np.linalg.norm(p[i+1:]-p[i],axis=1)
    for j in np.flatnonzero(distances<.0001)+i+1:
        close+=1
        if sum(abs(w[i].get(k,0)-w[j].get(k,0)) for k in w[i].keys()|w[j].keys())>.01:bad+=1
assert bad==0,bad
result={'passed':True,'unchanged_geometry_uvs_topology_materials_and_73_shapes':True,
        'max_shape_position_error_m':errors,'max_outfit_weight_export_error':weight_error,
        'near_coincident_pairs':close,'mismatched_pairs':bad}
(OUT/'blender_readback.json').write_text(json.dumps(result,indent=2))
print('SEAM_REPAIR_FBX_VERIFIED',json.dumps(result),flush=True)
