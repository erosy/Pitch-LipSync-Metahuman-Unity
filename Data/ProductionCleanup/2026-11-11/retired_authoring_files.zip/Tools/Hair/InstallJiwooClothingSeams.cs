using System;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine.SceneManagement;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

public static class InstallJiwooClothingSeams
{
    const string Model="Assets/_Sandbox/Characters/Jiwoo New/Jiwoo_EthanSetup.fbx";
    const string Prefab="Assets/_Sandbox/Characters/Jiwoo/Jiwoo_Normalized.prefab";
    const string Output="Data/JiwooRigged/ClothingSeamRepair";
    public static object Main() => Install(Output,false);
    public static object WeightRepair() => Install("Data/JiwooRigged/ClothingWeightRepair",true);
    static object Install(string outputFolder,bool rebindOutfit)
    {
        if(EditorApplication.isPlayingOrWillChangePlaymode)throw new Exception("Edit Mode required; user controls Play Mode.");
        if(!(bool)JObject.Parse(File.ReadAllText(outputFolder+"/blender_readback.json"))["passed"])
            throw new Exception("Independent FBX verification must pass first.");
        Directory.CreateDirectory(outputFolder+"/Before");
        foreach(var file in new[]{Model,Model+".meta",Prefab,Prefab+".meta"})
        {
            var dest=outputFolder+"/Before/"+Path.GetFileName(file);
            if(!File.Exists(dest))File.Copy(file,dest);
        }
        if(!File.Exists(outputFolder+"/Before/unity_audit.json"))
            File.Copy("Data/JiwooRigged/ClothingAudit/unity_audit.json",outputFolder+"/Before/unity_audit.json");
        var importer=(ModelImporter)AssetImporter.GetAtPath(Model);
        var mapping=JsonUtility.ToJson(importer.humanDescription);
        var remaps=importer.GetExternalObjectMap().ToDictionary(p=>p.Key.name,p=>AssetDatabase.GetAssetPath(p.Value));
        var guid=AssetDatabase.AssetPathToGUID(Model);
        var prefabGuid=AssetDatabase.AssetPathToGUID(Prefab);
        var asset=AssetDatabase.LoadAssetAtPath<GameObject>(Model);
        var face=asset.GetComponentsInChildren<SkinnedMeshRenderer>(true).Single(r=>r.name=="Face").sharedMesh;
        var vertices=face.vertexCount;
        var shapes=Enumerable.Range(0,face.blendShapeCount).Select(face.GetBlendShapeName).ToArray();
        File.Copy(outputFolder+"/Jiwoo_EthanSetup.fbx",Model,true);
        AssetDatabase.ImportAsset(Model,ImportAssetOptions.ForceSynchronousImport|ImportAssetOptions.ForceUpdate);
        importer=(ModelImporter)AssetImporter.GetAtPath(Model);
        if(JsonUtility.ToJson(importer.humanDescription)!=mapping)throw new Exception("Humanoid mapping/reference pose changed.");
        foreach(var pair in importer.GetExternalObjectMap())
            if(!remaps.TryGetValue(pair.Key.name,out var expected) || AssetDatabase.GetAssetPath(pair.Value)!=expected)
                throw new Exception("Material remap changed: "+pair.Key.name);
        if(AssetDatabase.AssetPathToGUID(Model)!=guid || AssetDatabase.AssetPathToGUID(Prefab)!=prefabGuid)
            throw new Exception("Asset GUID changed.");
        asset=AssetDatabase.LoadAssetAtPath<GameObject>(Model);
        var avatar=asset.GetComponent<Animator>().avatar;
        face=asset.GetComponentsInChildren<SkinnedMeshRenderer>(true).Single(r=>r.name=="Face").sharedMesh;
        if(!avatar || !avatar.isValid || !avatar.isHuman || face.vertexCount!=vertices ||
            !shapes.SequenceEqual(Enumerable.Range(0,face.blendShapeCount).Select(face.GetBlendShapeName)))
            throw new Exception("Avatar or face integrity failed.");
        var prefab=AssetDatabase.LoadAssetAtPath<GameObject>(Prefab);
        var outfit=prefab.GetComponentsInChildren<SkinnedMeshRenderer>(true).Single(r=>r.name=="Outfit");
        var imported=asset.GetComponentsInChildren<SkinnedMeshRenderer>(true).Single(r=>r.name=="Outfit");
        if(rebindOutfit)
        {
            Action<GameObject,bool> rebind=(root,undo)=>{
                var r=root.GetComponentsInChildren<SkinnedMeshRenderer>(true).Single(x=>x.name=="Outfit");
                if(undo)Undo.RecordObject(r,"Update Jiwoo garment bone bindings");
                var bones=root.GetComponentsInChildren<Transform>(true).Where(t=>t.name.StartsWith("DEF-")).ToDictionary(t=>t.name);
                r.bones=imported.bones.Select(b=>bones[b.name]).ToArray();r.rootBone=bones[imported.rootBone.name];
                EditorUtility.SetDirty(r);
                if(undo && PrefabUtility.IsPartOfPrefabInstance(r))PrefabUtility.RecordPrefabInstancePropertyModifications(r);
            };
            var content=PrefabUtility.LoadPrefabContents(Prefab);
            try{rebind(content,false);PrefabUtility.SaveAsPrefabAsset(content,Prefab);}
            finally{PrefabUtility.UnloadPrefabContents(content);}
            for(int i=0;i<SceneManager.sceneCount;i++)
            {
                var scene=SceneManager.GetSceneAt(i);
                if(!scene.isLoaded || EditorSceneManager.IsPreviewScene(scene))continue;
                foreach(var root in scene.GetRootGameObjects().Where(r=>r.name=="Jiwoo_Normalized"))
                {rebind(root,true);EditorSceneManager.MarkSceneDirty(scene);}
            }
        }
        if(outfit.sharedMesh!=imported.sharedMesh)throw new Exception("Prefab lost its outfit mesh reference.");
        Selection.activeObject=prefab;
        var result=new {passed=true,model=Model,prefab=Prefab,modelGuid=guid,prefabGuid,
            avatarValid=avatar.isValid,humanoid=avatar.isHuman,faceShapeCount=shapes.Length,
            materialRemapsPreserved=true,humanoidMappingPreserved=true,sceneSaved=false,playModeChanged=false};
        File.WriteAllText(outputFolder+"/unity_install.json",JsonConvert.SerializeObject(result,Formatting.Indented));
        return result;
    }
}
