"""Read-only inspection of the delivered rig and installed DNA SDK."""
import sys
import os
import json
from pathlib import Path
import bpy
import numpy as np
from array import array
from mathutils.kdtree import KDTree

bindings = Path('C:/Users/ina17/AppData/Roaming/Blender Foundation/Blender/4.5/extensions/api_portal_polyhammer_com/character_dna/bindings/windows/x64/py313')
sys.path.insert(0, str(bindings))
dll = os.add_dll_directory(str(bindings))
import dna
import riglogic
import _riglogic_blender as native

path = 'C:/Users/ina17/Downloads/Jiwoo_DNA_MetaHumanCharacter/head.dna'
stream = dna.FileStream(path, dna.FileStream.AccessMode_Read, dna.FileStream.OpenMode_Binary)
reader = dna.BinaryStreamReader(stream, dna.DataLayer_All)
reader.read()
assert dna.Status.isOk(), dna.Status.get().message
result = {
    'dna_meshes': [{'index':i, 'name':reader.getMeshName(i), 'vertices':reader.getVertexPositionCount(i)} for i in range(reader.getMeshCount())],
    'raw_controls':[reader.getRawControlName(i) for i in range(reader.getRawControlCount())],
    'gui_controls':[reader.getGUIControlName(i) for i in range(reader.getGUIControlCount())],
    'native_functions':{n:getattr(native,n).__doc__ for n in dir(native) if not n.startswith('_')},
    'carriers':[],
}
manager = riglogic.RigLogic(reader)
state = riglogic.RigInstance(manager)
for i in range(reader.getRawControlCount()):
    state.setRawControl(i, float(reader.getRawControlName(i).endswith('.qw')))
manager.calculate(state)
carrier = bpy.data.objects['Jiwoo_MetaHumanCharacter_head_native']
local = array('d', [0.0]) * (len(carrier['joints'])*9)
native.transform_into(array('f',carrier['plan']), array('d',state.getJointOutputs()), local, False)
result['neutral_local_max'] = max(abs(v) for i,v in enumerate(local) if i%9<6)
head = bpy.data.objects['Jiwoo_MetaHumanCharacter_head_lod0_mesh']
dp = np.array([reader.getVertexPosition(i) for i in range(reader.getVertexPositionCount(0))]) if False else np.column_stack([reader.getVertexPositionXs(0),reader.getVertexPositionYs(0),reader.getVertexPositionZs(0)])*.01
dp = dp[:,[0,2,1]]; dp[:,1]*=-1
tree = KDTree(len(dp))
for i,p in enumerate(dp): tree.insert(p,i)
tree.balance()
raw = np.array([head.matrix_world @ v.co for v in head.data.vertices])
ev = head.evaluated_get(bpy.context.evaluated_depsgraph_get())
evaluated = np.array([head.matrix_world @ v.co for v in ev.data.vertices])
result['dna_nearest_raw_m'] = [float(x) for x in np.percentile([tree.find(p)[2] for p in raw],[0,50,95,100])]
result['dna_nearest_evaluated_m'] = [float(x) for x in np.percentile([tree.find(p)[2] for p in evaluated],[0,50,95,100])]
result['rig_coordinate_version'] = bpy.data.objects['Jiwoo_MetaHumanCharacter_head_rig'].get('dna_coordinate_version')
result['neutral_local_first'] = list(local[:18])
result['head_bounds'] = [raw.min(0).tolist(),raw.max(0).tolist()]
for o in bpy.data.objects:
    if not o.name.endswith('_native'): continue
    result['carriers'].append({'name':o.name,'plan_length':len(o.get('plan',[])),
        'plan_sample':list(o.get('plan',[]))[:46],
        'joints_sample':[dict(i) for i in o.get('joints',[])[:2]],
        'raw_sample':[dict(i) for i in o.get('raw',[])[:4]],
        'gui_sample':[dict(i) for i in o.get('gui',[])[:4]]})
out = Path(__file__).resolve().parents[2]/'Data/JiwooRigged/EthanReference'
out.mkdir(exist_ok=True)
(out/'native_inspection.json').write_text(json.dumps(result,indent=2,default=str))
print('NATIVE_INSPECTED',len(result['raw_controls']),len(result['gui_controls']),flush=True)
