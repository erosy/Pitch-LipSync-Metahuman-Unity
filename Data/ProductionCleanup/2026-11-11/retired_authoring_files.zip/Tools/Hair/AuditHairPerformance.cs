using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using Unity.DemoTeam.Hair;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

public static class AuditHairPerformance
{
    static JObject J(object data)=>JObject.Parse(JsonUtility.ToJson(data));
    static object Describe(GameObject root)
    {
        return new{root.name,hairs=root.GetComponentsInChildren<HairInstance>(true).Select(h=>new{
            h.name,active=h.gameObject.activeInHierarchy,enabled=h.enabled,
            executive=J(h.settingsExecutive),volume=J(h.settingsVolumetrics),
            geometry=J(h.strandGroupDefaults.settingsGeometry),rendering=J(h.strandGroupDefaults.settingsRendering),
            physics=J(h.strandGroupDefaults.settingsPhysics),overrides=(h.strandGroupSettings??Array.Empty<HairInstance.GroupSettings>()).Select(s=>J(s)).ToArray(),
            material=AssetDatabase.GetAssetPath(h.strandGroupDefaults.settingsRendering.materialAsset),
            shader=h.strandGroupDefaults.settingsRendering.materialAsset.shader.name,
            boundaries=h.settingsEnvironment.boundaryResident.Select(b=>new{b.name,type=b.settings.type.ToString(),texture=AssetDatabase.GetAssetPath(b.settingsSDF.kSDFTexture),resolution=b.settingsSDF.kSDFTexture?b.settingsSDF.kSDFTexture.width:0}).ToArray(),
            groups=h.strandGroupProviders.SelectMany(p=>p.hairAsset.strandGroups.Select(g=>new{
                asset=AssetDatabase.GetAssetPath(p.hairAsset),bytes=new FileInfo(AssetDatabase.GetAssetPath(p.hairAsset)).Length,
                clustersEnabled=p.hairAsset.settingsBasic.kLODClusters,
                g.strandCount,g.strandParticleCount,particles=g.particlePosition.Length,g.lodCount,g.lodGuideCount,g.lodThreshold,
                solverParticlesPerLOD=g.lodGuideCount.Select(c=>(long)c*g.strandParticleCount).ToArray(),
                maxLength=g.strandParamsMax.x,averageLength=g.strandParamsAvg.x,
                geometry=J(p.hairAsset.settingsAlembic),clusters=J(p.hairAsset.settingsLODClusters)
            })).ToArray()
        }).ToArray(),warmup=root.GetComponents<CharacterHairStartupWarmup>().Select(w=>EditorJsonUtility.ToJson(w)).ToArray()};
    }
    public static object Run()
    {
        if(EditorApplication.isPlayingOrWillChangePlaymode)throw new Exception("Run saved-prefab audit in Edit Mode");
        var results=new System.Collections.Generic.List<object>();
        foreach(var path in new[]{"Assets/_Sandbox/Characters/Jiwoo/Jiwoo_Normalized.prefab","Assets/_Sandbox/Characters/Ethan/Ethan.prefab"}){
            var root=PrefabUtility.LoadPrefabContents(path);try{results.Add(Describe(root));}finally{PrefabUtility.UnloadPrefabContents(root);}
        }
        string folder="Data/JiwooRigged/HairPerformance";Directory.CreateDirectory(folder);
        File.WriteAllText(folder+"/comparison.json",JsonConvert.SerializeObject(results,Formatting.Indented,new JsonSerializerSettings{ReferenceLoopHandling=ReferenceLoopHandling.Ignore}));
        var scene=UnityEngine.Object.FindObjectsByType<HairInstance>(FindObjectsInactive.Include).Where(h=>h.gameObject.scene.isLoaded).Select(h=>new{
            h.name,root=h.transform.root.name,active=h.gameObject.activeInHierarchy,h.enabled,
            scene=h.gameObject.scene.path,h.gameObject.scene.isDirty,
            executive=J(h.settingsExecutive),physics=J(h.strandGroupDefaults.settingsPhysics),rendering=J(h.strandGroupDefaults.settingsRendering),
            assets=h.strandGroupProviders.Select(p=>AssetDatabase.GetAssetPath(p.hairAsset)).ToArray(),
            residentBoundaries=h.settingsEnvironment.boundaryResident.Length
        }).ToArray();
        File.WriteAllText(folder+"/scene_comparison.json",JsonConvert.SerializeObject(scene,Formatting.Indented));
        return new{report=folder+"/comparison.json",characters=results.Count};
    }
}
