using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using Newtonsoft.Json;

public static class RepairJiwooAvatar
{
    const string Model="Assets/_Sandbox/Characters/Jiwoo/Jiwoo_Rigged.fbx";
    static void Guard(){if(EditorApplication.isPlayingOrWillChangePlaymode)throw new Exception("Edit Mode required; user controls Play Mode.");}
    static Type Setup=>typeof(Editor).Assembly.GetType("UnityEditor.AvatarSetupTool");
    static MethodInfo Method(string name,int parameters)=>Setup.GetMethods(BindingFlags.Static|BindingFlags.Public|BindingFlags.NonPublic).Single(m=>m.Name==name&&m.GetParameters().Length==parameters);
    static object Wrappers(GameObject instance,ModelImporter importer)
    {
        var modelBones=Method("GetModelBones",3).Invoke(null,new object[]{instance.transform,false,null});
        var get=Setup.GetMethods(BindingFlags.Static|BindingFlags.Public|BindingFlags.NonPublic).Single(m=>m.Name=="GetHumanBones"&&m.GetParameters()[0].ParameterType==typeof(Dictionary<string,string>));
        return get.Invoke(null,new object[]{importer.humanDescription.human.ToDictionary(h=>h.humanName,h=>h.boneName),modelBones});
    }
    public static object AuditPose()
    {
        Guard();var importer=(ModelImporter)AssetImporter.GetAtPath(Model);
        var instance=UnityEngine.Object.Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>(Model));instance.hideFlags=HideFlags.HideAndDontSave;
        try
        {
            Method("TransferDescriptionToPose",2).Invoke(null,new object[]{new SerializedObject(importer),instance.transform});
            var wrappers=Wrappers(instance,importer);
            return new{referenceTPoseValid=Method("IsPoseValid",1).Invoke(null,new[]{wrappers}),poseError=Method("GetPoseError",1).Invoke(null,new[]{wrappers})};
        }finally{UnityEngine.Object.DestroyImmediate(instance);}
    }
    public static object Apply()
    {
        Guard();var importer=(ModelImporter)AssetImporter.GetAtPath(Model);
        var asset=AssetDatabase.LoadAssetAtPath<GameObject>(Model);
        var mesh=asset.GetComponentsInChildren<SkinnedMeshRenderer>(true).Single().sharedMesh;
        var previousShapes=Enumerable.Range(0,mesh.blendShapeCount).Select(mesh.GetBlendShapeName).ToArray();
        var instance=UnityEngine.Object.Instantiate(asset);instance.hideFlags=HideFlags.HideAndDontSave;
        var description=importer.humanDescription;var original=description.skeleton;
        float before,after;bool valid;
        try
        {
            Method("TransferDescriptionToPose",2).Invoke(null,new object[]{new SerializedObject(importer),instance.transform});
            var wrappers=Wrappers(instance,importer);
            before=(float)Method("GetPoseError",1).Invoke(null,new[]{wrappers});
            // This authors only the avatar's reference skeleton on a disposable
            // model copy. It never samples or plays an animation clip.
            Method("MakePoseValid",1).Invoke(null,new[]{wrappers});
            valid=(bool)Method("IsPoseValid",1).Invoke(null,new[]{wrappers});
            after=(float)Method("GetPoseError",1).Invoke(null,new[]{wrappers});
            if(!valid)throw new Exception("Unity could not produce a valid T-pose: "+after);
            description.skeleton=(SkeletonBone[])Method("GetSkeletonBones",1).Invoke(null,new object[]{instance.transform});
        }finally{UnityEngine.Object.DestroyImmediate(instance);}
        var changed=description.skeleton.Where(b=>original.Any(o=>o.name==b.name&&Quaternion.Angle(o.rotation,b.rotation)>.01f)).Select(b=>b.name).ToArray();
        Directory.CreateDirectory("Data/JiwooRigged/AvatarRepair");
        File.WriteAllText("Data/JiwooRigged/AvatarRepair/importer_before.json",EditorJsonUtility.ToJson(importer,true));
        importer.humanDescription=description;importer.SaveAndReimport();
        var updated=AssetDatabase.LoadAssetAtPath<GameObject>(Model);
        var animator=updated.GetComponent<Animator>();
        var newMesh=updated.GetComponentsInChildren<SkinnedMeshRenderer>(true).Single().sharedMesh;
        if(!animator.avatar||!animator.avatar.isHuman||!animator.avatar.isValid||!previousShapes.SequenceEqual(Enumerable.Range(0,newMesh.blendShapeCount).Select(newMesh.GetBlendShapeName)))throw new Exception("Avatar or shape integrity failed");
        var result=new{beforePoseError=before,afterPoseError=after,referenceTPoseValid=valid,changedReferenceBones=changed,
            avatarValid=animator.avatar.isValid,shapeCount=newMesh.blendShapeCount,sourceMeshReexported=false,animationsPlayed=false,playModeEntered=false};
        File.WriteAllText("Data/JiwooRigged/AvatarRepair/result.json",JsonConvert.SerializeObject(result,Formatting.Indented));
        return result;
    }
    public static object Inspect()
    {
        var type=typeof(Editor).Assembly.GetType("UnityEditor.AvatarSetupTool");
        var methods=type.GetMethods(BindingFlags.Static|BindingFlags.Public|BindingFlags.NonPublic)
            .Where(m=>new[]{"GetHumanBones","GetModelBones","MakePoseValid","IsPoseValid","GetPoseError","GetSkeletonBones","SampleBindPose","TransferDescriptionToPose"}.Contains(m.Name))
            .Select(m=>m.ToString()).ToArray();
        var importer=(ModelImporter)AssetImporter.GetAtPath(Model);
        var asset=AssetDatabase.LoadAssetAtPath<GameObject>(Model);
        var bones=asset.GetComponentsInChildren<Transform>(true);
        return new{playing=EditorApplication.isPlaying,methods,
            armBones=bones.Where(b=>b.name.StartsWith("DEF-upper_arm")||b.name.StartsWith("DEF-forearm")||b.name.StartsWith("DEF-hand")||b.name.StartsWith("DEF-shoulder"))
                .Select(b=>new{b.name,parent=b.parent.name,position=new{x=b.position.x,y=b.position.y,z=b.position.z}}).ToArray(),
            skeleton=importer.humanDescription.skeleton.Where(b=>b.name.Contains("upper_arm")||b.name.Contains("forearm")||b.name.Contains("hand"))
                .Select(b=>new{b.name,rotation=new{x=b.rotation.x,y=b.rotation.y,z=b.rotation.z,w=b.rotation.w}}).ToArray()};
    }
}
