"""Independent FBX/ABC readback, no source edits or Unity execution."""
import json
from pathlib import Path
import bpy
import numpy as np
from mathutils.kdtree import KDTree
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'Data/JiwooRigged/Batch02'
report=json.loads((OUT/'export_report.json').read_text())

def array(data,prop='co',n=3):
    a=np.empty(len(data)*n,np.float32);data.foreach_get(prop,a)
    return a.reshape(-1,n)

def world(p,m):
    m=np.array(m);return p@m[:3,:3].T+m[:3,3]

bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.fbx(filepath=str(OUT/'Jiwoo_Rigged.fbx'),use_anim=False,ignore_leaf_bones=False)
obj=next(o for o in bpy.data.objects if o.type=='MESH')
rig=next(o for o in bpy.data.objects if o.type=='ARMATURE')
baseline=np.load(OUT/'combined_blender_baseline.npz')
positions=world(array(obj.data.vertices),obj.matrix_world)
assert len(positions)==report['vertices']
mapping=np.arange(len(positions))
if np.max(np.linalg.norm(positions-baseline['Basis'],axis=1))>2e-5:
    tree=KDTree(len(baseline['Basis']))
    for i,p in enumerate(baseline['Basis']):tree.insert(p,i)
    tree.balance()
    mapping=np.array([tree.find(p)[1] for p in positions])
errors={}
for key in obj.data.shape_keys.key_blocks:
    errors[key.name]=float(np.max(np.linalg.norm(world(array(key.data),obj.matrix_world)-baseline[key.name][mapping],axis=1)))
assert max(errors.values())<2e-5,errors
assert len(rig.data.bones)==report['bones']
assert [k.name for k in obj.data.shape_keys.key_blocks]==['Basis']+report['shape_names']
assert [m.name for m in obj.data.materials]==report['material_names']
grooms=[]
for g in report['grooms']:
    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.ops.wm.alembic_import(filepath=str(OUT/g['filename']),scale=1,set_frame_range=False,as_background_job=False)
    bpy.context.view_layer.update()
    obj=next(o for o in bpy.data.objects if o.type=='CURVES')
    data=obj.evaluated_get(bpy.context.evaluated_depsgraph_get()).data
    actual=array(data.attributes['position'].data,'vector')
    expected=np.load(OUT/(g['label']+'_head_local.npy')).reshape(-1,3)[:,[0,2,1]].copy();expected[:,0]*=-1
    error=float(np.max(np.linalg.norm(actual-expected,axis=1)))
    diameter=array(data.attributes['radius'].data,'value',1)*2
    assert len(data.curves)==g['strands'] and error<2e-6
    assert np.max(np.abs(diameter-g['diameter_m']))<1e-8
    grooms.append({'label':g['label'],'strands':len(data.curves),'max_error_m':error,'diameter_m':float(diameter.max())})
result={'passed':True,'vertices':report['vertices'],'bones':report['bones'],'shape_count':len(errors)-1,
        'max_fbx_error_m':max(errors.values()),'grooms':grooms}
(OUT/'blender_readback.json').write_text(json.dumps(result,indent=2))
print('READBACK_VERIFIED '+json.dumps(result),flush=True)
