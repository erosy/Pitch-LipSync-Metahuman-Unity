using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using Newtonsoft.Json;

public static class AuditJiwooClothing
{
    const string Model="Assets/_Sandbox/Characters/Jiwoo New/Jiwoo_EthanSetup.fbx";
    const string Prefab="Assets/_Sandbox/Characters/Jiwoo/Jiwoo_Normalized.prefab";
    const string Output="Data/JiwooRigged/ClothingAudit";
    static Dictionary<string,float>[] Weights(SkinnedMeshRenderer r)
    {
        var mesh=r.sharedMesh;var counts=mesh.GetBonesPerVertex();var all=mesh.GetAllBoneWeights();
        var result=new Dictionary<string,float>[mesh.vertexCount];int offset=0;
        for(int i=0;i<result.Length;i++){
            var w=new Dictionary<string,float>();
            for(int j=0;j<counts[i];j++) {var entry=all[offset++];if(entry.weight>0)w[r.bones[entry.boneIndex].name]=entry.weight;}
            result[i]=w;
        }
        return result;
    }
    static float Difference(Dictionary<string,float> a,Dictionary<string,float> b)
        =>a.Keys.Union(b.Keys).Sum(k=>Mathf.Abs((a.TryGetValue(k,out var x)?x:0)-(b.TryGetValue(k,out var y)?y:0)));
    public static object Main() => Run(Output+"/unity_audit.json");
    public static object AfterRepair() => Run("Data/JiwooRigged/ClothingSeamRepair/unity_stress_after.json");
    public static object AfterWeightRepair() => Run("Data/JiwooRigged/ClothingWeightRepair/unity_stress_after.json");
    static object Run(string reportFile)
    {
        Directory.CreateDirectory(Output);
        var asset=AssetDatabase.LoadAssetAtPath<GameObject>(Model);
        var prefab=AssetDatabase.LoadAssetAtPath<GameObject>(Prefab);
        var imported=asset.GetComponentsInChildren<SkinnedMeshRenderer>(true).Single(r=>r.name=="Outfit");
        var renderer=prefab.GetComponentsInChildren<SkinnedMeshRenderer>(true).Single(r=>r.name=="Outfit");
        var positions=imported.sharedMesh.vertices;var weights=Weights(imported);
        var seamPairs=new List<(int a,int b,float gap,float difference)>();
        // 5k vertices permits a straightforward independent exhaustive duplicate
        // search, without depending on Blender vertex ordering or UV welding.
        for(int i=0;i<positions.Length;i++)for(int j=i+1;j<positions.Length;j++)
            if((positions[i]-positions[j]).sqrMagnitude<1e-8f)
                seamPairs.Add((i,j,Vector3.Distance(positions[i],positions[j]),Difference(weights[i],weights[j])));
        var bad=seamPairs.Where(p=>p.difference>.01f).ToArray();
        var stress=new List<object>();
        if(!EditorApplication.isPlayingOrWillChangePlaymode)
        {
            var clone=UnityEngine.Object.Instantiate(asset);clone.hideFlags=HideFlags.HideAndDontSave;
            try {
                clone.GetComponent<Animator>().enabled=false;
                var outfit=clone.GetComponentsInChildren<SkinnedMeshRenderer>(true).Single(r=>r.name=="Outfit");
                var neutral=new Mesh();outfit.BakeMesh(neutral,false);var neutralPositions=neutral.vertices;
                UnityEngine.Object.DestroyImmediate(neutral);
                foreach(var name in new[]{"DEF-shoulder.R","DEF-shoulder.L","DEF-spine.004"})
                {
                    var bone=clone.GetComponentsInChildren<Transform>(true).Single(t=>t.name==name);
                    var rotation=bone.localRotation;bone.localRotation=rotation*Quaternion.AngleAxis(20,Vector3.forward);
                    var mesh=new Mesh();outfit.BakeMesh(mesh,false);var p=mesh.vertices;
                    var ordered=seamPairs.Select(pair=>new {pair.a,pair.b,weightDifference=pair.difference,
                        neutralGapM=Vector3.Distance(neutralPositions[pair.a],neutralPositions[pair.b]),
                        posedGapM=Vector3.Distance(p[pair.a],p[pair.b]),
                        aWeights=weights[pair.a],bWeights=weights[pair.b]}).OrderByDescending(x=>x.posedGapM).ToArray();
                    stress.Add(new {bone=name,angleDegrees=20,axis="local Z",syntheticPose=true,
                        pairsOver1mm=ordered.Count(x=>x.posedGapM>.001f),worst=ordered.Take(5).ToArray()});
                    UnityEngine.Object.DestroyImmediate(mesh);bone.localRotation=rotation;
                }
            } finally {UnityEngine.Object.DestroyImmediate(clone);}
        }
        var importer=(ModelImporter)AssetImporter.GetAtPath(Model);
        var originalSource=renderer.sharedMaterials.Single();
        var result=new { playing=EditorApplication.isPlaying,model=Model,
            prefabUsesNewOutfit=renderer.sharedMesh==imported.sharedMesh,
            sourceAndPrefabBoneOrderMatch=renderer.bones.Select(b=>b.name).SequenceEqual(imported.bones.Select(b=>b.name)),
            vertices=positions.Length,nearCoincidentPairs=seamPairs.Count,mismatchedPairs=bad.Length,
            badPairs=bad.OrderByDescending(p=>p.difference).Take(20).Select(p=>new {p.a,p.b,p.gap,p.difference,aWeights=weights[p.a],bWeights=weights[p.b]}).ToArray(),
            importerSkinWeights=importer.skinWeights.ToString(),importer.maxBonesPerVertex,importer.minBoneWeight,
            rendererQuality=renderer.quality.ToString(),globalSkinWeights=QualitySettings.skinWeights.ToString(),
            maximumStoredInfluences=imported.sharedMesh.GetBonesPerVertex().Select(n=>(int)n).Max(),
            material=new {name=originalSource.name,shader=originalSource.shader.name,
                cull=originalSource.HasProperty("_Cull")?originalSource.GetFloat("_Cull"):-1,
                alphaClip=originalSource.HasProperty("_AlphaClip")?originalSource.GetFloat("_AlphaClip"):-1},
            stress,assetsModified=false,animationClipsSampled=false,playModeChanged=false};
        File.WriteAllText(reportFile,JsonConvert.SerializeObject(result,Formatting.Indented));
        return result;
    }
}
