"""Independent Unity ABC/HairAsset coordinate verification using Blender Python."""
import numpy as np, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'Data/JiwooRigged/ScalpRestore'
expected=np.load(ROOT/'Data/JiwooRigged/Batch02/Scalp_head_local.npy').reshape(-1,3)
source=json.loads((OUT/'source_bones.json').read_text());audit=json.loads((OUT/'unity_audit.json').read_text())
bones={b['name']:b for b in audit['bones']};names=sorted(source.keys()&bones.keys())
src=np.array([source[n] for n in names]);dst=np.array([bones[n]['position'] for n in names])
design=np.c_[src,np.ones(len(src))];conversion=np.linalg.lstsq(design,dst,rcond=None)[0]
bone_error=float(np.linalg.norm(design@conversion-dst,axis=1).max())
world=np.eye(4);world[:3,:]=conversion.T
fit=json.loads((OUT/'blender_fit.json').read_text())
frame=np.linalg.inv(np.array(audit['headMatrix']).reshape(4,4))@world@np.array(fit['head_matrix_blender'])
expected=expected@frame[:3,:3].T+frame[:3,3]
abc=np.fromfile(OUT/'unity_abc.bin',dtype='<f4').reshape(-1,3)
asset=np.fromfile(OUT/'unity_groom.bin',dtype='<f4').reshape(-1,3)
report={'abc_max_error_m':float(np.linalg.norm(abc-expected,axis=1).max()),
        'bone_conversion_error_m':bone_error,'head_local_frame_conversion':frame.tolist(),
        'hair_asset_max_error_m':float(np.linalg.norm(asset-expected,axis=1).max()),
        'bounds_m':[asset.min(0).tolist(),asset.max(0).tolist()],
        'particle_count':len(asset)}
# Face geometry was dumped head-local from the actual current FBX in the prefab.
from mathutils.kdtree import KDTree
face=np.fromfile(OUT/'unity_Face.bin',dtype='<f4').reshape(-1,3)
tree=KDTree(len(face))
for i,p in enumerate(face):tree.insert(p,i)
tree.balance()
dist=[tree.find(p)[2] for p in asset.reshape(-1,64,3)[:,0]]
report['root_nearest_current_fbx_vertex_percentiles_m']=np.percentile(dist,[0,50,95,100]).tolist()
from mathutils.bvhtree import BVHTree
tri=np.fromfile(OUT/'unity_Face_triangles.bin',dtype='<i4').reshape(-1,3)
bvh=BVHTree.FromPolygons(face.tolist(),tri.tolist(),all_triangles=True)
surfacedist=[bvh.find_nearest(p)[3] for p in asset.reshape(-1,64,3)[:,0]]
report['root_current_fbx_surface_distance_percentiles_m']=np.percentile(surfacedist,[0,50,95,100]).tolist()
report['passed']=bool(bone_error<2e-5 and report['abc_max_error_m']<2e-5 and report['hair_asset_max_error_m']<2e-5 and np.percentile(dist,95)<.006)
(OUT/'unity_fit_verification.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report),flush=True)
assert report['passed'],report
