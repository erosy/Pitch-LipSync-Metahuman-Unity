"""Measure actual post-import greeting geometry against the original samples."""
import json
import struct
from pathlib import Path
import bpy
import numpy as np
from mathutils import Vector
from mathutils.bvhtree import BVHTree
OUT=Path(__file__).resolve().parents[2]/'Data/JiwooRigged/ClothingWeightRepair'
def load(folder):
    metadata=json.loads((folder/'greeting_samples.json').read_text())
    frames=[]
    with (folder/'greeting_geometry.bin').open('rb') as f:
        count,nf,nc=struct.unpack('<iii',f.read(12))
        for _ in range(count):
            frames.append([np.frombuffer(f.read(n*12),dtype='<f4').reshape(n,3).copy() for n in (nf,nf,nc,nc)])
    return metadata,frames
before,original=load(OUT);after,actual=load(OUT/'After')
assert before['clipPath']==after['clipPath'] and before['times']==after['times']
tri=np.asarray(after['skinTriangles']).reshape(-1,3)
body_error=0.;metrics=[]
for i,(skin,normals,cloth,_) in enumerate(actual):
    body_error=max(body_error,float(np.linalg.norm(skin-original[i][0],axis=1).max()))
    bvh=BVHTree.FromPolygons(skin.tolist(),tri.tolist(),all_triangles=True)
    depths=[]
    for p in cloth:
        nearest,_,index,_=bvh.find_nearest(Vector(p))
        depths.append(max(0.,-float(np.dot(p-np.array(nearest),normals[tri[index]].mean(0)))))
    depths=np.array(depths)
    metrics.append({'time':after['times'][i],'vertices_inside_over_1mm':int(sum(depths>.001)),
        'vertices_inside_over_3mm':int(sum(depths>.003)),
        'max_depth_m':float(depths.max()),'depth_excess_over_1mm_sum_m':float(np.maximum(depths-.001,0).sum())})
    print('ACTUAL_GREETING_CHECK',i,flush=True)
assert body_error<.0001,body_error
comparison=json.loads((OUT/'weight_comparison.json').read_text())
score=sum(x['depth_excess_over_1mm_sum_m'] for x in metrics)
baseline=comparison['scores']['before']
assert score<baseline*.9,(score,baseline)
result={'passed':True,'clip':after['clip'],'sample_count':len(actual),'body_pose_max_difference_m':body_error,
    'before_depth_score_m':baseline,'after_depth_score_m':score,'depth_score_reduction_fraction':1-score/baseline,
    'before_vertex_frame_probes_over_1mm':sum(x['vertices_inside_over_1mm'] for x in comparison['metrics']['before']),
    'after_vertex_frame_probes_over_1mm':sum(x['vertices_inside_over_1mm'] for x in metrics),
    'metrics':metrics,'note':'Nearest-surface normal probes are comparative diagnostics, not visible-pixel counts or a guarantee against all intersections.'}
(OUT/'greeting_verification.json').write_text(json.dumps(result,indent=2))
print('GREETING_REPAIR_VERIFIED',json.dumps({k:v for k,v in result.items() if k not in ('metrics',)}),flush=True)
