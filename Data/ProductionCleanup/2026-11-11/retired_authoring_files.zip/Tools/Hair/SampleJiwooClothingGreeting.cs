using System;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEditor;
using UnityEngine.Playables;
using UnityEngine.Animations;
using Sandbox.CharacterSystem;
using Newtonsoft.Json;

public static class SampleJiwooClothingGreeting
{
    const string Model="Assets/_Sandbox/Characters/Jiwoo New/Jiwoo_EthanSetup.fbx";
    const string Output="Data/JiwooRigged/ClothingWeightRepair";
    public static object Main() => Sample(Output);
    public static object AfterRepair() => Sample(Output+"/After");
    static object Sample(string outputFolder)
    {
        if(EditorApplication.isPlayingOrWillChangePlaymode)throw new Exception("Edit Mode sampling only; do not change user Play Mode.");
        Directory.CreateDirectory(outputFolder);
        var activity=AssetDatabase.LoadAssetAtPath<ActivityDefinition>("Assets/_Sandbox/Data/Activity/Greeting.asset");
        var clip=activity.Animation.Clip;
        var model=UnityEngine.Object.Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>(Model));
        model.hideFlags=HideFlags.HideAndDontSave;
        var graph=PlayableGraph.Create("Disposable Jiwoo greeting samples");
        try {
            var animator=model.GetComponent<Animator>();animator.cullingMode=AnimatorCullingMode.AlwaysAnimate;animator.applyRootMotion=false;
            var cloth=model.GetComponentsInChildren<SkinnedMeshRenderer>(true).Single(r=>r.name=="Outfit");
            var face=model.GetComponentsInChildren<SkinnedMeshRenderer>(true).Single(r=>r.name=="Face");
            var bones=model.GetComponentsInChildren<Transform>(true).Where(t=>t.name.StartsWith("DEF-")).OrderBy(t=>t.name).ToArray();
            var binds=bones.Select(b=>Array.FindIndex(cloth.bones,x=>x==b)).Select((index,i)=>index>=0?
                cloth.sharedMesh.bindposes[index]:bones[i].worldToLocalMatrix*cloth.transform.localToWorldMatrix).ToArray();
            var slots=face.sharedMaterials.Select((m,i)=>new {m.name,index=i}).Where(m=>m.name=="Jiwoo_Body" || m.name=="Jiwoo_Head").ToArray();
            var triangles=slots.SelectMany(s=>face.sharedMesh.GetTriangles(s.index)).ToArray();
            var playable=AnimationClipPlayable.Create(graph,clip);playable.SetApplyFootIK(false);playable.SetApplyPlayableIK(false);
            var output=AnimationPlayableOutput.Create(graph,"Greeting",animator);output.SetSourcePlayable(playable);
            graph.SetTimeUpdateMode(DirectorUpdateMode.Manual);graph.Play();
            var times=Enumerable.Range(0,21).Select(i=>clip.length*.999f*i/20).ToArray();
            var matrices=new float[times.Length][][];
            using(var writer=new BinaryWriter(File.Create(outputFolder+"/greeting_geometry.bin")))
            {
                writer.Write(times.Length);writer.Write(face.sharedMesh.vertexCount);writer.Write(cloth.sharedMesh.vertexCount);
                for(int frame=0;frame<times.Length;frame++) {
                    playable.SetTime(times[frame]);graph.Evaluate(0);
                    foreach(var r in new[]{face,cloth}) {
                        var mesh=new Mesh();r.BakeMesh(mesh,false);
                        var positions=mesh.vertices;var normals=mesh.normals;
                        foreach(var p in positions) {var v=r.transform.TransformPoint(p);writer.Write(v.x);writer.Write(v.y);writer.Write(v.z);}
                        foreach(var n in normals) {var v=r.transform.TransformDirection(n).normalized;writer.Write(v.x);writer.Write(v.y);writer.Write(v.z);}
                        UnityEngine.Object.DestroyImmediate(mesh);
                    }
                    matrices[frame]=bones.Select((b,i)=>{
                        var m=b.localToWorldMatrix*binds[i];
                        return Enumerable.Range(0,16).Select(j=>m[j/4,j%4]).ToArray();
                    }).ToArray();
                }
            }
            var data=new {clip=clip.name,clipPath=AssetDatabase.GetAssetPath(clip),clip.length,times,
                faceVertices=face.sharedMesh.vertexCount,clothVertices=cloth.sharedMesh.vertexCount,
                skinTriangles=triangles,clothTriangles=cloth.sharedMesh.triangles,boneNames=bones.Select(b=>b.name).ToArray(),matrices,
                clothPositions=cloth.sharedMesh.vertices.Select(v=>new[]{v.x,v.y,v.z}).ToArray(),
                note="Manual PlayableGraph samples on a disposable model; no live character or Play Mode changes."};
            File.WriteAllText(outputFolder+"/greeting_samples.json",JsonConvert.SerializeObject(data));
            return new {clip=clip.name,samples=times.Length,clip.length,livePoseModified=false,playModeChanged=false};
        } finally {graph.Destroy();UnityEngine.Object.DestroyImmediate(model);}
    }
}
