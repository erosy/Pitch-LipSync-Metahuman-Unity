using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Security.Cryptography;
using UnityEngine;
using UnityEditor;
using UnityEditor.Events;
using UnityEditor.SceneManagement;
using Sandbox.CharacterSystem;
using Newtonsoft.Json;

public static class ConfigureJiwooSelection
{
    const string Prefab="Assets/_Sandbox/Characters/Jiwoo/Jiwoo_Normalized.prefab";
    const string Data="Assets/_Sandbox/Data/";
    const string Output="Data/JiwooRigged/Selection";
    static readonly Dictionary<string,string> Shapes=new Dictionary<string,string>{
        ["A"]="viseme_aa",["I"]="viseme_I",["U"]="viseme_U",["E"]="viseme_E",
        ["O"]="viseme_O",["S"]="viseme_SS",["M"]="viseme_PP",["N"]="viseme_nn"};
    static void Guard()
    {
        if(EditorApplication.isPlayingOrWillChangePlaymode)throw new Exception("Edit Mode required; no playback is performed.");
    }
    static T Reference<T>(UnityEngine.Object obj,string name) where T:UnityEngine.Object
        =>new SerializedObject(obj).FindProperty(name).objectReferenceValue as T;
    static void Set(UnityEngine.Object obj,string name,UnityEngine.Object value)
    {
        var data=new SerializedObject(obj);var p=data.FindProperty(name);
        if(p==null)throw new Exception("Missing field "+name);
        p.objectReferenceValue=value;data.ApplyModifiedPropertiesWithoutUndo();EditorUtility.SetDirty(obj);
        if(PrefabUtility.IsPartOfPrefabInstance(obj))PrefabUtility.RecordPrefabInstancePropertyModifications(obj);
    }
    static GameObject Root(string name)=>UnityEngine.SceneManagement.SceneManager.GetActiveScene().GetRootGameObjects().Single(r=>r.name==name);
    static UnityEngine.UI.Button Button(string name)=>UnityEngine.Object.FindObjectsByType<UnityEngine.UI.Button>(FindObjectsInactive.Include).Single(b=>b.name==name&&b.gameObject.scene.IsValid());
    static string Hash(string path){using(var sha=SHA256.Create())return BitConverter.ToString(sha.ComputeHash(File.ReadAllBytes(path))).Replace("-","");}
    static string Tuning(uLipSync.uLipSyncBlendShape driver)=>JsonConvert.SerializeObject(new{
        driver.maxBlendShapeValue,driver.minVolume,driver.maxVolume,driver.smoothness,driver.usePhonemeBlend,driver.updateMethod,
        gains=driver.blendShapes.ToDictionary(b=>b.phoneme,b=>b.maxWeight)});
    static string[] ProtectedFiles()=>new[]{"Assets/_Sandbox/Characters/Ethan/Ethan.prefab"}
        .Concat(Directory.GetFiles(Data,"*.asset",SearchOption.AllDirectories)).OrderBy(p=>p).ToArray();

    static void ConfigureResponse(GameObject root)
    {
        var shared=AssetDatabase.LoadAssetAtPath<CharacterFlowDefinition>(Data+"Flow/Response.asset");
        string pausePath=Data+"Flow/Jiwoo Idle Pause State.asset",flowPath=Data+"Flow/Jiwoo Response.asset";
        var pause=AssetDatabase.LoadAssetAtPath<ActivityFlowStateDefinition>(pausePath);
        if(!pause){pause=UnityEngine.Object.Instantiate((ActivityFlowStateDefinition)shared.States[1]);AssetDatabase.CreateAsset(pause,pausePath);}
        var p=new SerializedObject(pause);p.FindProperty("id").stringValue="state-jiwoo-idle-pause";p.FindProperty("displayName").stringValue="Jiwoo Idle Pause";
        p.FindProperty("useDefaultIdle").boolValue=true;p.FindProperty("duration").floatValue=1;p.ApplyModifiedPropertiesWithoutUndo();EditorUtility.SetDirty(pause);
        var response=AssetDatabase.LoadAssetAtPath<CharacterFlowDefinition>(flowPath);
        if(!response){response=UnityEngine.Object.Instantiate(shared);AssetDatabase.CreateAsset(response,flowPath);}
        var f=new SerializedObject(response);f.FindProperty("id").stringValue="flow-jiwoo-response";f.FindProperty("displayName").stringValue="Jiwoo Response";
        var states=f.FindProperty("states");states.arraySize=shared.States.Count;
        for(int i=0;i<shared.States.Count;i++)states.GetArrayElementAtIndex(i).objectReferenceValue=i==1?pause:shared.States[i];
        f.ApplyModifiedPropertiesWithoutUndo();EditorUtility.SetDirty(response);
        Set(root.GetComponent<CharacterFlowController>(),"responseFlow",response);
    }

    static void SeparateButtons()
    {
        var boy=(RectTransform)Button("Boy").transform;var girl=(RectTransform)Button("Girl").transform;
        if(boy.parent!=girl.parent)throw new Exception("Buttons require their existing common parent");
        Undo.RecordObject(girl,"Separate Girl and Boy buttons");
        girl.anchoredPosition=new Vector2(boy.anchoredPosition.x-(boy.rect.width-girl.rect.width)*.5f,
            boy.anchoredPosition.y-boy.rect.height*boy.pivot.y-12-girl.rect.height*(1-girl.pivot.y));
        EditorUtility.SetDirty(girl);
    }

    public static object Inspect()
    {
        Guard();
        var scene=UnityEngine.SceneManagement.SceneManager.GetActiveScene();
        return new{scene=scene.path,dirty=scene.isDirty,playing=EditorApplication.isPlaying,
            characters=new[]{Root("Ethan"),Root("Jiwoo_Normalized")}.Select(r=>new{name=r.name,active=r.activeSelf,
                flow=r.GetComponent<CharacterFlowController>()!=null,animator=r.GetComponent<Animator>()!=null}).ToArray(),
            buttons=new[]{Button("Boy"),Button("Girl")}.Select(b=>new{b.name,active=b.gameObject.activeSelf,enabled=b.enabled,
                calls=Enumerable.Range(0,b.onClick.GetPersistentEventCount()).Select(i=>b.onClick.GetPersistentMethodName(i)).ToArray()}).ToArray()};
    }

    static object ConfigureVoice(GameObject root)
    {
        var face=root.GetComponentsInChildren<SkinnedMeshRenderer>(true).Single(r=>r.name=="Face");
        var driver=face.GetComponent<uLipSync.uLipSyncBlendShape>();
        var lip=root.GetComponentsInChildren<uLipSync.uLipSync>(true).Single();
        var audio=lip.GetComponent<AudioSource>();
        var speech=root.GetComponent<CharacterSpeechPlayer>();
        var profile=AssetDatabase.LoadAssetAtPath<uLipSync.Profile>("Assets/_Sandbox/LipSync/Profile_Liora_ID.asset");
        var clip=AssetDatabase.LoadAssetAtPath<AudioClip>("Assets/_Sandbox/Audio/liora.mp3");
        if(!driver||!audio||!speech||!profile||!clip)throw new Exception("Jiwoo speech asset or component missing");
        foreach(var phoneme in Shapes.Keys)if(!profile.mfccs.Any(m=>m.name==phoneme))throw new Exception("Liora profile lacks "+phoneme);
        var before=Tuning(driver);
        foreach(var entry in Shapes)
        {
            int index=face.sharedMesh.GetBlendShapeIndex(entry.Value);
            if(index<0)throw new Exception("Jiwoo lacks shape "+entry.Value);
            var binding=driver.blendShapes.Single(b=>b.phoneme==entry.Key);binding.index=index;
        }
        driver.skinnedMeshRenderer=face;
        lip.profile=profile;lip.audioSourceProxy=null;
        lip.onLipSyncUpdate=new uLipSync.LipSyncUpdateEvent();
        UnityEventTools.AddPersistentListener(lip.onLipSyncUpdate,driver.OnLipSyncUpdate);
        audio.clip=clip;
        Set(speech,"audioSource",audio);Set(speech,"lipSync",lip);Set(speech,"clip",clip);Set(speech,"profile",profile);
        var expression=root.GetComponentsInChildren<ExpressionModule>(true).Single();
        Set(expression,"face",face);Set(expression,"lipSync",lip);Set(expression,"blendShapeDriver",driver);
        foreach(var obj in new UnityEngine.Object[]{driver,lip,audio})
        {EditorUtility.SetDirty(obj);if(PrefabUtility.IsPartOfPrefabInstance(obj))PrefabUtility.RecordPrefabInstancePropertyModifications(obj);}
        if(Tuning(driver)!=before)throw new Exception("Viseme tuning changed unexpectedly");
        return new{profile=AssetDatabase.GetAssetPath(profile),clip=AssetDatabase.GetAssetPath(clip),tuningPreserved=true,
            bindings=driver.blendShapes.Select(b=>new{phoneme=b.phoneme,shape=face.sharedMesh.GetBlendShapeName(b.index),gain=b.maxWeight}).ToArray()};
    }

    public static object Apply()
    {
        Guard();var scene=UnityEngine.SceneManagement.SceneManager.GetActiveScene();
        if(scene.path!="Assets/_Sandbox/Scenes/CharacterTesting.unity"||scene.isDirty)throw new Exception("Requires the saved CharacterTesting scene; preserve existing unsaved edits first.");
        var boy=Root("Ethan");var girl=Root("Jiwoo_Normalized");
        var boyFlow=boy.GetComponent<CharacterFlowController>();var girlFlow=girl.GetComponent<CharacterFlowController>();
        if(!boyFlow||!girlFlow)throw new Exception("Character flows missing");
        var fingerprints=ProtectedFiles().ToDictionary(p=>p,Hash);
        Directory.CreateDirectory(Output);
        File.WriteAllText(Output+"/protected_fingerprints.json",JsonConvert.SerializeObject(fingerprints,Formatting.Indented));
        var prefab=PrefabUtility.LoadPrefabContents(Prefab);object prefabVoice;
        try{prefabVoice=ConfigureVoice(prefab);ConfigureResponse(prefab);PrefabUtility.SaveAsPrefabAsset(prefab,Prefab);}
        finally{PrefabUtility.UnloadPrefabContents(prefab);}
        var sceneVoice=ConfigureVoice(girl);
        ConfigureResponse(girl);
        var selectors=UnityEngine.Object.FindObjectsByType<CharacterSelectionController>(FindObjectsInactive.Include).Where(c=>c.gameObject.scene==scene).ToArray();
        if(selectors.Length>1)throw new Exception("Multiple selection controllers");
        var selector=selectors.SingleOrDefault();
        if(!selector)
        {
            var obj=new GameObject("CharacterSelection");Undo.RegisterCreatedObjectUndo(obj,"Add character selection");
            selector=Undo.AddComponent<CharacterSelectionController>(obj);
        }
        SeparateButtons();
        Set(selector,"boy",boyFlow);Set(selector,"girl",girlFlow);
        foreach(var name in new[]{"Boy","Girl"})
        {
            var button=Button(name);Undo.RecordObject(button,"Wire character selection");
            for(int i=button.onClick.GetPersistentEventCount()-1;i>=0;i--)UnityEventTools.RemovePersistentListener(button.onClick,i);
            if(name=="Boy")UnityEventTools.AddPersistentListener(button.onClick,selector.SelectBoy);
            else UnityEventTools.AddPersistentListener(button.onClick,selector.SelectGirl);
            button.gameObject.SetActive(true);button.enabled=true;button.interactable=true;EditorUtility.SetDirty(button);
        }
        // Edit Mode persistence only: these components do not start their runtime
        // activation, audio or animation while Application.isPlaying is false.
        girl.SetActive(false);boy.SetActive(true);
        PrefabUtility.RecordPrefabInstancePropertyModifications(girl);PrefabUtility.RecordPrefabInstancePropertyModifications(boy);
        AssetDatabase.SaveAssets();EditorSceneManager.MarkSceneDirty(scene);
        if(!EditorSceneManager.SaveScene(scene))throw new Exception("Scene save failed");
        foreach(var entry in fingerprints)if(Hash(entry.Key)!=entry.Value)throw new Exception("Protected Ethan/shared asset changed: "+entry.Key);
        var result=new{applied=true,prefabVoice,sceneVoice,initialSelection="Ethan",liveTestingPerformed=false};
        File.WriteAllText(Output+"/configuration.json",JsonConvert.SerializeObject(result,Formatting.Indented));return result;
    }

    static object CheckVoice(GameObject root)
    {
        var face=root.GetComponentsInChildren<SkinnedMeshRenderer>(true).Single(r=>r.name=="Face");
        var driver=face.GetComponent<uLipSync.uLipSyncBlendShape>();
        var lip=root.GetComponentsInChildren<uLipSync.uLipSync>(true).Single();var speech=root.GetComponent<CharacterSpeechPlayer>();
        var audio=lip.GetComponent<AudioSource>();var character=root.GetComponent<Character>();var flow=root.GetComponent<CharacterFlowController>();
        if(driver.skinnedMeshRenderer!=face||Reference<AudioSource>(speech,"audioSource")!=audio||Reference<uLipSync.uLipSync>(speech,"lipSync")!=lip||lip.audioSourceProxy)throw new Exception("Cross-character or mismatched speech route");
        foreach(var obj in new Component[]{face,driver,lip,speech,audio})if(obj.GetComponentInParent<Character>(true)!=character)throw new Exception("Speech component belongs to another character");
        if(AssetDatabase.GetAssetPath(lip.profile)!="Assets/_Sandbox/LipSync/Profile_Liora_ID.asset"||Reference<uLipSync.Profile>(speech,"profile")!=lip.profile)throw new Exception("Incorrect Liora profile");
        if(AssetDatabase.GetAssetPath(Reference<AudioClip>(speech,"clip"))!="Assets/_Sandbox/Audio/liora.mp3"||audio.clip!=Reference<AudioClip>(speech,"clip")||audio.playOnAwake||audio.loop)throw new Exception("Incorrect voice configuration");
        if(lip.onLipSyncUpdate.GetPersistentEventCount()!=1||lip.onLipSyncUpdate.GetPersistentTarget(0)!=driver||lip.onLipSyncUpdate.GetPersistentMethodName(0)!="OnLipSyncUpdate")throw new Exception("Lip-sync listener mismatch");
        foreach(var entry in Shapes)
        {var binding=driver.blendShapes.Single(b=>b.phoneme==entry.Key);if(face.sharedMesh.GetBlendShapeName(binding.index)!=entry.Value||!lip.profile.mfccs.Any(m=>m.name==entry.Key))throw new Exception("Viseme mismatch: "+entry.Key);}
        var animator=root.GetComponent<Animator>();if(!animator.avatar||!animator.avatar.isHuman||!animator.avatar.isValid)throw new Exception("Invalid Humanoid");
        if(AssetDatabase.GetAssetPath(character.DefaultIdle.Animation.Clip)!="Assets/_Sandbox/Animations/Remy@Idle.fbx")throw new Exception("Idle clip mismatch");
        var greeting=Reference<CharacterFlowDefinition>(flow,"greetingFlow");var response=Reference<CharacterFlowDefinition>(flow,"responseFlow");
        if(greeting!=AssetDatabase.LoadAssetAtPath<CharacterFlowDefinition>(Data+"Flow/Greeting Flow.asset")||response!=AssetDatabase.LoadAssetAtPath<CharacterFlowDefinition>(Data+"Flow/Jiwoo Response.asset"))throw new Exception("Flow reference incorrect");
        var thinking=Reference<ActivityDefinition>(response.States[0],"activity");
        var greetingActivity=Reference<ActivityDefinition>(greeting.States[0],"activity");
        if(AssetDatabase.GetAssetPath(greetingActivity.Animation.Clip)!="Assets/_Sandbox/Animations/Remy@Waving.fbx")throw new Exception("Greeting animation mismatch");
        if(AssetDatabase.GetAssetPath(thinking.Animation.Clip)!="Assets/_Sandbox/Animations/Remy@Thinking.fbx")throw new Exception("Thinking clip mismatch");
        var pause=new SerializedObject(response.States[1]);if(!pause.FindProperty("useDefaultIdle").boolValue||Mathf.Abs(pause.FindProperty("duration").floatValue-1)>.0001f)throw new Exception("Idle pause mismatch");
        if(root.GetComponentsInChildren<Transform>(true).Any(t=>GameObjectUtility.GetMonoBehavioursWithMissingScriptCount(t.gameObject)>0))throw new Exception("Missing script");
        return new{root=root.name,validHumanoid=true,namedVisemes=Shapes.Count,profile=lip.profile.name,idle="Remy@Idle",thinking="Remy@Thinking",greeting=greeting.name,response=response.name,idlePauseSeconds=pause.FindProperty("duration").floatValue};
    }

    public static object Verify()
    {
        Guard();var boy=Root("Ethan");var girl=Root("Jiwoo_Normalized");
        var selector=UnityEngine.Object.FindObjectsByType<CharacterSelectionController>(FindObjectsInactive.Include).Single(c=>c.gameObject.scene.IsValid());
        if(!selector.isActiveAndEnabled||selector.transform.IsChildOf(boy.transform)||selector.transform.IsChildOf(girl.transform))throw new Exception("Selection controller must remain active outside both characters");
        if(Reference<CharacterFlowController>(selector,"boy")!=boy.GetComponent<CharacterFlowController>()||Reference<CharacterFlowController>(selector,"girl")!=girl.GetComponent<CharacterFlowController>())throw new Exception("Selector references incorrect");
        if(!boy.activeSelf||girl.activeSelf)throw new Exception("Startup selection incorrect");
        foreach(var name in new[]{"Boy","Girl"})
        {
            var b=Button(name);
            if(!b.gameObject.activeInHierarchy||!b.enabled||!b.interactable||b.onClick.GetPersistentEventCount()!=1||b.onClick.GetPersistentTarget(0)!=selector||b.onClick.GetPersistentMethodName(0)!="Select"+name)throw new Exception("Button binding incorrect: "+name);
            var rect=(RectTransform)b.transform;if(rect.rect.width<=0||rect.rect.height<=0)throw new Exception("Button has zero area");
        }
        var boyRect=(RectTransform)Button("Boy").transform;var girlRect=(RectTransform)Button("Girl").transform;
        var a=RectTransformUtility.CalculateRelativeRectTransformBounds(boyRect.parent,boyRect);
        var bBounds=RectTransformUtility.CalculateRelativeRectTransformBounds(boyRect.parent,girlRect);
        if(a.Intersects(bBounds))throw new Exception("Boy and Girl buttons overlap");
        var sceneVoice=CheckVoice(girl);object prefabVoice;var prefab=PrefabUtility.LoadPrefabContents(Prefab);
        try{prefabVoice=CheckVoice(prefab);}finally{PrefabUtility.UnloadPrefabContents(prefab);}
        var fingerprints=JsonConvert.DeserializeObject<Dictionary<string,string>>(File.ReadAllText(Output+"/protected_fingerprints.json"));
        foreach(var entry in fingerprints)if(Hash(entry.Key)!=entry.Value)throw new Exception("Ethan/shared definition changed: "+entry.Key);
        var result=new{passed=true,sceneVoice,prefabVoice,boyButton="SelectBoy",girlButton="SelectGirl",initialSelection="Ethan",protectedAssetsUnchanged=fingerprints.Count,playModeEntered=false,liveTestingPerformed=false};
        File.WriteAllText(Output+"/verification.json",JsonConvert.SerializeObject(result,Formatting.Indented));return result;
    }
}
