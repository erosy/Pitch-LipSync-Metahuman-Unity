"""Equalize coincident garment seam weights; preserve topology/UVs/shape keys.

Open Data/JiwooRigged/EthanReference/Jiwoo_EthanSetup.blend in safe background
Blender and run this script. Output is a separate candidate, never the source.
"""
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path
import bpy
import numpy as np
from mathutils.kdtree import KDTree

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'Data/JiwooRigged/ClothingSeamRepair'
OUT.mkdir(exist_ok=True)
source=Path(bpy.data.filepath)
assert source.name=='Jiwoo_EthanSetup.blend'
destination=OUT/'Jiwoo_EthanSetup_SeamFixed.blend'
assert not destination.exists(),'Refusing to overwrite a prepared repair file'
source_hash=hashlib.sha256(source.read_bytes()).hexdigest()
obj=bpy.data.objects['Outfit'];mesh=obj.data

def fingerprint(data):
    h=hashlib.sha256()
    for key in data.shape_keys.key_blocks:
        a=np.empty(len(key.data)*3,np.float32);key.data.foreach_get('co',a)
        h.update(key.name.encode());h.update(a.tobytes())
    for poly in data.polygons:
        h.update(np.array(list(poly.vertices)+[poly.material_index],np.int32).tobytes())
    for uv in data.uv_layers:
        a=np.empty(len(uv.data)*2,np.float32);uv.data.foreach_get('uv',a);h.update(a.tobytes())
    return h.hexdigest()

geometry_before=fingerprint(mesh)
face_before=fingerprint(bpy.data.objects['Face'].data)
points=np.array([obj.matrix_world@v.co for v in mesh.vertices])
edges=Counter()
for poly in mesh.polygons:
    ids=list(poly.vertices)
    for a,b in zip(ids,ids[1:]+ids[:1]):edges[tuple(sorted((a,b)))]+=1
boundary={i for edge,count in edges.items() if count==1 for i in edge}
tree=KDTree(len(boundary))
for i in boundary:tree.insert(points[i],i)
tree.balance()
parents=list(range(len(points)))
def find(i):
    while parents[i]!=i:parents[i]=parents[parents[i]];i=parents[i]
    return i
def union(i,j):parents[find(j)]=find(i)
pairs=[]
for i in sorted(boundary):
    for _,j,gap in tree.find_range(points[i],.0001):
        if j<=i or tuple(sorted((i,j))) in edges:continue
        pairs.append((i,j,gap));union(i,j)
clusters=defaultdict(list)
for i in boundary:clusters[find(i)].append(i)
clusters=[sorted(v) for v in clusters.values() if len(v)>1]
def weights(i):return {g.group:g.weight for g in mesh.vertices[i].groups if g.weight>0}
before=[weights(i) for i in range(len(points))]
def difference(a,b):return sum(abs(a.get(k,0)-b.get(k,0)) for k in a.keys()|b.keys())
bad_before=sum(difference(before[a],before[b])>.01 for a,b,_ in pairs)
assert bad_before>=400,'Expected clothing seam defect not found'
changes=[]
for ids in clusters:
    combined=defaultdict(float)
    for i in ids:
        for group,weight in before[i].items():combined[group]+=weight/len(ids)
    total=sum(combined.values());assert total>0
    combined={g:w/total for g,w in combined.items()}
    # Keep split vertices and UV islands. Equal skin weights keep them together
    # without welding collars, armholes, material boundaries, or layered fabric.
    for i in ids:
        if difference(before[i],combined)>1e-7:
            changes.append({'vertex':i,'before':{obj.vertex_groups[g].name:w for g,w in before[i].items()},
                            'after':{obj.vertex_groups[g].name:w for g,w in combined.items()}})
        for group in list(mesh.vertices[i].groups):obj.vertex_groups[group.group].remove([i])
    for group,w in combined.items():obj.vertex_groups[group].add(ids,w,'REPLACE')
after=[weights(i) for i in range(len(points))]
assert max(difference(after[a],after[b]) for a,b,_ in pairs)<1e-6
assert geometry_before==fingerprint(mesh),'Clothing geometry, UVs, or shapes changed'
assert face_before==fingerprint(bpy.data.objects['Face'].data),'Face changed'
assert all(abs(sum(w.values())-1)<1e-5 for w in after)
report={'source':str(source),'source_sha256':source_hash,'prepared':str(destination),
        'method':'Averaged normalized weights across connected clusters of non-edge-adjacent boundary vertices within 0.1 mm. No vertices welded, moved, or removed.',
        'boundary_pairs':len(pairs),'clusters':len(clusters),'modified_vertices':len(changes),
        'mismatched_pairs_before':bad_before,'mismatched_pairs_after':0,
        'maximum_retained_neutral_gap_m':max(gap for _,_,gap in pairs),
        'clothing_geometry_uv_shapes_sha256':geometry_before,'face_geometry_uv_shapes_sha256':face_before,
        'shape_count':len(mesh.shape_keys.key_blocks)-1,'vertex_count':len(mesh.vertices),
        'pairs':[{'a':a,'b':b,'neutral_gap_m':gap} for a,b,gap in pairs],
        'clusters_vertices':clusters,'weight_changes':changes}
(OUT/'repair_report.json').write_text(json.dumps(report,indent=2))
np.savez_compressed(OUT/'outfit_weights_baseline.npz',
    positions=points,bones=np.array([g.name for g in obj.vertex_groups]),
    weights=np.array([[w.get(g.index,0) for g in obj.vertex_groups] for w in after],np.float32))
bpy.context.preferences.filepaths.save_version=0
bpy.ops.wm.save_as_mainfile(filepath=str(destination))
bpy.ops.object.select_all(action='DESELECT')
rig=bpy.data.objects['Jiwoo_Armature']
for o in (rig,obj,bpy.data.objects['Face']):o.select_set(True)
bpy.context.view_layer.objects.active=rig
bpy.ops.export_scene.fbx(filepath=str(OUT/'Jiwoo_EthanSetup.fbx'),use_selection=True,
    object_types={'ARMATURE','MESH'},global_scale=1,apply_unit_scale=True,
    apply_scale_options='FBX_SCALE_UNITS',axis_forward='-Z',axis_up='Y',
    use_space_transform=True,bake_space_transform=False,use_mesh_modifiers=False,
    add_leaf_bones=False,primary_bone_axis='Y',secondary_bone_axis='X',
    use_armature_deform_only=False,bake_anim=False,mesh_smooth_type='FACE',
    path_mode='AUTO',embed_textures=False,use_custom_props=False)
assert hashlib.sha256(source.read_bytes()).hexdigest()==source_hash
print('SEAM_WEIGHTS_REPAIRED',json.dumps({k:report[k] for k in ['boundary_pairs','clusters','modified_vertices','mismatched_pairs_before','mismatched_pairs_after']}),flush=True)
