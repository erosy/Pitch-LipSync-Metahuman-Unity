"""Independent saved Blender and FBX readback, including facial hair binding."""
import json
from pathlib import Path
import bpy
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'Data/JiwooRigged/EthanReference'
report=json.loads((OUT/'preparation_report.json').read_text())
names=['Basis']+report['reference']['shape_names']

def coords(data):
    a=np.empty(len(data)*3,np.float32);data.foreach_get('co',a)
    return a.reshape(-1,3)

def world(p,m):
    m=np.array(m,np.float64);return p@m[:3,:3].T+m[:3,3]

def check(mode):
    face=bpy.data.objects['Face'];outfit=bpy.data.objects['Outfit']
    rig=face.modifiers[0].object
    assert len(rig.data.bones)==report['bones']
    results={}
    for obj,filename in [(face,'face_baseline.npz'),(outfit,'outfit_baseline.npz')]:
        base=np.load(OUT/filename)
        assert [k.name for k in obj.data.shape_keys.key_blocks]==names
        assert all(k.value==0 for k in obj.data.shape_keys.key_blocks[1:])
        assert len(obj.modifiers)==1 and obj.modifiers[0].type=='ARMATURE'
        assert obj.data.shape_keys.animation_data is None
        errors={};evaluation_errors={}
        for name in names:
            key=obj.data.shape_keys.key_blocks[name]
            actual=world(coords(key.data),obj.matrix_world)
            errors[name]=float(np.linalg.norm(actual-base[name],axis=1).max())
            if name!='Basis':key.value=1
            bpy.context.view_layer.update()
            ev=obj.evaluated_get(bpy.context.evaluated_depsgraph_get());mesh=ev.to_mesh()
            evaluation_errors[name]=float(np.linalg.norm(world(coords(mesh.vertices),ev.matrix_world)-base[name],axis=1).max())
            ev.to_mesh_clear()
            key.value=0
        assert max(errors.values())<2e-5,(mode,obj.name,max(errors.values()))
        assert max(evaluation_errors.values())<2e-5,(mode,obj.name,max(evaluation_errors.values()))
        weights=[]
        for v in obj.data.vertices:
            w={obj.vertex_groups[g.group].name:g.weight for g in v.groups if g.weight>0}
            assert w and abs(sum(w.values())-1)<1e-5,(obj.name,v.index,w)
            weights.append(w)
        results[obj.name]={'shape_count':len(names)-1,'vertices':len(obj.data.vertices),
            'max_shape_position_error_m':max(errors.values()),'max_evaluated_error_m':max(evaluation_errors.values())}
    sections={s['name']:s for s in report['face_sections']}
    assert 'Eyebrows' in sections and 'Eyelashes' in sections
    facebase=np.load(OUT/'face_baseline.npz')
    hair={}
    for label in ('Eyebrows','Eyelashes'):
        section=sections[label];start=section['start'];end=start+section['count']
        binding=np.load(OUT/(label+'_binding.npz'))
        tri=binding['triangles'];bary=binding['barycentric'];offsets=binding['local_offsets']
        def frames(p):
            t=p[tri];x=t[:,1]-t[:,0];x/=np.linalg.norm(x,axis=1)[:,None]
            z=np.cross(x,t[:,2]-t[:,0]);z/=np.linalg.norm(z,axis=1)[:,None]
            return np.stack((x,np.cross(z,x),z),axis=2)
        errors={}
        for name in names:
            hp=facebase[name]
            anchors=np.einsum('ni,nij->nj',bary,hp[tri])
            expected=(anchors[:,None,:]+np.einsum('nij,nkj->nki',frames(hp),offsets)).reshape(-1,3)
            errors[name]=float(np.linalg.norm(hp[start:end]-expected,axis=1).max())
        assert max(errors.values())<2e-6,(label,max(errors.values()))
        active='browInnerUp' if label=='Eyebrows' else 'eyeBlinkLeft'
        delta=facebase[active][start:end]-facebase['Basis'][start:end]
        assert np.linalg.norm(delta,axis=1).max()>1e-4,label
        hair[label]={'vertices':section['count'],'max_surface_following_error_m':max(errors.values())}
    head=sections['Prepared_head_lod0_mesh'];body=sections['Prepared_body_lod0_mesh']
    seam_max=0.
    for a,b in report['seam_pairs']:
        a+=head['start'];b+=body['start']
        wa={face.vertex_groups[g.group].name:g.weight for g in face.data.vertices[a].groups}
        wb={face.vertex_groups[g.group].name:g.weight for g in face.data.vertices[b].groups}
        assert max(abs(wa.get(k,0)-wb.get(k,0)) for k in wa.keys()|wb.keys())<1e-6
        for name in names:seam_max=max(seam_max,float(np.linalg.norm(facebase[name][a]-facebase[name][b])))
    assert seam_max<1e-7
    return {'meshes':results,'facial_hair':hair,'seam_max_gap_m':seam_max,'bones':len(rig.data.bones)}

# Compare the prepared neutral silhouette against a fresh, safe source load.
bpy.ops.wm.open_mainfile(filepath=report['source'],load_ui=False,use_scripts=False)
source_errors={}
base=np.load(OUT/'face_baseline.npz')
sections={s['name']:s for s in report['face_sections']}
for obj in bpy.data.objects:
    if obj.type!='MESH' or not obj.name.startswith('Jiwoo_MetaHumanCharacter_'):continue
    part='Prepared_'+obj.name.removeprefix('Jiwoo_MetaHumanCharacter_')
    if part not in sections:continue
    s=sections[part]
    ev=obj.evaluated_get(bpy.context.evaluated_depsgraph_get());mesh=ev.to_mesh()
    actual=world(coords(mesh.vertices),obj.matrix_world)
    source_errors[obj.name]=float(np.linalg.norm(actual-base['Basis'][s['start']:s['start']+s['count']],axis=1).max())
    ev.to_mesh_clear()
assert max(source_errors.values())<.0001,source_errors
bpy.ops.wm.open_mainfile(filepath=str(OUT/'Jiwoo_EthanSetup.blend'),load_ui=False,use_scripts=False)
results={'source_neutral_max_error_m':max(source_errors.values()),'source_neutral_per_mesh_m':source_errors,'blend':check('blend')}
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.fbx(filepath=str(OUT/'Jiwoo_EthanSetup.fbx'),use_anim=False,ignore_leaf_bones=False)
results['fbx']=check('fbx')
results['passed']=True
(OUT/'verification_report.json').write_text(json.dumps(results,indent=2))
print('ETHAN_SETUP_VERIFIED',json.dumps(results),flush=True)
