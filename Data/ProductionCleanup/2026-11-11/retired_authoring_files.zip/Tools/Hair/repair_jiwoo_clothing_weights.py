"""Transfer/smooth torso garment skin weights and evaluate greeting samples.
Writes a separate candidate. Does not modify the delivery or seam-fixed source.
"""
import hashlib
import itertools
import json
import struct
from pathlib import Path
import bpy
import numpy as np
from mathutils import Vector
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'Data/JiwooRigged/ClothingWeightRepair'
assert Path(bpy.data.filepath).name=='Jiwoo_EthanSetup_SeamFixed.blend'
target=OUT/'Jiwoo_EthanSetup_WeightsFixed.blend'
assert not target.exists(),'Refusing to overwrite an artist candidate'
source_hash=hashlib.sha256(Path(bpy.data.filepath).read_bytes()).hexdigest()
obj=bpy.data.objects['Outfit'];face=bpy.data.objects['Face']
samples=json.loads((OUT/'greeting_samples.json').read_text())
bone_names=samples['boneNames'];n=len(obj.data.vertices);nb=len(bone_names)
bp=np.array([face.matrix_world@v.co for v in face.data.vertices]);cp=np.array([obj.matrix_world@v.co for v in obj.data.vertices])
def weights(o):
    result=np.zeros((len(o.data.vertices),nb),np.float32)
    for v in o.data.vertices:
        for g in v.groups:
            name=o.vertex_groups[g.group].name
            if name in bone_names:result[v.index,bone_names.index(name)]=g.weight
    return result/result.sum(1)[:,None]
old=weights(obj);skin_weights=weights(face)
face.data.calc_loop_triangles()
skin_slots={i for i,m in enumerate(face.data.materials) if 'body_shader' in m.name or 'head_shader' in m.name}
tri=np.array([t.vertices[:] for t in face.data.loop_triangles if t.material_index in skin_slots],np.int32)
bvh=BVHTree.FromPolygons(bp.tolist(),tri.tolist(),all_triangles=True)
transferred=np.zeros_like(old);clearance=[]
for i,p in enumerate(cp):
    nearest,_,index,gap=bvh.find_nearest(Vector(p));ids=tri[index];a,b,c=bp[ids]
    vw=np.linalg.lstsq(np.column_stack((b-a,c-a)),np.array(nearest)-a,rcond=None)[0]
    bary=np.clip([1-sum(vw),*vw],0,1);bary/=bary.sum()
    transferred[i]=bary@skin_weights[ids];clearance.append(gap)
# This is a sleeveless torso garment. Keep torso/neck, shoulder, breast,
# pelvis and upper-arm influences; exclude jaw/ear/face/forearm/hand influences.
allowed=np.array([name.startswith(('DEF-spine','DEF-shoulder','DEF-breast','DEF-pelvis','DEF-upper_arm')) for name in bone_names])
def clean(w):
    w=w.copy();w[:,~allowed]=0
    assert np.all(w.sum(1)>0)
    return w/w.sum(1)[:,None]
transferred=clean(transferred)
seams=json.loads((ROOT/'Data/JiwooRigged/ClothingSeamRepair/repair_report.json').read_text())
parents=np.arange(n)
for cluster in seams['clusters_vertices']:
    for i in cluster:parents[i]=cluster[0]
unique=sorted(set(parents));lookup={key:i for i,key in enumerate(unique)}
group=np.array([lookup[i] for i in parents]);count=np.bincount(group)
adj=[set() for _ in unique]
for edge in obj.data.edges:
    a,b=group[list(edge.vertices)]
    if a!=b:adj[a].add(b);adj[b].add(a)
def smooth(w,iterations=2):
    collapsed=np.zeros((len(unique),nb),np.float64)
    np.add.at(collapsed,group,w);collapsed/=count[:,None]
    for _ in range(iterations):
        updated=collapsed.copy()
        for i,neighbors in enumerate(adj):
            if neighbors:updated[i]=.8*collapsed[i]+.2*collapsed[list(neighbors)].mean(0)
        collapsed=updated/collapsed.sum(1)[:,None]
    return collapsed[group].astype(np.float32)
# Find the exact signed-axis transform between Blender and imported mesh bases.
up=np.asarray(samples['clothPositions']);best=None
test_ids=np.linspace(0,n-1,128,dtype=int)
for perm in itertools.permutations(range(3)):
    for signs in itertools.product((-1,1),repeat=3):
        mapped=cp[:,perm]*signs;tree=KDTree(n)
        for i,p in enumerate(mapped):tree.insert(p,i)
        tree.balance();error=max(tree.find(up[i])[2] for i in test_ids)
        if best is None or error<best[0]:best=(error,perm,signs,tree)
assert best[0]<2e-6,best[0]
mapping=np.array([best[3].find(p)[1] for p in up])
assert max(best[3].find(p)[2] for p in up)<2e-6
def imported_weights(w):
    result=w[mapping].copy();result[result<.001]=0
    return result/result.sum(1)[:,None]
variants={'before':old,'cleaned_smoothed':smooth(clean(old)),
          'surface_transfer_50':smooth(.5*clean(old)+.5*transferred),
          'surface_transfer_100':smooth(transferred),
          'surface_transfer_seams_only':smooth(transferred,0)}
candidate_positions={};prediction_error=0.
with (OUT/'greeting_geometry.bin').open('rb') as f:
    frames,nf,nc=struct.unpack('<iii',f.read(12));assert nc==n
    geometry=[]
    for frame in range(frames):
        arrays=[]
        for size in (nf,nf,nc,nc):arrays.append(np.frombuffer(f.read(size*12),dtype='<f4').reshape(size,3).copy())
        geometry.append(arrays)
matrices=np.asarray(samples['matrices']).reshape(frames,nb,4,4)
homogeneous=np.column_stack((up,np.ones(n)))
metrics={key:[] for key in variants}
skin_triangles=np.asarray(samples['skinTriangles']).reshape(-1,3)
for frame,(skin,normals,actual,_) in enumerate(geometry):
    tree=BVHTree.FromPolygons(skin.tolist(),skin_triangles.tolist(),all_triangles=True)
    transformed=np.einsum('bij,vj->bvi',matrices[frame,:,:3,:],homogeneous)
    for label,w in variants.items():
        p=np.einsum('vb,bvi->vi',imported_weights(w),transformed)
        if label=='before':prediction_error=max(prediction_error,float(np.linalg.norm(p-actual,axis=1).max()))
        depths=[]
        for point in p:
            closest,normal,index,gap=tree.find_nearest(Vector(point))
            ids=skin_triangles[index]
            outward=normals[ids].mean(0)
            signed=float(np.dot(point-np.array(closest),outward))
            depths.append(max(0.,-signed))
        depth=np.array(depths)
        metrics[label].append({'time':samples['times'][frame],'vertices_inside_over_1mm':int(sum(depth>.001)),
            'vertices_inside_over_3mm':int(sum(depth>.003)),'max_depth_m':float(depth.max()),
            'depth_excess_over_1mm_sum_m':float(np.maximum(depth-.001,0).sum())})
    print('GREETING_WEIGHT_CHECK',frame,flush=True)
assert prediction_error<.00005,('Offline skin prediction differs from actual Unity BakeMesh',prediction_error)
scores={key:sum(x['depth_excess_over_1mm_sum_m'] for x in values) for key,values in metrics.items()}
chosen=min((key for key in variants if key!='before'),key=lambda key:scores[key])
summary={'scores':scores,'chosen':chosen,'prediction_error_m':prediction_error,'metrics':metrics}
(OUT/'weight_comparison.json').write_text(json.dumps(summary,indent=2))
assert scores[chosen]<scores['before']*.9,'No measurable improvement; do not install automatically'
assert max(x['max_depth_m'] for x in metrics[chosen])<=max(x['max_depth_m'] for x in metrics['before'])+.0001,'Worst penetration regressed'
w=variants[chosen]
for vertex in obj.data.vertices:
    for g in list(vertex.groups):obj.vertex_groups[g.group].remove([vertex.index])
for j,name in enumerate(bone_names):
    group_obj=obj.vertex_groups.get(name) or obj.vertex_groups.new(name=name)
    for i in np.flatnonzero(w[:,j]>1e-8):group_obj.add([int(i)],float(w[i,j]),'REPLACE')
for cluster in seams['clusters_vertices']:
    assert max(np.abs(w[i]-w[cluster[0]]).max() for i in cluster)<1e-7
np.savez_compressed(OUT/'outfit_weights_baseline.npz',positions=cp,
    bones=np.array(bone_names),weights=w)
(OUT/'repair_report.json').write_text(json.dumps({'source':bpy.data.filepath,'source_sha256':source_hash,
    'chosen':chosen,'scores':scores,'seam_clusters_preserved':len(seams['clusters_vertices']),
    'shape_count':73,'geometry_modified':False,'pairs':seams['pairs'],'unity_vertex_mapping':mapping.tolist()},indent=2))
bpy.context.preferences.filepaths.save_version=0
bpy.ops.wm.save_as_mainfile(filepath=str(target))
bpy.ops.object.select_all(action='DESELECT')
rig=bpy.data.objects['Jiwoo_Armature']
for o in (rig,obj,face):o.select_set(True)
bpy.context.view_layer.objects.active=rig
bpy.ops.export_scene.fbx(filepath=str(OUT/'Jiwoo_EthanSetup.fbx'),use_selection=True,
    object_types={'ARMATURE','MESH'},global_scale=1,apply_unit_scale=True,
    apply_scale_options='FBX_SCALE_UNITS',axis_forward='-Z',axis_up='Y',
    use_space_transform=True,bake_space_transform=False,use_mesh_modifiers=False,
    add_leaf_bones=False,primary_bone_axis='Y',secondary_bone_axis='X',
    use_armature_deform_only=False,bake_anim=False,mesh_smooth_type='FACE',
    path_mode='AUTO',embed_textures=False,use_custom_props=False)
print('CLOTHING_WEIGHTS_PREPARED',json.dumps({'chosen':chosen,'scores':scores}),flush=True)
