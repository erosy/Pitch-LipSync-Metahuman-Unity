using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Reflection;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using Newtonsoft.Json;
using Sandbox.CharacterSystem;
using Unity.DemoTeam.Hair;

public static class ReplaceJiwooPrefab
{
    const string Prefab = "Assets/_Sandbox/Characters/Jiwoo/Jiwoo_Normalized.prefab";
    const string Model = "Assets/_Sandbox/Characters/Jiwoo New/Jiwoo_EthanSetup.fbx";
    const string OldModel = "Assets/_Sandbox/Characters/Jiwoo/Jiwoo_Rigged.fbx";
    const string Output = "Data/JiwooRigged/EthanReference/PrefabReplacement";
    static string PathOf(Transform t, Transform root) => AnimationUtility.CalculateTransformPath(t, root);
    static object Describe(GameObject root)
    {
        var animator = root.GetComponent<Animator>();
        return new {
            name = root.name,
            children = root.GetComponentsInChildren<Transform>(true).Where(t => !t.name.StartsWith("DEF-"))
                .Select(t => new { path = PathOf(t, root.transform), active = t.gameObject.activeSelf }).ToArray(),
            components = root.GetComponentsInChildren<Component>(true).Where(c => c && !(c is Transform) && !(c is Renderer) && !(c is MeshFilter))
                .Select(c => new { path = PathOf(c.transform, root.transform), type = c.GetType().FullName }).ToArray(),
            renderers = root.GetComponentsInChildren<SkinnedMeshRenderer>(true).Select(r => new {
                path = PathOf(r.transform,root.transform), mesh = AssetDatabase.GetAssetPath(r.sharedMesh),
                vertices = r.sharedMesh ? r.sharedMesh.vertexCount : 0, shapes = r.sharedMesh ? r.sharedMesh.blendShapeCount : 0,
                materials = r.sharedMaterials.Select(m => m ? m.name : "<null>").ToArray()
            }).ToArray(),
            animator = animator ? new { controller = AssetDatabase.GetAssetPath(animator.runtimeAnimatorController),
                avatar = AssetDatabase.GetAssetPath(animator.avatar), valid = animator.avatar && animator.avatar.isValid,
                human = animator.avatar && animator.avatar.isHuman } : null
        };
    }
    public static object Audit()
    {
        Directory.CreateDirectory(Output);
        var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(Prefab);
        var model = AssetDatabase.LoadAssetAtPath<GameObject>(Model);
        var scenes = Enumerable.Range(0,SceneManager.sceneCount).Select(i => SceneManager.GetSceneAt(i))
            .Where(s => s.isLoaded).Select(s => new { s.path, s.isDirty,
                jiwoo = s.GetRootGameObjects().SelectMany(r=>r.GetComponentsInChildren<Animator>(true))
                    .Where(a=>a.name=="Jiwoo_Normalized").Select(a => new {
                        prefab = PrefabUtility.GetPrefabAssetPathOfNearestInstanceRoot(a.gameObject), details = Describe(a.gameObject)
                    }).ToArray() }).ToArray();
        var result = new { playing = EditorApplication.isPlayingOrWillChangePlaymode,
            prefab = Describe(prefab), model = Describe(model), scenes,
            oldImport = EditorJsonUtility.ToJson(AssetImporter.GetAtPath(OldModel)),
            newImport = EditorJsonUtility.ToJson(AssetImporter.GetAtPath(Model)) };
        File.WriteAllText(Output+"/audit.json",JsonConvert.SerializeObject(result,Formatting.Indented));
        return new { playing = EditorApplication.isPlayingOrWillChangePlaymode, scenes,
            prefab = Describe(prefab), model = Describe(model) };
    }

    static void Guard()
    {
        if (EditorApplication.isPlayingOrWillChangePlaymode)
            throw new Exception("Edit Mode required; the user controls Play Mode.");
        Directory.CreateDirectory(Output);
    }
    public static object InspectImport()
    {
        var importer=(ModelImporter)AssetImporter.GetAtPath(Model);
        var asset=AssetDatabase.LoadAssetAtPath<GameObject>(Model);
        var animator=asset.GetComponent<Animator>();
        var result=new { importer.animationType,importer.avatarSetup,importer.importAnimation,
            animator=animator?animator.name:null, avatar=animator&&animator.avatar?animator.avatar.name:null,
            valid=animator&&animator.avatar&&animator.avatar.isValid,
            human=animator&&animator.avatar&&animator.avatar.isHuman,
            subAssets=AssetDatabase.LoadAllAssetsAtPath(Model).Where(o=>o is Avatar).Select(o=>new {o.name,valid=((Avatar)o).isValid,human=((Avatar)o).isHuman}).ToArray(),
            skeleton=importer.humanDescription.skeleton.Take(4).Select(b=>new { b.name,position=b.position.ToString(),scale=b.scale.ToString(),rotation=b.rotation.eulerAngles.ToString() }).ToArray(),
            bones=asset.GetComponentsInChildren<Transform>(true).Where(t=>t.name.StartsWith("DEF-upper_arm") || t.name=="Jiwoo_Armature").Select(t=>new {t.name,parent=t.parent.name}).ToArray() };
        return result;
    }
    static void Backup(string path)
    {
        var dest=Output+"/Before/"+path;
        Directory.CreateDirectory(Path.GetDirectoryName(dest));
        if (File.Exists(path) && !File.Exists(dest)) File.Copy(path,dest);
        if (File.Exists(path+".meta") && !File.Exists(dest+".meta")) File.Copy(path+".meta",dest+".meta");
    }
    public static object ConfigureImport()
    {
        Guard(); Backup(Model);
        var previous=(ModelImporter)AssetImporter.GetAtPath(OldModel);
        var importer=(ModelImporter)AssetImporter.GetAtPath(Model);
        var description=previous.humanDescription;
        importer.globalScale=previous.globalScale; importer.useFileScale=previous.useFileScale;
        importer.bakeAxisConversion=previous.bakeAxisConversion;
        importer.meshCompression=ModelImporterMeshCompression.Off;importer.isReadable=true;
        importer.skinWeights=ModelImporterSkinWeights.Custom;importer.maxBonesPerVertex=32;importer.minBoneWeight=.0001f;
        importer.importBlendShapes=true;importer.optimizeGameObjects=false;
        importer.importAnimation=false;importer.importCameras=false;importer.importLights=false;
        importer.animationType=ModelImporterAnimationType.Generic;
        importer.SaveAndReimport();
        var neutral=UnityEngine.Object.Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>(Model));
        neutral.hideFlags=HideFlags.HideAndDontSave;
        bool poseValid;
        try
        {
            // Build the new avatar's T-pose on a disposable neutral instance;
            // no animation clips are sampled or played.
            var setup=typeof(Editor).Assembly.GetType("UnityEditor.AvatarSetupTool");
            var methods=setup.GetMethods(BindingFlags.Static|BindingFlags.Public|BindingFlags.NonPublic);
            var bones=methods.Single(m=>m.Name=="GetModelBones"&&m.GetParameters().Length==3)
                .Invoke(null,new object[]{neutral.transform,false,null});
            var wrappers=methods.Single(m=>m.Name=="GetHumanBones"&&m.GetParameters()[0].ParameterType==typeof(Dictionary<string,string>))
                .Invoke(null,new object[]{description.human.ToDictionary(h=>h.humanName,h=>h.boneName),bones});
            methods.Single(m=>m.Name=="MakePoseValid").Invoke(null,new[]{wrappers});
            poseValid=(bool)methods.Single(m=>m.Name=="IsPoseValid").Invoke(null,new[]{wrappers});
            if(!poseValid)throw new Exception("Could not calibrate a valid new avatar reference T-pose.");
            description.skeleton=(SkeletonBone[])methods.Single(m=>m.Name=="GetSkeletonBones")
                .Invoke(null,new object[]{neutral.transform});
        }
        finally{UnityEngine.Object.DestroyImmediate(neutral);}
        importer.avatarSetup=ModelImporterAvatarSetup.CreateFromThisModel;
        importer.humanDescription=description;
        importer.animationType=ModelImporterAnimationType.Human;
        importer.SaveAndReimport();
        var model=AssetDatabase.LoadAssetAtPath<GameObject>(Model);
        var animator=model.GetComponent<Animator>();
        if(!animator || !animator.avatar || !animator.avatar.isValid || !animator.avatar.isHuman)
            throw new Exception("New model does not have a valid Humanoid avatar.");
        var result=new { avatarValid=animator.avatar.isValid, humanoid=animator.avatar.isHuman,
            humanBones=importer.humanDescription.human.Length, calibratedFrom=OldModel,referenceTPoseValid=poseValid,
            rootScale=model.transform.localScale.ToString(), bakeAxisConversion=importer.bakeAxisConversion,
            bones=model.GetComponentsInChildren<Transform>(true).Count(t=>t.name.StartsWith("DEF-")),
            sceneRoots=Enumerable.Range(0,SceneManager.sceneCount).SelectMany(i=>SceneManager.GetSceneAt(i).GetRootGameObjects())
                .Select(r=>r.name).ToArray() };
        File.WriteAllText(Output+"/import_configuration.json",JsonConvert.SerializeObject(result,Formatting.Indented));
        return result;
    }

    static void SetRef(UnityEngine.Object target,string field,UnityEngine.Object value)
    {
        var so=new SerializedObject(target);var p=so.FindProperty(field);
        if(p==null)throw new Exception("Missing serialized property: "+field);
        p.objectReferenceValue=value;so.ApplyModifiedPropertiesWithoutUndo();EditorUtility.SetDirty(target);
    }

    static Dictionary<string,string> Configuration(GameObject root)
    {
        // These components own activities, animation clips, speech, emotion and
        // selection-facing flow settings; preserve them byte-for-byte.
        var types=new[]{typeof(Character),typeof(AnimationModule),typeof(ExpressionModule),
            typeof(CharacterSpeechPlayer),typeof(CharacterFlowController),typeof(AudioSource),
            typeof(uLipSync.uLipSync),typeof(uLipSync.uLipSyncMicrophone)};
        return root.GetComponentsInChildren<Component>(true).Where(c=>c && types.Contains(c.GetType()))
            .ToDictionary(c=>PathOf(c.transform,root.transform)+":"+c.GetType().FullName,c=>EditorJsonUtility.ToJson(c));
    }

    static object Swap(GameObject root,GameObject source,bool undo)
    {
        if(undo)Undo.RegisterFullObjectHierarchyUndo(root,"Replace Jiwoo model, preserve animations");
        var before=Configuration(root);
        var animator=root.GetComponent<Animator>();
        var controller=animator.runtimeAnimatorController;
        var face=root.GetComponentsInChildren<SkinnedMeshRenderer>(true).Single(r=>r.name=="Face");
        var driver=face.GetComponent<uLipSync.uLipSyncBlendShape>();
        var visemes=driver.blendShapes.Select(b=>face.sharedMesh.GetBlendShapeName(b.index)).ToArray();
        var imported=source.GetComponentsInChildren<SkinnedMeshRenderer>(true);
        var sourceFace=imported.Single(r=>r.name=="Face");
        var sourceOutfit=imported.Single(r=>r.name=="Outfit");
        var sourceRig=source.transform.Find("Jiwoo_Armature");
        var targetRig=root.transform.Find("Jiwoo_Armature");
        if(!targetRig || !sourceRig)throw new Exception("Missing deform skeleton.");
        var sourceBones=sourceRig.GetComponentsInChildren<Transform>(true).Where(t=>t==sourceRig || t.name.StartsWith("DEF-")).ToDictionary(t=>t.name);
        var targetBones=targetRig.GetComponentsInChildren<Transform>(true).Where(t=>t==targetRig || t.name.StartsWith("DEF-")).ToDictionary(t=>t.name);
        if(!sourceBones.Keys.OrderBy(n=>n).SequenceEqual(targetBones.Keys.OrderBy(n=>n)))
            throw new Exception("Skeleton bone names differ; cannot preserve existing references.");
        foreach(var pair in sourceBones)
        {
            var src=pair.Value;var dst=targetBones[pair.Key];
            if(src!=sourceRig && src.parent.name!=dst.parent.name)throw new Exception("Skeleton hierarchy mismatch: "+src.name);
        }
        var expectedNames=Enumerable.Range(0,sourceFace.sharedMesh.blendShapeCount).Select(sourceFace.sharedMesh.GetBlendShapeName).ToArray();
        if(expectedNames.Length!=73 || visemes.Any(n=>!expectedNames.Contains(n)))throw new Exception("Facial shape interface mismatch.");
        foreach(var pair in sourceBones)
        {
            var dst=targetBones[pair.Key];var src=pair.Value;
            dst.localPosition=src.localPosition;dst.localRotation=src.localRotation;dst.localScale=src.localScale;
            if(undo && PrefabUtility.IsPartOfPrefabInstance(dst))PrefabUtility.RecordPrefabInstancePropertyModifications(dst);
        }
        Action<SkinnedMeshRenderer,SkinnedMeshRenderer> bind=(dst,src)=> {
            dst.transform.localPosition=src.transform.localPosition;dst.transform.localRotation=src.transform.localRotation;
            dst.transform.localScale=src.transform.localScale;
            dst.sharedMesh=src.sharedMesh;dst.sharedMaterials=src.sharedMaterials;
            dst.bones=src.bones.Select(b=>targetBones[b.name]).ToArray();dst.rootBone=targetBones[src.rootBone.name];
            dst.localBounds=src.localBounds;dst.quality=SkinQuality.Auto;dst.enabled=true;
            for(int i=0;i<dst.sharedMesh.blendShapeCount;i++)dst.SetBlendShapeWeight(i,0);
            EditorUtility.SetDirty(dst);
            if(undo && PrefabUtility.IsPartOfPrefabInstance(dst))PrefabUtility.RecordPrefabInstancePropertyModifications(dst);
        };
        bind(face,sourceFace);
        var outfit=root.transform.Find("Outfit")?.GetComponent<SkinnedMeshRenderer>();
        if(!outfit)
        {
            var go=new GameObject("Outfit");go.transform.SetParent(root.transform,false);
            go.layer=face.gameObject.layer;
            if(undo)Undo.RegisterCreatedObjectUndo(go,"Install Jiwoo outfit");
            outfit=go.AddComponent<SkinnedMeshRenderer>();
        }
        bind(outfit,sourceOutfit);
        animator.avatar=source.GetComponent<Animator>().avatar;
        if(animator.runtimeAnimatorController!=controller)throw new Exception("Animation controller unexpectedly changed.");
        EditorUtility.SetDirty(animator);
        if(undo && PrefabUtility.IsPartOfPrefabInstance(animator))PrefabUtility.RecordPrefabInstancePropertyModifications(animator);
        for(int i=0;i<visemes.Length;i++)driver.blendShapes[i].index=face.sharedMesh.GetBlendShapeIndex(visemes[i]);
        driver.skinnedMeshRenderer=face;EditorUtility.SetDirty(driver);
        if(undo && PrefabUtility.IsPartOfPrefabInstance(driver))PrefabUtility.RecordPrefabInstancePropertyModifications(driver);
        var readiness=root.GetComponent<CharacterReadiness>();
        if(readiness){SetRef(readiness,"startupWarmup",null);SetRef(readiness,"hairFallback",null);
            if(undo && PrefabUtility.IsPartOfPrefabInstance(readiness))PrefabUtility.RecordPrefabInstancePropertyModifications(readiness);}
        Action<UnityEngine.Object> destroy=o=>{if(undo)Undo.DestroyObjectImmediate(o);else UnityEngine.Object.DestroyImmediate(o);};
        foreach(var component in root.GetComponents<FacialGroomSurfaceBinding>())destroy(component);
        foreach(var component in root.GetComponents<CharacterHairFallback>())destroy(component);
        foreach(var component in root.GetComponents<CharacterHairStartupWarmup>())destroy(component);
        foreach(var groom in root.GetComponentsInChildren<HairInstance>(true))destroy(groom.gameObject);
        foreach(var boundary in root.GetComponentsInChildren<HairBoundary>(true))destroy(boundary.gameObject);
        var after=Configuration(root);
        var changed=before.Keys.Where(k=>!after.TryGetValue(k,out var value) || before[k]!=value).ToArray();
        if(changed.Length>0)throw new Exception("Animation/voice/flow configuration changed: "+string.Join(", ",changed));
        // The scene intentionally starts Jiwoo inactive while Ethan is selected.
        // Validate an active disposable copy without changing that selection.
        var validation=UnityEngine.Object.Instantiate(root);
        validation.hideFlags=HideFlags.HideAndDontSave;
        SceneManager.MoveGameObjectToScene(validation,SceneManager.GetActiveScene());
        List<string> errors;
        try {
            validation.SetActive(true);
            errors=validation.GetComponent<Character>().ValidateConfiguration();
            errors.AddRange(validation.GetComponent<CharacterFlowController>().ValidateConfiguration());
            validation.GetComponent<CharacterReadiness>()?.ValidateConfiguration(errors);
        } finally {UnityEngine.Object.DestroyImmediate(validation);}
        if(errors.Count>0)throw new Exception("Character configuration invalid: "+string.Join("; ",errors));
        if(root.GetComponentsInChildren<HairInstance>(true).Length!=0)throw new Exception("Groom remained in replacement.");
        if(!readiness || !readiness.IsReady)throw new Exception("Hairless character must be ready without groom warmup.");
        var maximum=0f;
        foreach(var pair in new[]{(face,sourceFace),(outfit,sourceOutfit)})
        {
            var actual=new Mesh();var expected=new Mesh();pair.Item1.BakeMesh(actual,false);pair.Item2.BakeMesh(expected,false);
            try {
                var a=actual.vertices;var b=expected.vertices;if(a.Length!=b.Length)throw new Exception("Bake vertex count differs.");
                for(int i=0;i<a.Length;i++) {
                    var p=root.transform.InverseTransformPoint(pair.Item1.transform.TransformPoint(a[i]));
                    var q=source.transform.InverseTransformPoint(pair.Item2.transform.TransformPoint(b[i]));
                    maximum=Mathf.Max(maximum,Vector3.Distance(p,q));
                }
            } finally {UnityEngine.Object.DestroyImmediate(actual);UnityEngine.Object.DestroyImmediate(expected);}
        }
        if(maximum>.0001f)throw new Exception("Skin binding mismatch exceeds 0.1 mm: "+maximum);
        return new { preservedConfigurationComponents=before.Count,visemeCount=visemes.Length,
            shapeCount=face.sharedMesh.blendShapeCount,bodyBones=sourceBones.Count-1,
            neutralSkinErrorM=maximum,avatarValid=animator.avatar.isValid,humanoid=animator.avatar.isHuman,
            hairInstances=0,ready=readiness.IsReady,configurationErrors=errors.ToArray() };
    }

    public static object Apply()
    {
        Guard();Backup(Prefab);
        var stage=PrefabStageUtility.GetCurrentPrefabStage();
        if(stage && stage.assetPath==Prefab)throw new Exception("Close the Jiwoo prefab stage before replacing its asset.");
        var model=AssetDatabase.LoadAssetAtPath<GameObject>(Model);
        var source=UnityEngine.Object.Instantiate(model);source.name=model.name;source.hideFlags=HideFlags.HideAndDontSave;
        var scenes=Enumerable.Range(0,SceneManager.sceneCount).Select(i=>SceneManager.GetSceneAt(i)).Where(s=>s.isLoaded && !EditorSceneManager.IsPreviewScene(s)).ToArray();
        var roots=scenes.SelectMany(s=>s.GetRootGameObjects()).SelectMany(r=>r.GetComponentsInChildren<Animator>(true))
            .Where(a=>a.name=="Jiwoo_Normalized").Select(a=>a.gameObject).ToArray();
        foreach(var scene in roots.Select(r=>r.scene).Distinct())
        {
            Backup(scene.path);
            var snapshot=Output+"/"+Path.GetFileNameWithoutExtension(scene.path)+"_working_before.unity";
            if(!File.Exists(snapshot) && !EditorSceneManager.SaveScene(scene,snapshot,true))throw new Exception("Cannot preserve unsaved scene snapshot.");
        }
        object prefabResult;
        try
        {
            var content=PrefabUtility.LoadPrefabContents(Prefab);
            try {prefabResult=Swap(content,source,false);PrefabUtility.SaveAsPrefabAsset(content,Prefab);}
            finally {PrefabUtility.UnloadPrefabContents(content);}
            var sceneResults=new List<object>();
            Undo.IncrementCurrentGroup();int group=Undo.GetCurrentGroup();Undo.SetCurrentGroupName("Replace Jiwoo with native facial bake");
            foreach(var root in roots)
            {
                sceneResults.Add(new { scene=root.scene.path,result=Swap(root,source,true) });
                EditorSceneManager.MarkSceneDirty(root.scene);
            }
            var disabledPreviews=new List<string>();
            foreach(var scene in roots.Select(r=>r.scene).Distinct())
                foreach(var preview in scene.GetRootGameObjects().Where(r=>r.name=="Jiwoo_EthanSetup" &&
                    PrefabUtility.GetPrefabAssetPathOfNearestInstanceRoot(r)==Model && r.activeSelf))
                {
                    Undo.RecordObject(preview,"Disable standalone Jiwoo model preview");
                    preview.SetActive(false);PrefabUtility.RecordPrefabInstancePropertyModifications(preview);
                    disabledPreviews.Add(scene.path+":"+preview.name);
                }
            Undo.CollapseUndoOperations(group);
            AssetDatabase.SaveAssets();
            var result=new {passed=true,prefab=Prefab,model=Model,prefabResult,scenes=sceneResults,disabledPreviews,sceneSaved=false};
            File.WriteAllText(Output+"/replacement_report.json",JsonConvert.SerializeObject(result,Formatting.Indented));
            Selection.activeObject=AssetDatabase.LoadAssetAtPath<GameObject>(Prefab);
            return result;
        }
        finally {UnityEngine.Object.DestroyImmediate(source);}
    }

    public static object Verify()
    {
        Guard();
        var asset=AssetDatabase.LoadAssetAtPath<GameObject>(Prefab);
        var dependencies=AssetDatabase.GetDependencies(Prefab,true);
        if(dependencies.Any(p=>p.EndsWith(".abc",StringComparison.OrdinalIgnoreCase)))
            throw new Exception("Saved prefab still depends on Alembic hair.");
        if(!dependencies.Contains(Model) || dependencies.Contains(OldModel))
            throw new Exception("Saved prefab does not exclusively reference the new model.");
        var checks=new List<object>();
        var roots=new List<GameObject>{asset};
        roots.AddRange(Enumerable.Range(0,SceneManager.sceneCount).Select(i=>SceneManager.GetSceneAt(i))
            .Where(s=>s.isLoaded&&!EditorSceneManager.IsPreviewScene(s)).SelectMany(s=>s.GetRootGameObjects())
            .Where(r=>r.name=="Jiwoo_Normalized"));
        foreach(var root in roots)
        {
            var face=root.GetComponentsInChildren<SkinnedMeshRenderer>(true).Single(r=>r.name=="Face");
            var outfit=root.GetComponentsInChildren<SkinnedMeshRenderer>(true).Single(r=>r.name=="Outfit");
            if(new[]{face,outfit}.Any(r=>AssetDatabase.GetAssetPath(r.sharedMesh)!=Model || r.sharedMesh.blendShapeCount!=73 || r.bones.Any(b=>!b)))
                throw new Exception("New meshes/bones not persisted on "+root.name);
            if(root.GetComponentsInChildren<Transform>(true).Any(t=>GameObjectUtility.GetMonoBehavioursWithMissingScriptCount(t.gameObject)>0))
                throw new Exception("Missing MonoBehaviour in saved character.");
            if(root.GetComponentsInChildren<HairInstance>(true).Length!=0 || root.GetComponent<FacialGroomSurfaceBinding>())
                throw new Exception("Old hair components remain.");
            var animator=root.GetComponent<Animator>();
            if(!animator.avatar || !animator.avatar.isHuman || !animator.avatar.isValid || AssetDatabase.GetAssetPath(animator.avatar)!=Model)
                throw new Exception("Wrong avatar after replacement.");
            var module=root.GetComponentInChildren<AnimationModule>(true);
            var expression=root.GetComponentInChildren<ExpressionModule>(true);
            if(module.Animator!=animator || expression.Face!=face || face.GetComponent<uLipSync.uLipSyncBlendShape>().skinnedMeshRenderer!=face)
                throw new Exception("Animation/expression/lip-sync references changed.");
            checks.Add(new { asset=EditorUtility.IsPersistent(root),rootActive=root.activeSelf,
                avatar=AssetDatabase.GetAssetPath(animator.avatar),faceVertices=face.sharedMesh.vertexCount,
                outfitVertices=outfit.sharedMesh.vertexCount,shapeCount=face.sharedMesh.blendShapeCount,
                readiness=root.GetComponent<CharacterReadiness>().IsReady });
        }
        var importer=(ModelImporter)AssetImporter.GetAtPath(Model);
        var model=AssetDatabase.LoadAssetAtPath<GameObject>(Model);
        var temporary=UnityEngine.Object.Instantiate(model);temporary.hideFlags=HideFlags.HideAndDontSave;
        bool tpose;
        try {
            var setup=typeof(Editor).Assembly.GetType("UnityEditor.AvatarSetupTool");
            var methods=setup.GetMethods(BindingFlags.Static|BindingFlags.Public|BindingFlags.NonPublic);
            methods.Single(m=>m.Name=="TransferDescriptionToPose" && m.GetParameters().Length==2)
                .Invoke(null,new object[]{new SerializedObject(importer),temporary.transform});
            var bones=methods.Single(m=>m.Name=="GetModelBones" && m.GetParameters().Length==3)
                .Invoke(null,new object[]{temporary.transform,false,null});
            var wrappers=methods.Single(m=>m.Name=="GetHumanBones" && m.GetParameters()[0].ParameterType==typeof(Dictionary<string,string>))
                .Invoke(null,new object[]{importer.humanDescription.human.ToDictionary(h=>h.humanName,h=>h.boneName),bones});
            tpose=(bool)methods.Single(m=>m.Name=="IsPoseValid").Invoke(null,new[]{wrappers});
            if(!tpose)throw new Exception("Saved avatar reference T-pose invalid.");
        } finally {UnityEngine.Object.DestroyImmediate(temporary);}
        var clips=dependencies.SelectMany(p=>AssetDatabase.LoadAllAssetsAtPath(p)).OfType<AnimationClip>()
            .Distinct().Select(c=>new {c.name,c.isHumanMotion,c.isLooping}).ToArray();
        var result=new {passed=true,checks,referenceTPoseValid=tpose,alembicDependencies=0,oldModelDependency=false,
            clips,prefabGuid=AssetDatabase.AssetPathToGUID(Prefab),playModeEntered=false,
            sceneDirty=SceneManager.GetActiveScene().isDirty};
        File.WriteAllText(Output+"/verification_report.json",JsonConvert.SerializeObject(result,Formatting.Indented));
        return result;
    }
}
