"""Clay review of captured Unity greeting geometry; no project edits."""
import json
import struct
from pathlib import Path
import bpy
import numpy as np
from mathutils import Vector
OUT=Path(__file__).resolve().parents[2]/'Data/JiwooRigged/ClothingWeightRepair'
data=json.loads((OUT/'greeting_samples.json').read_text())
with (OUT/'greeting_geometry.bin').open('rb') as f:
    count,nf,nc=struct.unpack('<iii',f.read(12));frame=10
    f.seek(12+frame*(nf+nc)*24)
    skin=np.frombuffer(f.read(nf*12),dtype='<f4').reshape(-1,3).copy()
    f.read(nf*12)
    clothing=np.frombuffer(f.read(nc*12),dtype='<f4').reshape(-1,3).copy()
bpy.ops.wm.read_factory_settings(use_empty=True)
def add(label,positions,triangles,color):
    mesh=bpy.data.meshes.new(label);mesh.from_pydata(positions[:,[0,2,1]].tolist(),[],np.array(triangles).reshape(-1,3).tolist())
    obj=bpy.data.objects.new(label,mesh);bpy.context.scene.collection.objects.link(obj)
    mat=bpy.data.materials.new(label);mat.diffuse_color=(*color,1.);mesh.materials.append(mat)
    for p in mesh.polygons:p.use_smooth=True
    return obj
add('Skin',skin,data['skinTriangles'],(.7,.36,.27))
cloth=add('Clothes',clothing,data['clothTriangles'],(.07,.32,.4))
scene=bpy.context.scene;scene.render.engine='BLENDER_WORKBENCH'
scene.display.shading.color_type='MATERIAL';scene.display.shading.show_shadows=True
scene.display.shading.show_cavity=True;scene.render.resolution_x=800;scene.render.resolution_y=900;scene.render.resolution_percentage=100
camera=bpy.data.objects.new('Camera',bpy.data.cameras.new('Camera'));scene.collection.objects.link(camera)
center=skin.mean(0)[[0,2,1]];center[2]=1.3
camera.location=Vector(center)+Vector((0,-3,0))
camera.rotation_euler=(Vector(center)-camera.location).to_track_quat('-Z','Y').to_euler()
camera.data.type='ORTHO';camera.data.ortho_scale=1.0;scene.camera=camera
scene.render.filepath=str(OUT/'greeting_before.png');bpy.ops.render.render(write_still=True)
if (OUT/'outfit_weights_baseline.npz').exists():
    baseline=np.load(OUT/'outfit_weights_baseline.npz');weights=baseline['weights']
    mapping=json.loads((OUT/'repair_report.json').read_text())['unity_vertex_mapping']
    weights=weights[mapping];weights[weights<.001]=0;weights/=weights.sum(1)[:,None]
    matrices=np.array(data['matrices'])[frame].reshape(-1,4,4)
    positions=np.column_stack((np.array(data['clothPositions']),np.ones(nc)))
    posed=np.einsum('vb,bvi->vi',weights,np.einsum('bij,vj->bvi',matrices[:,:3,:],positions))
    cloth.data.vertices.foreach_set('co',posed[:,[0,2,1]].astype(np.float32).ravel());cloth.data.update()
    scene.render.filepath=str(OUT/'greeting_candidate.png');bpy.ops.render.render(write_still=True)
