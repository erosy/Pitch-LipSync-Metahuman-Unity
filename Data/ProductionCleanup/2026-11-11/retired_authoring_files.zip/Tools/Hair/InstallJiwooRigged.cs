using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using Unity.DemoTeam.Hair;
using Sandbox.CharacterSystem;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using UnityEngine.Formats.Alembic.Importer;

public static class InstallJiwooRigged
{
    const string Output = "Data/JiwooRigged/Batch02";
    const string Folder = "Assets/_Sandbox/Characters/Jiwoo";
    const string PrefabPath = Folder + "/Jiwoo_Normalized.prefab";
    const string ModelPath = Folder + "/Jiwoo_Rigged.fbx";
    const string Grooms = Folder + "/Groom/Rigged";
    const string Textures = Folder + "/Textures/Rigged";
    static JObject Export => JObject.Parse(File.ReadAllText(Output+"/export_report.json"));
    static object V(Vector3 v)=>new{x=v.x,y=v.y,z=v.z};
    static void SaveReport(string name, object report) => File.WriteAllText(Output+"/"+name+".json",JsonConvert.SerializeObject(report,Formatting.Indented));
    static void Backup(string path)
    {
        var dest=Output+"/Before/"+path;
        Directory.CreateDirectory(Path.GetDirectoryName(dest));
        if(File.Exists(path) && !File.Exists(dest)) File.Copy(path,dest);
        if(File.Exists(path+".meta") && !File.Exists(dest+".meta")) File.Copy(path+".meta",dest+".meta");
    }
    static void Guard()
    {
        if (EditorApplication.isPlayingOrWillChangePlaymode) throw new Exception("Edit Mode required; user controls Play Mode.");
    }
    static SkeletonBone[] ReferenceTPose(GameObject asset,HumanDescription description,bool repair=true)
    {
        // The delivered bind pose is an A-pose. A valid avatar flag does not
        // validate its retargeting reference: author that reference explicitly.
        var tool=typeof(Editor).Assembly.GetType("UnityEditor.AvatarSetupTool");
        var methods=tool.GetMethods(BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Static);
        var instance=UnityEngine.Object.Instantiate(asset);instance.hideFlags=HideFlags.HideAndDontSave;
        try
        {
            var transforms=instance.GetComponentsInChildren<Transform>(true).ToDictionary(t=>t.name);
            foreach(var bone in description.skeleton)if(transforms.TryGetValue(bone.name,out var t))
            {t.localPosition=bone.position;t.localRotation=bone.rotation;t.localScale=bone.scale;}
            var modelBones=methods.Single(m=>m.Name=="GetModelBones"&&m.GetParameters().Length==3).Invoke(null,new object[]{instance.transform,false,null});
            var humanBones=methods.Single(m=>m.Name=="GetHumanBones"&&m.GetParameters()[0].ParameterType==typeof(Dictionary<string,string>))
                .Invoke(null,new object[]{description.human.ToDictionary(h=>h.humanName,h=>h.boneName),modelBones});
            if(repair)methods.Single(m=>m.Name=="MakePoseValid").Invoke(null,new[]{humanBones});
            if(!(bool)methods.Single(m=>m.Name=="IsPoseValid").Invoke(null,new[]{humanBones}))throw new Exception("Humanoid reference T-pose invalid");
            return (SkeletonBone[])methods.Single(m=>m.Name=="GetSkeletonBones").Invoke(null,new object[]{instance.transform});
        }finally{UnityEngine.Object.DestroyImmediate(instance);}
    }
    public static object Import()
    {
        Guard();
        var scene=UnityEngine.SceneManagement.SceneManager.GetActiveScene();
        if(scene.isDirty) throw new Exception("Save or review existing scene changes before integration.");
        Backup(scene.path); Backup(PrefabPath);
        foreach(var mat in Directory.GetFiles(Folder+"/Materials","*.mat")) Backup(mat);
        Directory.CreateDirectory(Grooms);Directory.CreateDirectory(Textures);
        File.Copy(Output+"/Jiwoo_Rigged.fbx",ModelPath,true);
        foreach(var groom in Export["grooms"]) File.Copy(Output+"/"+groom["filename"],Grooms+"/"+groom["filename"],true);
        foreach(var texture in Directory.GetFiles(Output+"/Textures").Where(p=>!p.Contains("Animated_")&&!p.Contains("MetallicRoughness"))) File.Copy(texture,Textures+"/"+Path.GetFileName(texture),true);
        AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);
        foreach(var path in Directory.GetFiles(Textures).Where(p=>!p.EndsWith(".meta")))
        {
            var importer=AssetImporter.GetAtPath(path.Replace('\\','/')) as TextureImporter;
            if(!importer)continue;
            importer.textureType=Path.GetFileName(path).IndexOf("Normal",StringComparison.OrdinalIgnoreCase)>=0?TextureImporterType.NormalMap:TextureImporterType.Default;
            importer.sRGBTexture=!(path.Contains("Normal")||path.Contains("MetallicRoughness")||path.Contains("Occlusion"));
            importer.SaveAndReimport();
        }
        var model=(ModelImporter)AssetImporter.GetAtPath(ModelPath);
        model.globalScale=1;model.useFileScale=true;model.bakeAxisConversion=true;
        model.importBlendShapes=true;model.importAnimation=false;model.importCameras=false;model.importLights=false;
        model.meshCompression=ModelImporterMeshCompression.Off;model.isReadable=true;
        model.skinWeights=ModelImporterSkinWeights.Custom;model.maxBonesPerVertex=32;model.minBoneWeight=.0001f;
        model.optimizeGameObjects=false;model.materialImportMode=ModelImporterMaterialImportMode.None;
        model.animationType=ModelImporterAnimationType.Generic;model.SaveAndReimport();
        var asset=AssetDatabase.LoadAssetAtPath<GameObject>(ModelPath);
        var map=new Dictionary<string,string>{["Hips"]="DEF-spine",["Spine"]="DEF-spine.001",["Chest"]="DEF-spine.003",["UpperChest"]="DEF-spine.004",["Neck"]="DEF-spine.005",["Head"]="DEF-spine.006"};
        foreach(var side in new[]{"Left","Right"})
        {
            string s=side=="Left"?".L":".R";
            map[side+"Shoulder"]="DEF-shoulder"+s;map[side+"UpperArm"]="DEF-upper_arm"+s;map[side+"LowerArm"]="DEF-forearm"+s;map[side+"Hand"]="DEF-hand"+s;
            map[side+"UpperLeg"]="DEF-thigh"+s;map[side+"LowerLeg"]="DEF-shin"+s;map[side+"Foot"]="DEF-foot"+s;map[side+"Toes"]="DEF-toe"+s;
            foreach(var f in new[]{new[]{"Thumb","thumb"},new[]{"Index","f_index"},new[]{"Middle","f_middle"},new[]{"Ring","f_ring"},new[]{"Little","f_pinky"}})
                for(int i=0;i<3;i++)map[side+f[0]+new[]{"Proximal","Intermediate","Distal"}[i]]="DEF-"+f[1]+".0"+(i+1)+s;
        }
        var transforms=asset.GetComponentsInChildren<Transform>(true);
        foreach(var bone in map.Values)if(!transforms.Any(t=>t.name==bone))throw new Exception("Missing humanoid bone "+bone);
        var description=model.humanDescription;
        description.human=map.Select(kv=>new HumanBone{humanName=kv.Key,boneName=kv.Value,limit=new HumanLimit{useDefaultValues=true}}).ToArray();
        description.skeleton=transforms.Select(t=>new SkeletonBone{name=t.name,position=t.localPosition,rotation=t.localRotation,scale=t.localScale}).ToArray();
        description.skeleton=ReferenceTPose(asset,description);
        description.upperArmTwist=.5f;description.lowerArmTwist=.5f;description.upperLegTwist=.5f;description.lowerLegTwist=.5f;description.armStretch=.05f;description.legStretch=.05f;
        model.humanDescription=description;model.animationType=ModelImporterAnimationType.Human;model.avatarSetup=ModelImporterAvatarSetup.CreateFromThisModel;
        model.SaveAndReimport();
        asset=AssetDatabase.LoadAssetAtPath<GameObject>(ModelPath);
        var avatar=asset.GetComponent<Animator>()?.avatar;
        if(!avatar||!avatar.isValid||!avatar.isHuman)throw new Exception("Imported Humanoid avatar invalid; scene unchanged.");
        var renderer=asset.GetComponentsInChildren<SkinnedMeshRenderer>(true).Single();
        var expected=Export["shape_names"].Values<string>().ToArray();
        var actual=Enumerable.Range(0,renderer.sharedMesh.blendShapeCount).Select(renderer.sharedMesh.GetBlendShapeName).ToArray();
        if(!expected.SequenceEqual(actual))throw new Exception("Imported shape names differ");
        var result=new{validHumanoid=true,shapes=actual.Length,vertices=renderer.sharedMesh.vertexCount,bones=renderer.bones.Length,materials=renderer.sharedMesh.subMeshCount};
        SaveReport("unity_import",result);return result;
    }

    static Material[] Materials()
    {
        string shirt="MI_WI_SleevelessTurtleneck_SleevelessTurtleneck";
        string shirtPath=Folder+"/Materials/Jiwoo_Outfit.mat";
        var outfit=AssetDatabase.LoadAssetAtPath<Material>(shirtPath);
        if(!outfit){outfit=new Material(Shader.Find("Universal Render Pipeline/Lit"));AssetDatabase.CreateAsset(outfit,shirtPath);}
        outfit.SetTexture("_BaseMap",AssetDatabase.LoadAssetAtPath<Texture2D>(Textures+"/"+shirt+"_BaseColor.png"));
        outfit.SetTexture("_BumpMap",AssetDatabase.LoadAssetAtPath<Texture2D>(Textures+"/"+shirt+"_Normal.png"));outfit.EnableKeyword("_NORMALMAP");
        outfit.SetTexture("_OcclusionMap",AssetDatabase.LoadAssetAtPath<Texture2D>(Textures+"/"+shirt+"_Occlusion.png"));outfit.SetFloat("_Smoothness",.3f);
        // glTF packs metallic in B and roughness in G; URP needs metallic R,
        // smoothness A. Repack channels rather than using the wrong convention.
        string mr=Output+"/Textures/"+shirt+"_MetallicRoughness.png";
        if(File.Exists(mr))
        {
            var input=new Texture2D(2,2,TextureFormat.RGBA32,false,true);
            if(!ImageConversion.LoadImage(input,File.ReadAllBytes(mr)))throw new Exception("Outfit source map could not be decoded");
            var pixels=input.GetPixels();for(int i=0;i<pixels.Length;i++)pixels[i]=new Color(pixels[i].b,0,0,1-pixels[i].g);
            var packed=new Texture2D(input.width,input.height,TextureFormat.RGBA32,false,true);packed.SetPixels(pixels);packed.Apply();
            string path=Textures+"/Jiwoo_Outfit_MetallicSmoothness.png";File.WriteAllBytes(path,packed.EncodeToPNG());UnityEngine.Object.DestroyImmediate(packed);
            AssetDatabase.ImportAsset(path,ImportAssetOptions.ForceSynchronousImport);
            var packedImporter=(TextureImporter)AssetImporter.GetAtPath(path);packedImporter.sRGBTexture=false;packedImporter.SaveAndReimport();
            outfit.SetTexture("_MetallicGlossMap",AssetDatabase.LoadAssetAtPath<Texture2D>(path));outfit.SetFloat("_Smoothness",1);outfit.EnableKeyword("_METALLICSPECGLOSSMAP");
            UnityEngine.Object.DestroyImmediate(input);
        }
        var map=new Dictionary<string,string>{
            [shirt]="Jiwoo_Outfit",["Jiwoo_MetaHumanCharacter_body_shader"]="Jiwoo_Body",["Jiwoo_MetaHumanCharacter_head_shader"]="Jiwoo_Head",
            ["Jiwoo_MetaHumanCharacter_teeth_shader"]="Jiwoo_Teeth",["Jiwoo_MetaHumanCharacter_saliva_shader"]="Jiwoo_Saliva",
            ["Jiwoo_MetaHumanCharacter_eyeLeft_shader"]="Jiwoo_Eyes",["Jiwoo_MetaHumanCharacter_eyeRight_shader"]="Jiwoo_Eyes",
            ["Jiwoo_MetaHumanCharacter_eyeshell_shader"]="Jiwoo_EyeShell",["Jiwoo_MetaHumanCharacter_eyeEdge_shader"]="Jiwoo_EyeEdge",
            ["Jiwoo_MetaHumanCharacter_cartilage_shader"]="Jiwoo_Cartilage"};
        var result=Export["material_names"].Values<string>().Select(n=>AssetDatabase.LoadAssetAtPath<Material>(Folder+"/Materials/"+map[n]+".mat")).ToArray();
        if(result.Any(m=>!m))throw new Exception("Missing material");
        foreach(var material in result.Distinct())
        {
            foreach(var property in material.GetTexturePropertyNames())
            {
                var old=material.GetTexture(property);if(!old)continue;
                var replacement=AssetDatabase.LoadAssetAtPath<Texture>(Textures+"/"+Path.GetFileName(AssetDatabase.GetAssetPath(old)));
                if(replacement)material.SetTexture(property,replacement);
            }
            EditorUtility.SetDirty(material);
        }
        var model=(ModelImporter)AssetImporter.GetAtPath(ModelPath);
        var names=Export["material_names"].Values<string>().ToArray();
        for(int i=0;i<names.Length;i++)model.AddRemap(new AssetImporter.SourceAssetIdentifier(typeof(Material),names[i]),result[i]);
        model.materialImportMode=ModelImporterMaterialImportMode.ImportStandard;model.SaveAndReimport();
        return result;
    }

    public static object BuildAssets()
    {
        Guard();
        if(!(bool)JObject.Parse(File.ReadAllText(Output+"/blender_readback.json"))["passed"])throw new Exception("Readback must pass");
        var materials=Materials();
        var results=new List<object>();
        foreach(var groom in Export["grooms"])
        {
            string label=(string)groom["label"],abc=Grooms+"/"+(string)groom["filename"];
            var importer=AssetImporter.GetAtPath(abc);var so=new SerializedObject(importer);
            so.FindProperty("streamSettings.scaleFactor").floatValue=1;
            foreach(var f in new[]{"importCurves","swapHandedness","importXform"})so.FindProperty("streamSettings."+f).boolValue=true;
            foreach(var f in new[]{"createCurveRenderers","importMeshes","importCameras","importPoints"})so.FindProperty("streamSettings."+f).boolValue=false;
            so.ApplyModifiedPropertiesWithoutUndo();importer.SaveAndReimport();
            string path=Grooms+"/Jiwoo_"+label+".asset";
            var asset=AssetDatabase.LoadAssetAtPath<HairAsset>(path);
            if(!asset){asset=ScriptableObject.CreateInstance<HairAsset>();AssetDatabase.CreateAsset(asset,path);}
            asset.settingsBasic.type=HairAsset.Type.Alembic;
            asset.settingsBasic.kLODClusters=false;
            asset.settingsAlembic.alembicAsset=AssetDatabase.LoadAssetAtPath<AlembicStreamPlayer>(abc);
            asset.settingsAlembic.alembicScalePositions=HairAsset.SettingsAlembic.SourceUnit.DataInMeters;
            asset.settingsAlembic.alembicScaleDiameters=HairAsset.SettingsAlembic.SourceUnit.DataInMeters;
            asset.settingsAlembic.settingsResolve.resampleResolution=(int)groom["points_per_strand"];
            asset.settingsAlembic.settingsResolve.resampleCurves=false;
            asset.strandGroupsAutoBuild=false;
            HairAssetBuilder.BuildHairAsset(asset,HairAssetBuilder.BuildFlags.DisableProgress);
            var group=asset.strandGroups.Single();
            if(group.strandCount!=(int)groom["strands"]||group.strandParticleCount!=(int)groom["points_per_strand"])throw new Exception("Groom topology changed "+label);
            if(Mathf.Abs(group.strandParamsMax.y-(float)groom["diameter_m"])>1e-7f)throw new Exception("Diameter mismatch "+label);
            EditorUtility.SetDirty(asset);results.Add(new{label,group.strandCount,group.strandParticleCount,maxLength=group.strandParamsMax.x,diameter=group.strandParamsMax.y,lods=group.lodCount});
        }
        AssetDatabase.SaveAssets();
        SaveReport("unity_assets",new{grooms=results,materials=materials.Select(m=>m.name).ToArray()});
        return results;
    }

    public static object DumpImport()
    {
        Guard();
        var model=UnityEngine.Object.Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>(ModelPath));model.hideFlags=HideFlags.HideAndDontSave;
        try
        {
            var renderer=model.GetComponentsInChildren<SkinnedMeshRenderer>(true).Single();var mesh=renderer.sharedMesh;
            var head=model.GetComponent<Animator>().GetBoneTransform(HumanBodyBones.Head);
            var bones=model.GetComponentsInChildren<Transform>(true).Where(t=>t.name.StartsWith("DEF-")).Select(t=>new{name=t.name,position=V(t.position),matrix=Enumerable.Range(0,16).Select(i=>t.localToWorldMatrix[i/4,i%4]).ToArray()}).ToArray();
            var groomReports=new List<object>();
            foreach(var g in Export["grooms"])
            {
                var abc=UnityEngine.Object.Instantiate(AssetDatabase.LoadAssetAtPath<AlembicStreamPlayer>(Grooms+"/"+(string)g["filename"]));
                abc.gameObject.hideFlags=HideFlags.HideAndDontSave;
                try
                {
                    var curves=abc.GetComponentsInChildren<AlembicCurves>(true).Single();
                    var samples=g["sample_indices"].Values<int>().Select(i=>new{index=i,position=V(curves.Positions[i])}).ToArray();
                    groomReports.Add(new{label=(string)g["label"],strands=curves.CurveOffsets.Length,points=curves.Positions.Length,widthMin=curves.Widths.Min(),widthMax=curves.Widths.Max(),samples});
                }finally{UnityEngine.Object.DestroyImmediate(abc.gameObject);}
            }
            var vertices=mesh.vertices;
            using(var writer=new BinaryWriter(File.Create(Output+"/unity_shape_positions.bin")))
            {
                Action<Vector3[]> write=points=>{foreach(var p in points){var v=renderer.transform.TransformPoint(p);writer.Write(v.x);writer.Write(v.y);writer.Write(v.z);}};
                write(vertices);var delta=new Vector3[mesh.vertexCount];
                for(int i=0;i<mesh.blendShapeCount;i++){mesh.GetBlendShapeFrameVertices(i,0,delta,null,null);write(vertices.Select((p,j)=>p+delta[j]).ToArray());}
            }
            var result=new{vertices=mesh.vertexCount,shapeNames=Enumerable.Range(0,mesh.blendShapeCount).Select(mesh.GetBlendShapeName).ToArray(),bones,grooms=groomReports,headScale=V(head.lossyScale),rootScale=V(model.transform.lossyScale)};
            SaveReport("unity_geometry",result);return new{vertices=mesh.vertexCount,shapes=mesh.blendShapeCount,bones=bones.Length,grooms=groomReports.Count};
        }finally{UnityEngine.Object.DestroyImmediate(model);}
    }

    static void SetReference(UnityEngine.Object target,string field,UnityEngine.Object value)
    {
        var data=new SerializedObject(target);var p=data.FindProperty(field);
        if(p==null)throw new Exception("Missing binding "+field);
        p.objectReferenceValue=value;data.ApplyModifiedPropertiesWithoutUndo();EditorUtility.SetDirty(target);
    }

    public static object Install()
    {
        Guard();
        if(!(bool)JObject.Parse(File.ReadAllText(Output+"/unity_geometry_verification.json"))["passed"])throw new Exception("Static import verification must pass first");
        var root=UnityEngine.Object.FindObjectsByType<Transform>(FindObjectsInactive.Include).Single(t=>!t.parent && t.name=="Jiwoo_Normalized").gameObject;
        if(root.scene.isDirty)throw new Exception("Scene has existing unsaved changes");
        Backup(root.scene.path);Backup(PrefabPath);
        var scene=root.scene;
        var oldAnimator=root.GetComponent<Animator>();
        var face=root.GetComponentsInChildren<SkinnedMeshRenderer>(true).Single(r=>r.name=="Face");
        var driver=face.GetComponent<uLipSync.uLipSyncBlendShape>();
        var visemeNames=driver.blendShapes.Select(b=>face.sharedMesh.GetBlendShapeName(b.index)).ToArray();
        var oldRig=root.transform.Find("Jiwoo_Armature");if(!oldRig)throw new Exception("Old skeleton not found");
        var hairs=root.GetComponentsInChildren<HairInstance>(true);
        if(hairs.Length!=3)throw new Exception("Expected scalp, brows, lashes");
        var model=UnityEngine.Object.Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>(ModelPath));
        var newAnimator=model.GetComponent<Animator>();
        var importedFace=model.GetComponentsInChildren<SkinnedMeshRenderer>(true).Single();
        var head=newAnimator.GetBoneTransform(HumanBodyBones.Head);
        var newRig=model.transform.Find("Jiwoo_Armature");if(!newRig||!head)throw new Exception("New skeleton missing");
        var boneMap=new Dictionary<UnityEngine.Object,UnityEngine.Object>();
        for(int i=0;i<(int)HumanBodyBones.LastBone;i++)
        {
            var before=oldAnimator.GetBoneTransform((HumanBodyBones)i);var after=newAnimator.GetBoneTransform((HumanBodyBones)i);
            if(before&&after)boneMap[before]=after;
        }
        boneMap[oldRig]=newRig;
        var gaze=root.GetComponentsInChildren<Transform>(true).SingleOrDefault(t=>t.name=="SpeechGazeFrame");
        var boundaries=root.GetComponentsInChildren<HairBoundary>(true);
        Undo.IncrementCurrentGroup();int group=Undo.GetCurrentGroup();Undo.SetCurrentGroupName("Replace Jiwoo from approved rigged delivery");
        Undo.RegisterFullObjectHierarchyUndo(root,"Replace Jiwoo");
        try
        {
            if(PrefabUtility.IsPartOfPrefabInstance(root))PrefabUtility.UnpackPrefabInstance(root,PrefabUnpackMode.Completely,InteractionMode.AutomatedAction);
            newRig.SetParent(root.transform,false);
            Undo.RegisterCreatedObjectUndo(newRig.gameObject,"Install Jiwoo skeleton");
            oldRig.name="Jiwoo_Armature_Previous";
            var materials=AssetDatabase.LoadAssetAtPath<GameObject>(ModelPath).GetComponentsInChildren<SkinnedMeshRenderer>(true).Single().sharedMaterials;
            if(materials.Any(m=>!m))throw new Exception("Imported material remap missing");
            face.sharedMesh=importedFace.sharedMesh;face.bones=importedFace.bones;face.rootBone=importedFace.rootBone;
            face.sharedMaterials=materials;face.localBounds=importedFace.localBounds;
            face.transform.localPosition=Vector3.zero;face.transform.localRotation=Quaternion.identity;face.transform.localScale=Vector3.one;
            face.quality=SkinQuality.Auto;
            for(int i=0;i<face.sharedMesh.blendShapeCount;i++)face.SetBlendShapeWeight(i,0);
            oldAnimator.avatar=newAnimator.avatar;
            for(int i=0;i<driver.blendShapes.Count;i++)
            {
                int index=face.sharedMesh.GetBlendShapeIndex(visemeNames[i]);if(index<0)throw new Exception("Missing viseme "+visemeNames[i]);
                driver.blendShapes[i].index=index;
            }
            driver.skinnedMeshRenderer=face;
            foreach(var hair in hairs)
            {
                hair.transform.SetParent(head,false);hair.transform.localPosition=Vector3.zero;hair.transform.localRotation=Quaternion.identity;hair.transform.localScale=Vector3.one;
                string label=hair.name=="Hair"?"Scalp":hair.name=="EyeBrows"?"Eyebrows":"Eyelashes";
                var asset=AssetDatabase.LoadAssetAtPath<HairAsset>(Grooms+"/Jiwoo_"+label+".asset");
                if(!asset)throw new Exception("Missing groom "+label);
                hair.strandGroupProviders=new[]{new HairInstance.GroupProvider{hairAsset=asset}};
                foreach(var settings in hair.strandGroupSettings??Array.Empty<HairInstance.GroupSettings>())
                    if(settings.groupAssetReferences!=null)for(int i=0;i<settings.groupAssetReferences.Count;i++)settings.groupAssetReferences[i]=new HairInstance.GroupAssetReference{hairAsset=asset,hairAssetGroupIndex=0};
                hair.strandGroupDefaults.settingsGeometry.strandScale=HairSim.SettingsGeometry.StrandScale.Fixed;
                hair.strandGroupDefaults.settingsGeometry.strandLength=false;hair.strandGroupDefaults.settingsGeometry.strandDiameter=false;
                // Keep runtime scalp simulation settings; prevent automatic Edit
                // Mode simulation during this static installation and handoff.
                hair.settingsExecutive.updateSimulationInEditor=false;
                if(label!="Scalp")hair.settingsExecutive.updateSimulation=false;
                HairInstanceBuilder.BuildHairInstance(hair,hair.strandGroupProviders);
                EditorUtility.SetDirty(hair);
            }
            foreach(var boundary in boundaries)
                if(boundary.transform.IsChildOf(oldRig))boundary.transform.SetParent(head,true);
            if(gaze)
            {
                gaze.SetParent(head,false);gaze.localPosition=Vector3.zero;
                gaze.rotation=Quaternion.LookRotation(-root.transform.forward,root.transform.up);
            }
            foreach(var component in root.GetComponentsInChildren<Component>(true).Where(c=>c && !(c is Transform) && !(c is Renderer) && !(c is Animator)))
            {
                var data=new SerializedObject(component);var p=data.GetIterator();bool changed=false;
                while(p.Next(true))if(p.propertyType==SerializedPropertyType.ObjectReference && p.objectReferenceValue && boneMap.TryGetValue(p.objectReferenceValue,out var replacement))
                {p.objectReferenceValue=replacement;changed=true;}
                if(changed)data.ApplyModifiedPropertiesWithoutUndo();
            }
            var warmup=root.GetComponent<CharacterHairStartupWarmup>();SetReference(warmup,"targetAnimator",oldAnimator);
            var warmupData=new SerializedObject(warmup);var list=warmupData.FindProperty("strandHair");list.arraySize=hairs.Length;
            for(int i=0;i<hairs.Length;i++)list.GetArrayElementAtIndex(i).objectReferenceValue=hairs[i];warmupData.ApplyModifiedPropertiesWithoutUndo();
            var expression=root.GetComponentsInChildren<ExpressionModule>(true).Single();SetReference(expression,"face",face);
            if(gaze)SetReference(expression,"speechGaze.head",gaze);
            var body=root.GetComponentsInChildren<AnimationModule>(true).Single();SetReference(body,"animator",oldAnimator);
            Undo.DestroyObjectImmediate(importedFace.gameObject);
            Undo.DestroyObjectImmediate(oldRig.gameObject);
            UnityEngine.Object.DestroyImmediate(model);model=null;
            var errors=root.GetComponent<Character>().ValidateConfiguration();
            if(errors.Count>0)throw new Exception(string.Join("; ",errors));
            PrefabUtility.SaveAsPrefabAssetAndConnect(root,PrefabPath,InteractionMode.AutomatedAction,out bool saved);
            if(!saved)throw new Exception("Prefab save failed");
            AssetDatabase.SaveAssets();EditorSceneManager.MarkSceneDirty(scene);
            if(!EditorSceneManager.SaveScene(scene))throw new Exception("Scene save failed");
            var result=new{installed=true,prefab=PrefabPath,scene=scene.path,shapes=face.sharedMesh.blendShapeCount,
                mesh=AssetDatabase.GetAssetPath(face.sharedMesh),avatar=AssetDatabase.GetAssetPath(oldAnimator.avatar),
                visemes=visemeNames,grooms=hairs.Select(h=>new{name=h.name,asset=AssetDatabase.GetAssetPath(h.strandGroupProviders.Single().hairAsset),editModeSimulation=h.settingsExecutive.updateSimulationInEditor}).ToArray(),
                playModeEntered=false,liveTestingPerformed=false,cleanupDeferredToBatch3=true};
            SaveReport("installation",result);return result;
        }
        catch{Undo.RevertAllDownToGroup(group);throw;}
        finally{if(model)UnityEngine.Object.DestroyImmediate(model);}
    }

    static object CheckCharacter(GameObject root)
    {
        var animator=root.GetComponent<Animator>();
        if(!animator||!animator.avatar||!animator.avatar.isValid||!animator.avatar.isHuman)throw new Exception(root.name+": invalid avatar");
        if(AssetDatabase.GetAssetPath(animator.avatar)!=ModelPath)throw new Exception("Old avatar still bound");
        ReferenceTPose(AssetDatabase.LoadAssetAtPath<GameObject>(ModelPath),((ModelImporter)AssetImporter.GetAtPath(ModelPath)).humanDescription,false);
        var face=root.GetComponentsInChildren<SkinnedMeshRenderer>(true).Single(r=>r.name=="Face");
        if(AssetDatabase.GetAssetPath(face.sharedMesh)!=ModelPath||face.bones.Any(b=>!b))throw new Exception("Old mesh or missing bones");
        var names=Enumerable.Range(0,face.sharedMesh.blendShapeCount).Select(face.sharedMesh.GetBlendShapeName).ToArray();
        if(!names.SequenceEqual(Export["shape_names"].Values<string>()))throw new Exception("Shape names changed");
        if(face.sharedMaterials.Length!=face.sharedMesh.subMeshCount||face.sharedMaterials.Any(m=>!m||!m.shader||!m.shader.isSupported))throw new Exception("Invalid material slots or shaders");
        if(root.GetComponentsInChildren<Transform>(true).Any(t=>GameObjectUtility.GetMonoBehavioursWithMissingScriptCount(t.gameObject)>0))throw new Exception("Missing script");
        var hairs=root.GetComponentsInChildren<HairInstance>(true);
        if(hairs.Length!=3)throw new Exception("Unexpected groom count");
        foreach(var h in hairs)
        {
            if(h.transform.parent.name!="DEF-spine.006"||h.transform.localPosition.sqrMagnitude>1e-10f||Quaternion.Angle(h.transform.localRotation,Quaternion.identity)>.001f||(h.transform.localScale-Vector3.one).sqrMagnitude>1e-10f)throw new Exception("Groom attachment invalid");
            if(!AssetDatabase.GetAssetPath(h.strandGroupProviders.Single().hairAsset).StartsWith(Grooms+"/"))throw new Exception("Legacy groom still bound");
            if(h.settingsExecutive.updateSimulationInEditor)throw new Exception("Edit Mode hair simulation enabled");
            if(h.strandGroupInstances==null||h.strandGroupInstances.Length!=1)throw new Exception("Groom instance not built");
        }
        var errors=root.GetComponent<Character>().ValidateConfiguration();
        foreach(var module in root.GetComponentsInChildren<CharacterModule>(true))module.ValidateConfiguration(errors);
        if(errors.Count>0)throw new Exception(string.Join("; ",errors));
        var lip=face.GetComponent<uLipSync.uLipSyncBlendShape>();
        if(lip.skinnedMeshRenderer!=face||lip.blendShapes.Any(b=>b.index<0||b.index>=names.Length))throw new Exception("Invalid lip-sync mapping");
        var voice=root.GetComponentsInChildren<AudioSource>(true).Single(a=>a.name=="Voice");
        return new{root=root.name,model=AssetDatabase.GetAssetPath(face.sharedMesh),avatar=animator.avatar.name,
            shapes=names.Length,materials=face.sharedMaterials.Select(m=>m.name).ToArray(),
            headScale=V(animator.GetBoneTransform(HumanBodyBones.Head).lossyScale),rootScale=V(root.transform.lossyScale),
            voice=AssetDatabase.GetAssetPath(voice.clip),grooms=hairs.Select(h=>new{h.name,count=h.strandGroupProviders.Single().hairAsset.strandGroups.Single().strandCount}).ToArray(),
            missingScripts=0,configurationErrors=errors};
    }

    public static object VerifySaved()
    {
        Guard();
        var root=UnityEngine.Object.FindObjectsByType<Transform>(FindObjectsInactive.Include).Single(t=>!t.parent&&t.name=="Jiwoo_Normalized").gameObject;
        var sceneCheck=CheckCharacter(root);
        var prefab=PrefabUtility.LoadPrefabContents(PrefabPath);
        object prefabCheck;
        try{prefabCheck=CheckCharacter(prefab);}finally{PrefabUtility.UnloadPrefabContents(prefab);}
        var buttons=UnityEngine.Object.FindObjectsByType<UnityEngine.UI.Button>(FindObjectsInactive.Include)
            .Where(b=>b.gameObject.scene.IsValid()).Select(b=>new{name=b.name,calls=Enumerable.Range(0,b.onClick.GetPersistentEventCount()).Select(i=>new{target=b.onClick.GetPersistentTarget(i)?b.onClick.GetPersistentTarget(i).name:null,method=b.onClick.GetPersistentMethodName(i),isJiwoo=b.onClick.GetPersistentTarget(i)==root.GetComponent<CharacterFlowController>()}).ToArray()}).ToArray();
        var selector=UnityEngine.Object.FindObjectsByType<CharacterSelectionController>(FindObjectsInactive.Include).SingleOrDefault(c=>c.gameObject.scene.IsValid());
        bool selectionBound=selector&&new SerializedObject(selector).FindProperty("girl").objectReferenceValue==root.GetComponent<CharacterFlowController>()
            && UnityEngine.Object.FindObjectsByType<UnityEngine.UI.Button>(FindObjectsInactive.Include).Where(b=>b.name=="Girl"&&b.gameObject.scene.IsValid())
                .Any(b=>Enumerable.Range(0,b.onClick.GetPersistentEventCount()).Any(i=>b.onClick.GetPersistentTarget(i)==selector&&b.onClick.GetPersistentMethodName(i)=="SelectGirl"));
        if(!selectionBound&&!buttons.Any(b=>b.calls.Any(c=>c.isJiwoo&&c.method=="PlayResponse")))throw new Exception("Girl button no longer selects or requests Jiwoo");
        var dependencies=AssetDatabase.GetDependencies(PrefabPath,true).Where(p=>p.StartsWith(Folder+"/")).ToArray();
        var legacy=dependencies.Where(p=>(p.EndsWith(".fbx")&&p!=ModelPath)||(p.Contains("/Groom/")&&!p.StartsWith(Grooms+"/"))).ToArray();
        if(legacy.Length>0)throw new Exception("Legacy character/groom dependency: "+string.Join(",",legacy));
        var result=new{passed=true,scene=sceneCheck,prefab=prefabCheck,buttons,legacyModelOrGroomDependencies=legacy,playModeEntered=false,liveTestingPerformed=false};
        SaveReport("saved_verification",result);return result;
    }

    public static object VerifyCleanup()
    {
        Guard();
        VerifySaved();
        var errors=new List<string>();
        var paths=new[]{PrefabPath,"Assets/_Sandbox/Scenes/CharacterTesting.unity","Assets/_Sandbox/Characters/Ethan/Ethan.prefab"};
        foreach(var path in paths)
            foreach(System.Text.RegularExpressions.Match match in System.Text.RegularExpressions.Regex.Matches(File.ReadAllText(path),@"guid:\s*([0-9a-fA-F]{32})"))
            {
                var guid=match.Groups[1].Value;
                if(!guid.StartsWith("0000000000000000")&&string.IsNullOrEmpty(AssetDatabase.GUIDToAssetPath(guid)))errors.Add(path+": missing GUID "+guid);
            }
        foreach(var root in UnityEngine.SceneManagement.SceneManager.GetActiveScene().GetRootGameObjects())
            foreach(var t in root.GetComponentsInChildren<Transform>(true))
                if(GameObjectUtility.GetMonoBehavioursWithMissingScriptCount(t.gameObject)>0)errors.Add("Missing script: "+t.name);
        var ethan=AssetDatabase.LoadAssetAtPath<GameObject>(paths[2]);
        if(!ethan.GetComponent<CharacterHairStartupWarmup>()||!ethan.GetComponent<CharacterHairFallback>()||!ethan.GetComponent<CharacterReadiness>())errors.Add("Ethan shared support binding missing");
        if(AssetDatabase.FindAssets("CharacterHairstyle t:MonoScript").Length>0)errors.Add("Obsolete hairstyle script remains");
        var dependencies=AssetDatabase.GetDependencies(PrefabPath,true);
        if(dependencies.Any(p=>p.Contains("/Replacement/")||p.Contains("/FacialGrooms/")||p.EndsWith("Jiwoo_Bob.asset")))errors.Add("Legacy groom dependency remains");
        if(Directory.Exists("Data/JiwooReimport"))errors.Add("Legacy reimport directory remains");
        if(errors.Count>0)throw new Exception(string.Join("; ",errors));
        var result=new{passed=true,errors,missingAssetGuids=0,missingSceneScripts=0,ethanSharedSupportPreserved=true,
            selectorRemoved=true,legacyImportDirectoryRemoved=true,playing=EditorApplication.isPlaying,liveTestingPerformed=false};
        Directory.CreateDirectory("Data/JiwooRigged/Batch03");
        File.WriteAllText("Data/JiwooRigged/Batch03/saved_verification.json",JsonConvert.SerializeObject(result,Formatting.Indented));
        return result;
    }
}
