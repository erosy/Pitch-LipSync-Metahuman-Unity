"""Render a disposable geometry review; never save preview changes to the blend."""
from pathlib import Path
import bpy
from mathutils import Vector

OUT=Path(__file__).resolve().parents[2]/'Data/JiwooRigged/EthanReference'
bpy.ops.wm.open_mainfile(filepath=str(OUT/'Jiwoo_EthanSetup.blend'),load_ui=False,use_scripts=False)
scene=bpy.context.scene
scene.render.engine='BLENDER_WORKBENCH'
scene.render.resolution_x=600;scene.render.resolution_y=700;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG'
scene.display.shading.light='STUDIO';scene.display.shading.studiolight_rotate_z=.4
scene.display.shading.color_type='MATERIAL'
scene.display.shading.show_shadows=True;scene.display.shading.show_cavity=True
scene.display.shading.cavity_type='BOTH';scene.display.shading.background_type='WORLD'
scene.world.color=(.055,.055,.055)
for mat in bpy.data.materials:
    n=mat.name.lower()
    if 'facialhair' in n or 'hair' in n:mat.diffuse_color=(.025,.012,.008,1.)
    elif 'teeth' in n:mat.diffuse_color=(.9,.84,.72,1.)
    elif 'eyeleft' in n or 'eyeright' in n:mat.diffuse_color=(.7,.75,.72,1.)
    elif 'head' in n or 'body' in n:mat.diffuse_color=(.62,.4,.3,1.)
scalp=bpy.data.objects['Jiwoo_ScalpGroom'];scalp.hide_render=True
camera=bpy.data.objects.new('ReviewCamera',bpy.data.cameras.new('ReviewCamera'))
scene.collection.objects.link(camera)
camera.location=(0.,-3.,1.59)
target=Vector((0.,-.015,1.59));camera.rotation_euler=(target-camera.location).to_track_quat('-Z','Y').to_euler()
camera.data.type='ORTHO';camera.data.ortho_scale=.43;scene.camera=camera
face=bpy.data.objects['Face']
for label,active in [('neutral',[]),('blink',['eyeBlinkLeft','eyeBlinkRight']),('brows_up',['browInnerUp','browOuterUpLeft','browOuterUpRight']),('joy',['emo_joy']),('jaw_open',['jawOpen']),('viseme_FF',['viseme_FF'])]:
    for obj in (face,bpy.data.objects['Outfit']):
        for key in obj.data.shape_keys.key_blocks:key.value=float(key.name in active)
    scene.render.filepath=str(OUT/('review_'+label+'.png'))
    bpy.ops.render.render(write_still=True)
print('PREVIEWS_RENDERED',flush=True)
