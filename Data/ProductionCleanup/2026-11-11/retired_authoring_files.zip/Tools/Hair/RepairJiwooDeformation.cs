using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using Unity.DemoTeam.Hair;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

public static class RepairJiwooDeformation
{
    const string Folder="Assets/_Sandbox/Characters/Jiwoo/";
    const string Prefab=Folder+"Jiwoo_Normalized.prefab";
    const string Model=Folder+"Jiwoo_Rigged.fbx";
    const string Output="Data/JiwooRigged/DeformationRepair";
    static void Guard(){if(EditorApplication.isPlayingOrWillChangePlaymode)throw new Exception("Edit Mode required; no animation is sampled.");Directory.CreateDirectory(Output);}
    static GameObject SceneRoot()=>UnityEngine.SceneManagement.SceneManager.GetActiveScene().GetRootGameObjects().Single(r=>r.name=="Jiwoo_Normalized");
    static void RebindMesh(GameObject root,SkinnedMeshRenderer imported,Avatar avatar)
    {
        var face=root.GetComponentsInChildren<SkinnedMeshRenderer>(true).Single(r=>r.name=="Face");
        var transforms=root.GetComponentsInChildren<Transform>(true);
        face.sharedMesh=imported.sharedMesh;
        face.bones=imported.bones.Select(b=>transforms.Single(t=>t.name==b.name)).ToArray();
        face.rootBone=transforms.Single(t=>t.name==imported.rootBone.name);face.localBounds=imported.localBounds;
        root.GetComponent<Animator>().avatar=avatar;
        EditorUtility.SetDirty(face);EditorUtility.SetDirty(root.GetComponent<Animator>());
        if(PrefabUtility.IsPartOfPrefabInstance(face))PrefabUtility.RecordPrefabInstancePropertyModifications(face);
        if(PrefabUtility.IsPartOfPrefabInstance(root))PrefabUtility.RecordPrefabInstancePropertyModifications(root.GetComponent<Animator>());
    }
    public static object ImportCorrectedMesh()
    {
        Guard();var scene=UnityEngine.SceneManagement.SceneManager.GetActiveScene();
        if(scene.isDirty&&!EditorSceneManager.SaveScene(scene,Output+"/CharacterTesting_before.unity",true))throw new Exception("Could not preserve the current unsaved scene before repair");
        if(!(bool)JObject.Parse(File.ReadAllText("Data/JiwooRigged/Batch02/blender_readback.json"))["passed"])throw new Exception("FBX readback must pass first");
        if(!File.Exists(Output+"/model_before.fbx")){File.Copy(Model,Output+"/model_before.fbx");File.Copy(Model+".meta",Output+"/model_before.fbx.meta");}
        File.Copy("Data/JiwooRigged/Batch02/Jiwoo_Rigged.fbx",Model,true);
        AssetDatabase.ImportAsset(Model,ImportAssetOptions.ForceSynchronousImport|ImportAssetOptions.ForceUpdate);
        var asset=AssetDatabase.LoadAssetAtPath<GameObject>(Model);var imported=asset.GetComponentsInChildren<SkinnedMeshRenderer>(true).Single();
        var avatar=asset.GetComponent<Animator>().avatar;if(!avatar||!avatar.isValid||!avatar.isHuman)throw new Exception("Avatar invalid after mesh import");
        var prefab=PrefabUtility.LoadPrefabContents(Prefab);
        try{RebindMesh(prefab,imported,avatar);PrefabUtility.SaveAsPrefabAsset(prefab,Prefab);}finally{PrefabUtility.UnloadPrefabContents(prefab);}
        RebindMesh(SceneRoot(),imported,avatar);AssetDatabase.SaveAssets();EditorSceneManager.MarkSceneDirty(scene);
        if(!EditorSceneManager.SaveScene(scene))throw new Exception("Scene save failed");
        return new{vertices=imported.sharedMesh.vertexCount,shapes=imported.sharedMesh.blendShapeCount,bones=imported.bones.Length,avatarValid=avatar.isValid};
    }

    struct Triangle { public int a,b,c;public Vector3 min,max; }
    static Vector3 ClosestBarycentric(Vector3 p,Vector3 a,Vector3 b,Vector3 c)
    {
        Vector3 ab=b-a,ac=c-a,ap=p-a;float d1=Vector3.Dot(ab,ap),d2=Vector3.Dot(ac,ap);
        if(d1<=0&&d2<=0)return new Vector3(1,0,0);
        Vector3 bp=p-b;float d3=Vector3.Dot(ab,bp),d4=Vector3.Dot(ac,bp);
        if(d3>=0&&d4<=d3)return new Vector3(0,1,0);
        float vc=d1*d4-d3*d2;
        if(vc<=0&&d1>=0&&d3<=0){float v=d1/(d1-d3);return new Vector3(1-v,v,0);}
        Vector3 cp=p-c;float d5=Vector3.Dot(ab,cp),d6=Vector3.Dot(ac,cp);
        if(d6>=0&&d5<=d6)return new Vector3(0,0,1);
        float vb=d5*d2-d1*d6;
        if(vb<=0&&d2>=0&&d6<=0){float w=d2/(d2-d6);return new Vector3(1-w,0,w);}
        float va=d3*d6-d5*d4;
        if(va<=0&&d4-d3>=0&&d5-d6>=0){float w=(d4-d3)/((d4-d3)+(d5-d6));return new Vector3(0,1-w,w);}
        float inv=1/(va+vb+vc);float y=vb*inv,z=vc*inv;return new Vector3(1-y-z,y,z);
    }
    static float BoxDistance(Vector3 p,Triangle t)
    {float x=Mathf.Max(Mathf.Max(t.min.x-p.x,0),p.x-t.max.x),y=Mathf.Max(Mathf.Max(t.min.y-p.y,0),p.y-t.max.y),z=Mathf.Max(Mathf.Max(t.min.z-p.z,0),p.z-t.max.z);return x*x+y*y+z*z;}

    static object Bind(GameObject root)
    {
        var face=root.GetComponentsInChildren<SkinnedMeshRenderer>(true).Single(r=>r.name=="Face");
        int slot=Array.FindIndex(face.sharedMaterials,m=>m&&m.name=="Jiwoo_Head");if(slot<0)throw new Exception("Head skin material missing");
        // FBX vertices can be in a different import basis from the renderer's
        // local space. Bind to neutral skinned geometry, not raw mesh vertices.
        // BakeMesh here reads the saved skeleton only; no clip is evaluated.
        var neutral=new Mesh();face.BakeMesh(neutral,false);var vertices=neutral.vertices;UnityEngine.Object.DestroyImmediate(neutral);
        var indices=face.sharedMesh.GetTriangles(slot);var triangles=new List<Triangle>();
        for(int i=0;i<indices.Length;i+=3)
        {
            int a=indices[i],b=indices[i+1],c=indices[i+2];
            if(!FacialGroomSurfaceBinding.TryFrame(vertices[a],vertices[b],vertices[c],out _))continue;
            triangles.Add(new Triangle{a=a,b=b,c=c,min=Vector3.Min(vertices[a],Vector3.Min(vertices[b],vertices[c])),max=Vector3.Max(vertices[a],Vector3.Max(vertices[b],vertices[c]))});
        }
        var bindings=new List<FacialGroomSurfaceBinding.GroomBinding>();var reports=new List<object>();
        foreach(var groom in root.GetComponentsInChildren<HairInstance>(true).Where(h=>h.name=="EyeBrows"||h.name=="EyeLashes"))
        {
            var group=groom.strandGroupProviders.Single().hairAsset.strandGroups.Single();var roots=group.meshAssetRoots;
            var positions=roots.vertices;var directions=roots.normals;var tangents=roots.tangents;
            var conversion=face.transform.worldToLocalMatrix*groom.transform.localToWorldMatrix;
            var result=new FacialGroomSurfaceBinding.RootBinding[positions.Length];float maxDistance=0,maxRestError=0,maxRigidError=0;
            for(int i=0;i<result.Length;i++)
            {
                Vector3 p=conversion.MultiplyPoint3x4(positions[i]);float best=float.PositiveInfinity;Triangle chosen=default;Vector3 bary=default;
                foreach(var t in triangles)
                {
                    if(BoxDistance(p,t)>best)continue;
                    Vector3 w=ClosestBarycentric(p,vertices[t.a],vertices[t.b],vertices[t.c]);
                    Vector3 closest=vertices[t.a]*w.x+vertices[t.b]*w.y+vertices[t.c]*w.z;
                    float distance=(p-closest).sqrMagnitude;if(distance<best){best=distance;chosen=t;bary=w;}
                }
                maxDistance=Mathf.Max(maxDistance,Mathf.Sqrt(best));
                if(best>.01f*.01f)throw new Exception(groom.name+": root "+i+" distance="+(Mathf.Sqrt(best)*1000)+"mm, position="+p.ToString("F6")+", head="+groom.transform.position.ToString("F6")+", faceBounds="+face.sharedMesh.bounds.ToString("F6")+", skinSlot="+slot);
                Vector3 a=vertices[chosen.a],b=vertices[chosen.b],c=vertices[chosen.c];
                FacialGroomSurfaceBinding.TryFrame(a,b,c,out var frame);var inverse=Quaternion.Inverse(frame);
                Vector3 center=a*bary.x+b*bary.y+c*bary.z;
                var binding=new FacialGroomSurfaceBinding.RootBinding{a=chosen.a,b=chosen.b,c=chosen.c,barycentric=bary,
                    offset=inverse*(p-center),direction=inverse*conversion.MultiplyVector(directions[i]).normalized,
                    tangent=inverse*conversion.MultiplyVector((Vector3)tangents[i]).normalized};
                result[i]=binding;maxRestError=Mathf.Max(maxRestError,(center+frame*binding.offset-p).magnitude);
                // Algebraic covariance check only; no skeleton or clip is posed.
                var q=Quaternion.AngleAxis(23,new Vector3(.2f,1,.3f).normalized);var move=new Vector3(.1f,-.2f,.05f);
                Vector3 aa=q*a+move,bb=q*b+move,cc=q*c+move;
                FacialGroomSurfaceBinding.TryFrame(aa,bb,cc,out var rotated);
                maxRigidError=Mathf.Max(maxRigidError,(aa*bary.x+bb*bary.y+cc*bary.z+rotated*binding.offset-(q*p+move)).magnitude);
            }
            if(maxRestError>2e-6f||maxRigidError>2e-6f)throw new Exception("Root binding reconstruction failed");
            if(groom.settingsExecutive.updateSimulation||groom.settingsExecutive.updateSimulationInEditor)throw new Exception("Facial groom must remain kinematic with simulation disabled");
            bindings.Add(new FacialGroomSurfaceBinding.GroomBinding{groom=groom,roots=result});
            reports.Add(new{groom=groom.name,roots=result.Length,maxSurfaceOffsetMM=maxDistance*1000,maxRestErrorM=maxRestError,maxRigidCovarianceErrorM=maxRigidError});
        }
        if(bindings.Count!=2)throw new Exception("Expected both facial grooms");
        var component=root.GetComponent<FacialGroomSurfaceBinding>()??root.AddComponent<FacialGroomSurfaceBinding>();
        var shader=AssetDatabase.LoadAssetAtPath<ComputeShader>("Assets/_Sandbox/Shaders/FacialGroomKinematics.compute");
        if(!shader||!shader.HasKernel("FollowSurface"))throw new Exception("Kinematic shader missing");
        component.Configure(face,bindings.ToArray(),shader);EditorUtility.SetDirty(component);
        if(PrefabUtility.IsPartOfPrefabInstance(component))PrefabUtility.RecordPrefabInstancePropertyModifications(component);
        return reports;
    }
    public static object BindFacialGrooms()
    {
        Guard();var root=SceneRoot();var scene=root.scene;
        var prefab=PrefabUtility.LoadPrefabContents(Prefab);object prefabReport;
        try{prefabReport=Bind(prefab);PrefabUtility.SaveAsPrefabAsset(prefab,Prefab);}finally{PrefabUtility.UnloadPrefabContents(prefab);}
        var sceneReport=Bind(root);AssetDatabase.SaveAssets();EditorSceneManager.MarkSceneDirty(scene);
        if(!EditorSceneManager.SaveScene(scene))throw new Exception("Scene save failed");
        var report=new{prefab=prefabReport,scene=sceneReport,liveTestingPerformed=false};
        File.WriteAllText(Output+"/surface_binding.json",JsonConvert.SerializeObject(report,Formatting.Indented));return report;
    }

    static object CheckSeam()
    {
        var model=AssetDatabase.LoadAssetAtPath<GameObject>(Model);var face=model.GetComponentsInChildren<SkinnedMeshRenderer>(true).Single();
        var mesh=face.sharedMesh;var snapshot=new Mesh();face.BakeMesh(snapshot,false);var points=snapshot.vertices.Select(face.transform.TransformPoint).ToArray();UnityEngine.Object.DestroyImmediate(snapshot);
        int bodySlot=Array.FindIndex(face.sharedMaterials,m=>m&&m.name=="Jiwoo_Body"),headSlot=Array.FindIndex(face.sharedMaterials,m=>m&&m.name=="Jiwoo_Head");
        var body=mesh.GetTriangles(bodySlot).Distinct().ToArray();var head=mesh.GetTriangles(headSlot).Distinct().ToArray();
        var counts=mesh.GetBonesPerVertex().ToArray();var weights=mesh.GetAllBoneWeights().ToArray();var offsets=new int[counts.Length];
        for(int i=1;i<offsets.Length;i++)offsets[i]=offsets[i-1]+counts[i-1];
        var pairs=new List<int[]>();float maxPosition=0,maxWeight=0,maxShape=0;
        foreach(var pair in JObject.Parse(File.ReadAllText("Data/JiwooRigged/Batch02/seam_repair.json"))["pairs"])
        {
            var p=pair["position_blender"].Values<float>().ToArray();var target=new Vector3(p[0],p[2],p[1]);
            int a=body.OrderBy(i=>(points[i]-target).sqrMagnitude).First(),b=head.OrderBy(i=>(points[i]-target).sqrMagnitude).First();
            if((points[a]-target).magnitude>2e-5f||(points[b]-target).magnitude>2e-5f)throw new Exception("Seam vertex not found: target="+target.ToString("F6")+", body="+points[a].ToString("F6")+", head="+points[b].ToString("F6"));
            maxPosition=Mathf.Max(maxPosition,(points[a]-points[b]).magnitude);
            var wa=new Dictionary<int,float>();var wb=new Dictionary<int,float>();
            for(int k=0;k<counts[a];k++){var w=weights[offsets[a]+k];wa[w.boneIndex]=w.weight;}
            for(int k=0;k<counts[b];k++){var w=weights[offsets[b]+k];wb[w.boneIndex]=w.weight;}
            float error=wa.Keys.Union(wb.Keys).Sum(i=>Mathf.Abs((wa.TryGetValue(i,out var aa)?aa:0)-(wb.TryGetValue(i,out var bb)?bb:0)));
            maxWeight=Mathf.Max(maxWeight,error);pairs.Add(new[]{a,b});
        }
        var delta=new Vector3[mesh.vertexCount];
        for(int i=0;i<mesh.blendShapeCount;i++)
        {mesh.GetBlendShapeFrameVertices(i,0,delta,null,null);foreach(var p in pairs)maxShape=Mathf.Max(maxShape,(delta[p[0]]-delta[p[1]]).magnitude);}
        if(maxPosition>2e-5f||maxWeight>1e-5f||maxShape>2e-5f)throw new Exception("Imported seam mismatch: "+maxPosition+", "+maxWeight+", "+maxShape);
        return new{matchedPairs=pairs.Count,maxRestGapM=maxPosition,maxWeightL1=maxWeight,maxShapeDeltaMismatchM=maxShape,shapes=mesh.blendShapeCount};
    }

    static object CheckBindings(GameObject root)
    {
        var binding=root.GetComponent<FacialGroomSurfaceBinding>();if(!binding||!binding.enabled)throw new Exception("Surface binding component missing");
        var data=new SerializedObject(binding);var face=(SkinnedMeshRenderer)data.FindProperty("face").objectReferenceValue;
        if(!face||data.FindProperty("referenceMesh").objectReferenceValue!=face.sharedMesh)throw new Exception("Binding mesh reference mismatch");
        var grooms=data.FindProperty("grooms");if(grooms.arraySize!=2)throw new Exception("Expected two facial binding groups");
        var reports=new List<object>();
        for(int i=0;i<grooms.arraySize;i++)
        {
            var item=grooms.GetArrayElementAtIndex(i);var hair=(HairInstance)item.FindPropertyRelative("groom").objectReferenceValue;
            var roots=item.FindPropertyRelative("roots");
            if(!hair||!hair.transform.IsChildOf(root.transform)||roots.arraySize!=hair.strandGroupProviders.Single().hairAsset.strandGroups.Single().strandCount)throw new Exception("Missing facial roots");
            if(hair.settingsExecutive.updateSimulation||hair.settingsExecutive.updateSimulationInEditor||hair.settingsExecutive.updateMode!=HairInstance.SettingsExecutive.UpdateMode.BuiltinEvent)throw new Exception("Unexpected facial scheduling or simulation at rest");
            for(int j=0;j<roots.arraySize;j++)
            {
                var r=roots.GetArrayElementAtIndex(j);foreach(var field in new[]{"a","b","c"})
                    if(r.FindPropertyRelative(field).intValue<0||r.FindPropertyRelative(field).intValue>=face.sharedMesh.vertexCount)throw new Exception("Invalid surface index");
                var w=r.FindPropertyRelative("barycentric").vector3Value;
                if(Mathf.Abs(w.x+w.y+w.z-1)>1e-5f||w.x<-.00001f||w.y<-.00001f||w.z<-.00001f)throw new Exception("Invalid barycentrics");
            }
            reports.Add(new{name=hair.name,roots=roots.arraySize});
        }
        var shader=(ComputeShader)data.FindProperty("kinematics").objectReferenceValue;
        if(!shader||!shader.HasKernel("FollowSurface"))throw new Exception("Compute kernel missing");
        shader.GetKernelThreadGroupSizes(shader.FindKernel("FollowSurface"),out uint x,out uint y,out uint z);
        if(x!=64||y!=1||z!=1)throw new Exception("Unexpected compute thread group");
        foreach(var message in ShaderUtil.GetComputeShaderMessages(shader))
            if(message.severity.ToString()=="Error")throw new Exception("Compute compile error: "+message.message);
        return reports;
    }

    public static object Verify()
    {
        Guard();var seam=CheckSeam();var sceneBindings=CheckBindings(SceneRoot());
        var prefab=PrefabUtility.LoadPrefabContents(Prefab);object prefabBindings;
        try{prefabBindings=CheckBindings(prefab);}finally{PrefabUtility.UnloadPrefabContents(prefab);}
        var result=new{passed=true,seam,sceneBindings,prefabBindings,computeKernelCompiled=true,playModeEntered=false,liveTestingPerformed=false};
        File.WriteAllText(Output+"/verification.json",JsonConvert.SerializeObject(result,Formatting.Indented));return result;
    }
}
