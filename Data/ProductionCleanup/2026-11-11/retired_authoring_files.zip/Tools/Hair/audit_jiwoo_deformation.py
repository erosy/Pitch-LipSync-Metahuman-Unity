"""Inspect neutral geometry and weight continuity; never pose or save the source."""
import json
from pathlib import Path
from collections import defaultdict
import bpy
import numpy as np
from mathutils.kdtree import KDTree
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'Data/JiwooRigged/DeformationRepair'
OUT.mkdir(parents=True,exist_ok=True)
base=np.load(ROOT/'Data/JiwooRigged/Batch01/evaluated_baselines.npz')
names=['BAKED_body_lod0_mesh','BAKED_head_lod0_mesh','BAKED_Outfits']
points=[];weights=[];owners=[];boundaries=[]
for name in names:
    obj=bpy.data.objects[name]
    m=np.array(obj.matrix_world)
    positions=base[name+'|Basis']@m[:3,:3].T+m[:3,3]
    offset=len(points)
    edges=defaultdict(int)
    for poly in obj.data.polygons:
        vs=list(poly.vertices)
        for a,b in zip(vs,vs[1:]+vs[:1]):edges[tuple(sorted((a,b)))]+=1
    boundary={i for edge,count in edges.items() if count==1 for i in edge}
    for v,p in zip(obj.data.vertices,positions):
        w={obj.vertex_groups[g.group].name:g.weight for g in v.groups if obj.vertex_groups[g.group].name.startswith('DEF-') and g.weight>1e-6}
        total=sum(w.values());w={k:v/total for k,v in w.items()} if total else {}
        points.append(p);weights.append(w);owners.append(name)
        if v.index in boundary:boundaries.append(offset+v.index)
tree=KDTree(len(points))
for i,p in enumerate(points):tree.insert(p,i)
tree.balance()
pairs=[];seen=set()
for i in boundaries:
    if owners[i]=='BAKED_Outfits':continue
    for _,j,d in tree.find_range(points[i],.00005):
        if i==j or owners[j]=='BAKED_Outfits':continue
        pair=tuple(sorted((i,j)))
        if pair in seen:continue
        seen.add(pair)
        w1,w2=weights[i],weights[j]
        difference=sum(abs(w1.get(k,0)-w2.get(k,0)) for k in w1.keys()|w2.keys())
        if difference>.01:pairs.append({'a':i,'b':j,'mesh_a':owners[i],'mesh_b':owners[j],'distance_m':d,'position':list(map(float,points[i])),'weight_l1':difference,'weights_a':w1,'weights_b':w2})
summary={'mismatched_coincident_boundary_pairs':len(pairs),'largest_mismatches':sorted(pairs,key=lambda p:p['weight_l1'],reverse=True)[:30],
    'shoulder_pairs':[p for p in pairs if 1.25<p['position'][2]<1.5 and .05<abs(p['position'][0])<.3][:30]}
(OUT/'weight_continuity_audit.json').write_text(json.dumps(summary,indent=2))
print('WEIGHT_AUDIT '+json.dumps({'mismatched_pairs':len(pairs),'shoulder_pairs':len(summary['shoulder_pairs']),'max_l1':max((p['weight_l1'] for p in pairs),default=0)}),flush=True)
for p in summary['shoulder_pairs'][:3]:print(json.dumps(p),flush=True)
