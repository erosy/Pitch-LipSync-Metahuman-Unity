# Jiwoo corrected rig: current handoff

## 32-point / 30 Hz scalp variant - 11 November 2026

The saved `Jiwoo_Normalized.prefab` now uses
`Assets/_Sandbox/Characters/Jiwoo New/Groom/Jiwoo_Scalp_32.asset`, sourced from
the adjacent `Jiwoo_Scalp_32_HeadLocal.abc`, at 30 Hz. It retains all 100,498
strands with 32 points each: 3,215,936 particles, down from 6,431,872. The target
base particle-update cadence is one quarter of the preceding 64-point/60 Hz
configuration, while rendered segment count is approximately halved. Actual
frame-time improvement has not been measured. Solver iterations/substeps and
the maximum two simulation steps per frame are unchanged.

The 32-point curves were sampled by arc length from the previously verified
64-point scalp data, with roots and tips explicitly preserved. Independent
Blender Alembic readback matched every exported point exactly. Unity's built
Hair Asset has zero root/tip displacement and retains the original 0.1 mm strand
diameter. Fewer straight segments shorten the polygonal path by up to 8.24 mm
on the most curved strand, despite identical endpoints; visual curl/silhouette
and longer segment collision behavior need user review. The package's built-in
resampler was not used for the final asset because it moved some tips.

The fitted head SDF, all neck/shoulder boundaries, margin, strand scale, material,
startup/readiness wiring, model, animations, facial geometry, expressions and
lip-sync remain unchanged. Verification compared all 364 serialized prefab
blocks outside the hair subtree byte-for-byte. The original groom, Alembic, FBX
and its authored normal import settings, scalp collision texture, strand
material, prefab GUID and Ethan prefab have unchanged protected hashes. The
generated hair group/root mesh now point to the new variant. Missing-script and
character configuration checks pass. Edit Mode simulation remains disabled.

Backups of the preceding prefab/groom (with metas), protected hashes, independent
readback, geometry and saved-prefab checks are in
[`Data/JiwooRigged/HairOptimization32`](../Data/JiwooRigged/HairOptimization32/).
The original 64-point groom remains available unchanged. Reproduce the derived
Alembic with Blender background `Tools/Hair/export_jiwoo_scalp32.py`, then run
`OptimizeJiwooScalp.BuildVariant` and `OptimizeJiwooScalp.Apply` from
`Tools/Hair/OptimizeJiwooScalp.cs` through Unity CLI `run_script`. For an already
installed variant, use `OptimizeJiwooScalp.Verify`.

Compilation and Edit Mode asset/reference checks pass. No scene was saved,
no build was run, and Play Mode was not entered/exited. Please compare selection
hitching and steady frame rate, then greeting/idle/head turns for hairline,
clipping, settling and motion smoothness at 30 Hz. Buffer-reset reuse and guide
clustering are separate later optimizations if needed; this change implements
the agreed sampling/rate reduction only.

## Hair performance audit - 11 November 2026

Read-only comparison of the saved prefabs and loaded CharacterTesting instances
found no duplicate grooms or scene overrides of the relevant settings. No
performance settings or character assets were changed. Unity was in Edit Mode;
no frame timing or GPU Profiler measurement was taken.

| Setting | Jiwoo | Ethan |
| --- | ---: | ---: |
| Scalp strands | 100,498 | 94,408 |
| Points per strand | 64 | 32 |
| Total particles | 6,431,872 | 3,021,056 |
| Simulation target | 60 Hz | 30 Hz |
| Solver substeps / constraint iterations | 2 / 8 | 4 / 12 |
| Reduced guide LODs | None | None |
| Volume grid | 32 cubed | 32 cubed |
| Head SDF resolution | 96 cubed | 96 cubed |
| Additional collision capsules | 3 | 0 |
| Serialized Hair Asset size | 81.30 MiB | 41.80 MiB |

The main structural difference is strand sampling density, rather than strand
count: Jiwoo has 6.45% more strands but 2.13 times as many particles. At the target
rates this is 4.26 times the base particle-update cadence before accounting for
substeps and iterations. Ethan has more substeps/iterations, so this figure is
not a total solver-time ratio. Jiwoo also has approximately 2.16 times as many
strand segments for staging/rendering; both use the same `Hair/Custom/EthanHair`
shader, strip rendering, shadows, indirect draws and instancing. Render work
depends on visibility and culling; segment counts are workload bounds, not
measured draw timings. Longer hair may increase screen coverage/overdraw.

Both Hair Assets have clustering disabled and one LOD whose guide count equals
the entire strand count. Ethan's manual solver LOD value of zero therefore still
selects all 94,408 strands; it is not a reduced-guide optimization absent on
Jiwoo. Jiwoo's automatic LOD setting also cannot reduce its guide tier. Their
volume grids and head SDF resolutions match, so a larger volume or unique SDF
technique does not explain the difference. Jiwoo does have three extra analytic
capsules evaluated during collision; their exact cost requires profiling.

From the package's `HairSim.PrepareSolverData` allocation sizes, the mandatory
particle/root/guide buffers alone are approximately 479 MiB for Jiwoo versus
231 MiB for Ethan. Two half-precision staging buffers add approximately 98 MiB
versus 46 MiB, bringing that subtotal to about 577 versus 277 MiB. These are
allocation estimates, not measured VRAM: volume/topology/optional buffers,
driver overhead and asset memory are additional. Guide clustering can reduce
solver work, but this package allocates its base buffers at full strand count.

Selection can also hitch independently of steady-state frame rate. The shared
warmup simulates invisibly for eight frames, then calls `ResetSimulationState`.
That implementation releases runtime buffers, which the next initialization
reallocates and uploads. Character deactivation also releases runtime data.
Both characters use this behavior, but Jiwoo's larger buffers amplify the
allocation/upload burden. The bald version has neither workload.

Suggested next implementation: make a backed-up 32-point groom variant and
compare at 30 Hz while preserving the fitted scalp boundary, then validate
hair silhouette and collision during head turns. If more reduction is needed,
introduce a reduced-guide LOD hierarchy, reduce rendered density as appropriate,
and separately profile activation to decide whether reset can reuse buffers.
Do not remove readiness/reset behavior without preserving initial-pose safety.
The collision fix is retained throughout. Exact GPU/CPU contributions and FPS
improvement need user-controlled Play Mode profiling and an A/B comparison.

Raw reports: [`HairPerformance/comparison.json`](../Data/JiwooRigged/HairPerformance/comparison.json)
and [`scene_comparison.json`](../Data/JiwooRigged/HairPerformance/scene_comparison.json).
Reproduce with `Tools/Hair/AuditHairPerformance.cs`, entry `AuditHairPerformance.Run`,
through Unity CLI's in-memory `run_script` command.

## Scalp collision repair - 11 November 2026

User motion review showed strands passing through the scalp. The first head
capsule sat up to 27.23 mm beneath scalp roots (95th percentile gap 17.11 mm),
so the simulation could enter visible skin before reaching its collision shape.
The saved prefab now replaces that capsule with a head-shaped signed distance
field (SDF), attached directly to the same head bone. The neck and shoulder
capsules, total resident boundary count of four, 1.5 mm margin, strand count,
material, and all solver settings are unchanged. Performance tuning is deferred
to the user's next requested pass.

The new asset is
`Assets/_Sandbox/Characters/Jiwoo New/Groom/Collision/Jiwoo_HeadSDF.asset`:
a 96 x 96 x 96 RFloat Texture3D, linear filtering, clamp addressing, no mipmaps.
Its voxel payload is 3.375 MiB, with no runtime baking. It is derived from the
current FBX's head material submesh in head-local coordinates. Four holes in a
separate collision-only copy were closed for reliable inside/outside classification;
the actual Face mesh and FBX were not changed. The new boundary follows the
forehead, crown, temples, back of the skull and face rather than approximating
them with one small capsule. Its local center is
`(0.000007406, -0.002583429, -0.012866456)` and size in meters is
`(0.389632881, 0.445983380, 0.281617700)`.

All 100,498 scalp roots lie within 0.228 mm of the interpolated SDF surface.
At 4,096 distributed roots, probes 6 mm outside and inside the skin have the
correct sign; every texture border is positive to prevent collisions extending
outside its volume. A Unity Edit Mode compute check exercised the same GPU
trilinear sampling path used by HairSim: 576 samples across neutral, 45-degree
turn, and combined pitch/yaw/roll poses passed within 0.027 mm of the independent
Blender reference. The boundary's texture and head-bone attachment resolve
correctly after prefab reload.

Only the existing head boundary's Transform and HairBoundary serialized blocks
changed in the prefab; all other blocks are byte-for-byte preserved against the
pre-repair backup. Compilation is up to date; saved-prefab and loaded-character
configuration checks pass with no missing scripts. The scene remains clean and
was never saved. Play Mode was not entered/exited; no build was run. The final
console check is clean after archiving a tooling compatibility log.

Backup, recording review, bake inputs, SDF field, and verification reports are in
[`Data/JiwooRigged/ScalpBoundaryRepair`](../Data/JiwooRigged/ScalpBoundaryRepair/).
Reproduce using `RepairJiwooScalpBoundary.Audit` via Unity CLI `run_script`,
Blender background `Tools/Hair/bake_jiwoo_head_sdf.py`, then
`RepairJiwooScalpBoundary.Apply`. For an installed boundary, use its `Verify`
entry point. `Tools/Hair/VerifyJiwooHeadSdf.compute` is imported temporarily for
Edit Mode GPU checks and removed afterward. Sources remain outside Assets.

Please replay greeting, idle and head turns to confirm the hair stays outside
the scalp, especially the temples and back of the head. Runtime collision,
motion quality and performance still require user Play Mode review. The SDF
is a rigid neutral head proxy; it follows head turns but does not deform with
facial expressions. The reported frame-rate issue is still pending and has not
been optimized in this collision pass.

## Scalp restored — 11 November 2026

`Jiwoo_Normalized.prefab` is saved with one `Jiwoo_ScalpHair` Hair Instance
directly beneath `DEF-spine.006`, local position/rotation zero and scale one.
It reuses `Assets/_Sandbox/Characters/Jiwoo/Groom/Rigged/Jiwoo_Scalp.asset`
and its `Jiwoo_Scalp_HeadLocal.abc`, with the existing
`Assets/_Sandbox/Characters/Jiwoo/Materials/Jiwoo_StrandHair.mat` unchanged.
No new groom export was necessary. Eyebrows and eyelashes remain mesh sections
of the current Face; there are no facial strand instances or surface bindings.

Reuse was checked against the neutral scalp in the latest prepared source,
`Data/JiwooRigged/ClothingWeightRepair/Jiwoo_EthanSetup_WeightsFixed.blend`,
and the actual current imported `Jiwoo_EthanSetup.fbx` in the saved prefab.
The old/current resampled curves differ by at most 0.0101 mm. Independent Blender
Alembic readback matched the original sample data exactly, including positive
0.1 mm widths. Unity Alembic and Hair Asset points match the source coordinate
conversion within 0.0002 mm; the conversion was solved from 160 current bones,
including the head-local handedness change. Every root is within 0.0013 mm of
the current imported FBX surface. Root-to-tip ordering and uniform 64-point
sampling were checked. The groom has 100,498 strands / 6,431,872 particles,
maximum length 0.351923 m, and head-local bounds in meters:
`(-0.131333, -0.083146, -0.120187)` to `(0.128475, 0.204676, 0.136174)`.

Strand scale is Fixed, with no length/diameter override. Runtime simulation uses
60 Hz, a maximum of two steps per rendered frame, two solver substeps, eight
constraint iterations, a 32-cubed volume, gravity 0.2, and global position/rotation
retention influences 0.3/0.7. These are initial settings pending motion review.
Edit Mode simulation is disabled. The initial installation used four standalone
capsule boundaries (the head is now superseded by the SDF above); automatic scene
collider capture is disabled, with a 1.5 mm solid
margin. Centers below are in character-root space in the neutral pose; objects
follow their listed bones during animation.

| Boundary | Bone | Center (m) | Radius / height (m) | Axis |
| --- | --- | --- | --- | --- |
| Head | DEF-spine.006 | (0, 1.655, -0.005) | 0.073 / 0.190 | Y |
| Neck | DEF-spine.005 | (0, 1.500, 0.003) | 0.041 / 0.135 | Y |
| Left shoulder | DEF-shoulder.L | (0.105, 1.393, 0.015) | 0.052 / 0.180 | X |
| Right shoulder | DEF-shoulder.R | (-0.105, 1.393, 0.015) | 0.052 / 0.180 | X |

The existing shared `CharacterHairStartupWarmup` is explicitly wired to the
current Animator and the one scalp instance (eight pose frames, reset, then three
frames before reveal). `CharacterReadiness.startupWarmup` points to it. No
`CharacterHairFallback` is installed because a matching Jiwoo replacement does
not yet exist. Existing guards in `HairInstance.OnEnable`, runtime initialization,
and release reject graphics APIs without compute shaders; warmup reports ready
without resetting unsupported strands. This was inspected statically, without a
platform build. Unsupported devices currently have no scalp substitute.

Backups, hashes, fit/readback reports, serialized binding snapshots and the
42/42 passing `CharacterFlowTests` results are in
[`Data/JiwooRigged/ScalpRestore`](../Data/JiwooRigged/ScalpRestore/).
The original prefab, its meta/GUID, scalp groom/ABC, strand material, FBX and
FBX meta were copied to `ScalpRestore/Before` before installation. The saved
prefab verification preserved 182 existing component/transform contracts,
including Face/Outfit meshes and materials, avatar, activities, expressions,
lip-sync and bone bindings. The FBX, authored blend-shape-normal Import setting,
prefab GUID, groom and material hashes remain unchanged. No missing scripts or
character configuration errors were found in the saved prefab/current instance.
Compilation reported up-to-date, with zero errors/warnings. Final console checks
were clean after archiving CLI compatibility messages and the expected negative
fallback-test log. The open CharacterTesting scene was clean at inspection,
remains clean, and was never saved. Play Mode was never entered/exited; no build
was run. Editor auto-tick was already enabled and remains enabled.

Reproducible scalp-only tools: `Tools/Hair/audit_jiwoo_scalp.py`,
`Tools/Hair/verify_jiwoo_scalp_unity.py`, and `Tools/Hair/RestoreJiwooScalp.cs`.
The C# tool runs in memory using Unity CLI `run_script`; its `Audit`, `Install`,
`Verify` and `InspectLoadedScene` entries never run the historical character
installer. Large generated binary geometry dumps were removed after verification
and can be regenerated by the audit tools. Blender source files and the original
modeller delivery were not edited.

Please test greeting, idle, head turns and blinks in Play Mode. Review front and
temple hairlines, scalp/neck/shoulder and clothing clipping, reveal/settling on
each activation, and frame time/GPU memory on Windows. Static checks do not
establish motion quality or performance: this groom contains 6.43 million
particles and has no reduced simulation LOD clusters. Boundary and solver tuning
may be needed after that review. A matching Jiwoo scalp hair-card/mesh fallback
remains a separate follow-up before website deployment; Ethan's hairstyle is not
used.

The new model imports authored FBX blend-shape normals (Calculate -> Import)
to remove jagged dark shading around full left/right blinks. Mesh geometry,
facial shape positions, clothing weights, materials and rig configuration are
unchanged. Both blink comparisons and character-reference checks passed. See
[blink diagnosis and correction](../Data/JiwooRigged/BlinkAudit/README.md).

The latest garment pass transfers weights from nearby skin, removes inappropriate
facial/forearm influences, and retains all seam clusters. In 21 sampled greeting
poses the post-import penetration diagnostic improved by 15.46%; some skin
intersections remain for garment-fit review. The latest editable source is
`Data/JiwooRigged/ClothingWeightRepair/Jiwoo_EthanSetup_WeightsFixed.blend`.
See [greeting weight repair](../Data/JiwooRigged/ClothingWeightRepair/README.md).

The active new model also includes a clothing seam weight repair: 963 outfit
vertices now share consistent weights along matching garment boundaries, with
no topology/UV/shape-coordinate changes. The 20-degree shoulder/chest stress
checks reduced maximum gaps from about 34 mm to below 0.1 mm. The editable
repaired source is `Data/JiwooRigged/ClothingSeamRepair/Jiwoo_EthanSetup_SeamFixed.blend`.
See [clothing repair and checks](../Data/JiwooRigged/ClothingSeamRepair/README.md).

`Jiwoo_Normalized.prefab` now uses
`Assets/_Sandbox/Characters/Jiwoo New/Jiwoo_EthanSetup.fbx`, with a combined
native-DNA-baked `Face`, mesh eyebrows/lashes, and a separate `Outfit`. The original
prefab GUID, animation/activity, expression, voice, lip-sync, and selection-facing
flow references are preserved. The model replacement initially removed all
strand grooms. Scalp strands and shared startup/readiness wiring are now restored
as described above; facial hair remains mesh geometry.

The new model has 73 shapes, 160 deform bones, the original 52-bone Humanoid
mapping, and a verified reference T-pose. Static saved-prefab and current-scene
checks passed without animation playback, Play Mode changes, or a build. The
prefab is saved. The already-dirty open scene was updated but left unsaved, with
a copy of its prior working state preserved outside Assets. See the
[replacement notes](../Data/JiwooRigged/EthanReference/PrefabReplacement/README.md)
and [Blender preparation notes](../Data/JiwooRigged/EthanReference/README.md).

## Previous rig integration (historical)

The current character is `Assets/_Sandbox/Characters/Jiwoo/Jiwoo_Normalized.prefab`
in `CharacterTesting`. The original prefab GUID is preserved. It uses the
corrected `Jiwoo_Rigged.fbx`, a valid Humanoid avatar with fingers, 73 named facial
shapes, the delivered outfit/textures, and the scalp, eyebrow, and eyelash grooms
under `Groom/Rigged`. Both buttons now use the scene's
`CharacterSelectionController`: select a character to greet, then press again
for its response. Ethan starts selected. Jiwoo uses Liora's dedicated profile,
named visemes, and a one-second idle pause; Ethan's existing flow is unchanged.
See [selection and voice configuration](../Data/JiwooRigged/Selection/README.md).
The avatar's retargeting reference is now explicitly calibrated to a valid
T-pose; the delivered A-pose remains its mesh bind pose. See
[reference-pose correction](../Data/JiwooRigged/AvatarRepair/README.md).

## Sources and reproducible tools

- Original modeller delivery: `C:/Users/ina17/Downloads/Jiwoo_Rigged.blend`,
  unchanged. The separate prepared copy is
  `Data/JiwooRigged/Batch01/Jiwoo_Rigged_Baked.blend`; its hidden authoring
  collection also retains the delivered objects.
- `Tools/Hair/bake_jiwoo_rigged_shapes.py` bakes the facial controls. Its ordered
  73-name interface is `jiwoo_shape_names.json`; no old import batch is needed.
- `Tools/Hair/export_jiwoo_rigged.py` produces the FBX, ABC files, texture sources,
  and numerical baselines in `Data/JiwooRigged/Batch02`.
- `verify_jiwoo_rigged_export.py` checks independent Blender FBX/ABC readback.
  `InstallJiwooRigged.cs` provides import/material/groom configuration and static
  saved-prefab/scene checks. Run it through Unity CLI's in-memory script runner.
- For independent Unity geometry verification, run
  `InstallJiwooRigged.DumpImport` to regenerate its temporary reports and binary
  dump, then run `verify_jiwoo_rigged_unity.py` in Blender background mode. Those
  large temporary dumps need not be retained after verification.

Use Blender `--background --factory-startup --disable-autoexec` for these scripts.
The bake refuses to overwrite its review file. If editing the prepared shape keys,
refresh the numerical bake baselines before exporting; the exporter checks the
prepared-file hash to prevent silently ignoring artist edits.

## Cleanup and checks

Old models, groom attempts, obsolete texture copies, facial repair tools,
reimport batches, and hairstyle switching have been removed. Their deletion
manifests and final checks are in `Data/JiwooRigged/Batch03`. Active material and
prefab GUIDs are retained. Shared `CharacterHairStartupWarmup`,
`CharacterHairFallback`, and `CharacterReadiness` scripts retain the original
Ethan script GUIDs and their relevant tests.

The export/import comparisons passed for all 73 shapes, 160 deform bones, and
all three grooms. The saved prefab and scene have valid character/module,
material, lip-sync, and button bindings. The final cleanup uses compilation and
static checks only. No Play Mode changes, live testing, or builds are performed.

## Remaining user review

The facial shapes are newly authored approximations, not recovered facial clips.
Check eyelid contact, lip seals, teeth/tongue intersections, expressions, and
Humanoid animation. The delivered facial poses can move the outfit by about
5 mm. Eye-edge/cartilage meshes remain head-bound. The body/head seam now has
matching weights and shape positions, and facial grooms have surface bindings
that follow skinning and expressions. See the
[deformation repair](../Data/JiwooRigged/DeformationRepair/README.md).
Rendering, motion, binding cost, and runtime suitability remain user testing.
Edit Mode groom simulation is disabled.

Detailed checkpoints: [Blender bake review](../Data/JiwooRigged/Batch01/README.md)
and [Unity integration](../Data/JiwooRigged/Batch02/README.md).
