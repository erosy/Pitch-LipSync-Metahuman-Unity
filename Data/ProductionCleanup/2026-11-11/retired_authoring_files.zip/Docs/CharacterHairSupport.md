# Shared character hair support

The root-level components formerly named `EthanHairStartupWarmup`,
`EthanWebHairFallback`, and `EthanFlowReadiness` are now
`CharacterHairStartupWarmup`, `CharacterHairFallback`, and `CharacterReadiness`.
Their script GUIDs are preserved, with type migration attributes and a serialized
field alias for `bakedHair` -> `fallbackRoot`. Existing Ethan references are retained.

## Warmup

Attach `CharacterHairStartupWarmup` to the character root. Optionally assign
Target Animator (otherwise discover one in the hierarchy) and Strand Hair
(otherwise discover all child Hair Instances, including brows and lashes).
Every activation clears readiness and starts a fresh pose warmup. Disabling during
warmup restores renderer visibility, hair rendering settings, and Animator culling.
Warmup resets strand state but does not enable simulation or change its settings.

## Fallback

Assign character-specific mesh/card objects under the character root to Fallback
Root and, optionally, Additional Fallback Roots for brows, lashes, or other grooms.
These should start inactive in the normal strand setup. Strand Hair accepts an
explicit list or discovers all child Hair Instances. Assign Startup Warmup if used.
On graphics APIs without compute support, fallback activates before warmup.
Configuration is checked before disabling strands or warmup; missing replacements
leave those objects untouched and report an error. Fallback objects must not be
inside strand objects that are about to be disabled. The component switches
existing objects; it does not generate replacement meshes.

## Readiness

Assign the root's optional warmup and fallback components to `CharacterReadiness`,
then use it as the existing flow controller's readiness provider. It waits for
warmup or accepts an activated fallback. A character without strands or startup
dependencies is ready immediately; active strand hair requires warmup. This keeps
mesh-only or hairless characters from needing dummy hair components.

This refactor does not add animation modules, voice bindings, fallback geometry,
or facial groom deformation to Jiwoo. Those remain separate setup decisions.
