using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Security.Cryptography;
using Unity.Collections;
using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine.SceneManagement;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

public static class OptimizeEthanV2FacialHair
{
 const string Prefab="Assets/_Sandbox/Characters/Ethan_V2/Ethan_V2.prefab";
 const string Output="Data/EthanV2/FacialHairOptimization";
 const string Target="Assets/_Sandbox/Characters/Ethan_V2/Meshes/EthanV2_Head_FacialHairOptimized.asset";
 static readonly int[][] Rings={new[]{0,6,12,18,24,29,30,31},new[]{0,5,10,15,19,23,27,31}};
 static void Guard(){if(EditorApplication.isPlayingOrWillChangePlaymode)throw new Exception("Edit Mode required; user controls Play Mode");Directory.CreateDirectory(Output);}
 static void Save(string name,object data)=>File.WriteAllText(Output+"/"+name+".json",JsonConvert.SerializeObject(data,Formatting.Indented));
 static string Hash(string path){using(var h=SHA256.Create())return BitConverter.ToString(h.ComputeHash(File.ReadAllBytes(path))).Replace("-","");}
 static SkinnedMeshRenderer Head(GameObject r)=>r.GetComponentsInChildren<SkinnedMeshRenderer>(true).Single(x=>x.name=="BAKED_head_lod0_mesh");
 public static object Dump(){Guard();var mesh=Head(AssetDatabase.LoadAssetAtPath<GameObject>(Prefab)).sharedMesh;using(var w=new BinaryWriter(File.Create(Output+"/source_vertices.bin")))foreach(var p in mesh.vertices){w.Write(p.x);w.Write(p.y);w.Write(p.z);}for(int s=1;s<3;s++)using(var w=new BinaryWriter(File.Create(Output+"/source_triangles_"+s+".bin")))foreach(int i in mesh.GetTriangles(s))w.Write(i);return new{mesh.vertexCount};}
 static float Error(Vector3 p,Vector3 a,Vector3 b){var d=b-a;return Vector3.Distance(p,a+d*Mathf.Clamp01(Vector3.Dot(p-a,d)/Mathf.Max(1e-20f,d.sqrMagnitude)));}
 static Dictionary<string,string> Snapshot(GameObject root){var head=Head(root);return root.GetComponentsInChildren<Component>(true).Select((c,i)=>new{c,i}).ToDictionary(x=>x.i+":"+x.c.GetType().FullName,x=>{
  var json=JObject.Parse(EditorJsonUtility.ToJson(x.c));if(x.c==head)foreach(var p in json.Descendants().OfType<JProperty>().Where(p=>p.Name=="m_Mesh").ToArray())p.Remove();return json.ToString(Formatting.None);
 });}
 public static object Build(){
  Guard();if(File.Exists(Target))throw new Exception("Reviewed derivative exists; use Verify");
  var root=AssetDatabase.LoadAssetAtPath<GameObject>(Prefab);var source=Head(root).sharedMesh;
  var paths=AssetDatabase.GetDependencies(Prefab,true).Where(p=>p.StartsWith("Assets/")&&File.Exists(p)).Concat(new[]{Prefab,Prefab+".meta"}).Distinct().ToArray();
  Save("protected_hashes",paths.Where(p=>p!=Prefab).ToDictionary(p=>p,Hash));Directory.CreateDirectory(Output+"/Before");if(!File.Exists(Output+"/Before/Ethan_V2.prefab")){File.Copy(Prefab,Output+"/Before/Ethan_V2.prefab");File.Copy(Prefab+".meta",Output+"/Before/Ethan_V2.prefab.meta");}
  if(source.subMeshCount!=3||source.blendShapeCount!=73)throw new Exception("Unexpected head layout");
  var indices=new List<int>();var remap=new Dictionary<int,int>();var triangles=new List<int[]>();
  Action<int> Keep=i=>{if(!remap.ContainsKey(i)){remap.Add(i,indices.Count);indices.Add(i);}};
  var skin=source.GetTriangles(0);foreach(int i in skin)Keep(i);triangles.Add(skin.Select(i=>remap[i]).ToArray());
  var positions=source.vertices;var sourceNormals=source.normals;float maxCenterlineError=0;var sections=new List<object>();
  for(int section=1;section<3;section++){
   var old=source.GetTriangles(section);var layout=JsonConvert.DeserializeObject<int[][][]>(File.ReadAllText(Output+"/strand_rings_"+section+".json"));int count=layout.Length;
   if(old.Length/3!=count*186)throw new Exception("Unexpected strand tube layout");
   var plans=JsonConvert.DeserializeObject<int[][]>(File.ReadAllText(Output+"/retained_rings_"+section+".json"));var next=new List<int>();
   for(int s=0;s<count;s++){
    var rings=plans[s];if(rings.Length>12||rings[0]!=0||rings[rings.Length-1]!=31)throw new Exception("Invalid adaptive sampling plan");
    var strand=layout[s];if(strand.Length!=32||strand.Any(r=>r.Length!=3))throw new Exception("Invalid ring plan");foreach(int ring in rings)for(int side=0;side<3;side++)Keep(strand[ring][side]);
    for(int k=0;k<rings.Length-1;k++)for(int side=0;side<3;side++){
     int a=remap[strand[rings[k]][side]],b=remap[strand[rings[k]][(side+1)%3]],c=remap[strand[rings[k+1]][(side+1)%3]],d=remap[strand[rings[k+1]][side]];next.AddRange(new[]{a,b,c,a,c,d});
    }
    Func<int,Vector3> Center=ring=>(positions[strand[ring][0]]+positions[strand[ring][1]]+positions[strand[ring][2]])/3;
    for(int ring=0;ring<32;ring++){float best=float.MaxValue;for(int k=0;k<rings.Length-1;k++)best=Mathf.Min(best,Error(Center(ring),Center(rings[k]),Center(rings[k+1])));maxCenterlineError=Mathf.Max(maxCenterlineError,best);}
   }
   float winding=Mathf.Sign(Vector3.Dot(Vector3.Cross(positions[old[1]]-positions[old[0]],positions[old[2]]-positions[old[0]]),sourceNormals[old[0]]+sourceNormals[old[1]]+sourceNormals[old[2]]));
   for(int k=0;k<next.Count;k+=3){int a=indices[next[k]],b=indices[next[k+1]],c=indices[next[k+2]];if(winding*Vector3.Dot(Vector3.Cross(positions[b]-positions[a],positions[c]-positions[a]),sourceNormals[a]+sourceNormals[b]+sourceNormals[c])<0){int temp=next[k+1];next[k+1]=next[k+2];next[k+2]=temp;}}
   triangles.Add(next.ToArray());sections.Add(new{section,strands=count,oldVertices=count*96,newVertices=plans.Sum(p=>p.Length*3),oldTriangles=old.Length/3,newTriangles=next.Count/3,minRings=plans.Min(p=>p.Length),maxRings=plans.Max(p=>p.Length)});
  }
  var mesh=new Mesh{name="EthanV2_Head_FacialHairOptimized",indexFormat=UnityEngine.Rendering.IndexFormat.UInt32};var map=indices.ToArray();
  mesh.vertices=map.Select(i=>positions[i]).ToArray();mesh.normals=map.Select(i=>sourceNormals[i]).ToArray();var tangents=source.tangents;if(tangents.Length>0)mesh.tangents=map.Select(i=>tangents[i]).ToArray();
  for(int channel=0;channel<8;channel++){var uv=new List<Vector4>();source.GetUVs(channel,uv);if(uv.Count>0)mesh.SetUVs(channel,map.Select(i=>uv[i]).ToList());}
  var colors=source.colors32;if(colors.Length>0)mesh.colors32=map.Select(i=>colors[i]).ToArray();mesh.bindposes=source.bindposes;
  using(var counts=source.GetBonesPerVertex())using(var weights=source.GetAllBoneWeights()){
   int[] offsets=new int[counts.Length+1];for(int i=0;i<counts.Length;i++)offsets[i+1]=offsets[i]+counts[i];
   var selected=new List<BoneWeight1>();foreach(int i in map)for(int j=offsets[i];j<offsets[i+1];j++)selected.Add(weights[j]);
   using(var n=new NativeArray<byte>(map.Select(i=>counts[i]).ToArray(),Allocator.Temp))using(var w=new NativeArray<BoneWeight1>(selected.ToArray(),Allocator.Temp))mesh.SetBoneWeights(n,w);
  }
  mesh.subMeshCount=3;for(int i=0;i<3;i++)mesh.SetTriangles(triangles[i],i,false);mesh.bounds=source.bounds;
  var dv=new Vector3[source.vertexCount];var dn=new Vector3[source.vertexCount];var dt=new Vector3[source.vertexCount];
  for(int s=0;s<source.blendShapeCount;s++)for(int f=0;f<source.GetBlendShapeFrameCount(s);f++){source.GetBlendShapeFrameVertices(s,f,dv,dn,dt);mesh.AddBlendShapeFrame(source.GetBlendShapeName(s),source.GetBlendShapeFrameWeight(s,f),map.Select(i=>dv[i]).ToArray(),map.Select(i=>dn[i]).ToArray(),map.Select(i=>dt[i]).ToArray());}
  AssetDatabase.CreateAsset(mesh,Target);AssetDatabase.SaveAssetIfDirty(mesh);File.WriteAllBytes(Output+"/retained_vertex_indices.bin",map.SelectMany(BitConverter.GetBytes).ToArray());
  Save("build",new{source=AssetDatabase.GetAssetPath(source),target=Target,oldVertices=source.vertexCount,newVertices=mesh.vertexCount,oldTriangles=source.triangles.Length/3,newTriangles=mesh.triangles.Length/3,maxCenterlineErrorMeshUnits=maxCenterlineError,headWorldScale=Head(root).transform.lossyScale.x,sections});
  return VerifyGeometry();
 }
 public static object VerifyGeometry(){
  Guard();var source=Head(AssetDatabase.LoadAssetAtPath<GameObject>(Prefab)).sharedMesh;
  // Before installation source is the FBX; afterward resolve that immutable mesh explicitly.
  if(AssetDatabase.GetAssetPath(source)==Target)source=AssetDatabase.LoadAllAssetsAtPath("Assets/_Sandbox/Characters/Ethan_V2/Ethan_V2_73_Baked.fbx").OfType<Mesh>().Single(m=>m.name=="BAKED_head_lod0_mesh");
  var next=AssetDatabase.LoadAssetAtPath<Mesh>(Target);var bytes=File.ReadAllBytes(Output+"/retained_vertex_indices.bin");var map=new int[bytes.Length/4];Buffer.BlockCopy(bytes,0,map,0,bytes.Length);
  if(next.vertexCount!=map.Length||next.blendShapeCount!=source.blendShapeCount)throw new Exception("Mesh/shape count mismatch");
  var old=source.vertices;var actual=next.vertices;for(int i=0;i<map.Length;i++)if(!old[map[i]].Equals(actual[i]))throw new Exception("Retained vertex changed");
  var a=new Vector3[source.vertexCount];var b=new Vector3[source.vertexCount];var c=new Vector3[source.vertexCount];var x=new Vector3[next.vertexCount];var y=new Vector3[next.vertexCount];var z=new Vector3[next.vertexCount];
  for(int s=0;s<source.blendShapeCount;s++){
   if(source.GetBlendShapeName(s)!=next.GetBlendShapeName(s))throw new Exception("Shape name/order mismatch");
   source.GetBlendShapeFrameVertices(s,0,a,b,c);next.GetBlendShapeFrameVertices(s,0,x,y,z);
   for(int i=0;i<map.Length;i++)if(!a[map[i]].Equals(x[i])||!b[map[i]].Equals(y[i])||!c[map[i]].Equals(z[i]))throw new Exception("Authored shape/normal/tangent changed");
  }
  if(!source.bindposes.SequenceEqual(next.bindposes))throw new Exception("Bind poses changed");
  using(var counts=source.GetBonesPerVertex())using(var weights=source.GetAllBoneWeights())using(var nc=next.GetBonesPerVertex())using(var nw=next.GetAllBoneWeights()){
   var offsets=new int[counts.Length+1];for(int i=0;i<counts.Length;i++)offsets[i+1]=offsets[i]+counts[i];int write=0;
   for(int i=0;i<map.Length;i++){if(nc[i]!=counts[map[i]])throw new Exception("Skin influence count changed");for(int j=offsets[map[i]];j<offsets[map[i]+1];j++){if(weights[j].boneIndex!=nw[write].boneIndex||weights[j].weight!=nw[write].weight)throw new Exception("Skin weights changed");write++;}}
  }
  var result=new{passed=true,vertices=next.vertexCount,triangles=next.triangles.Length/3,shapes=next.blendShapeCount,retainedGeometryAndShapeDeltasExact=true,rootsTipsWidthsPreserved=true};Save("geometry_verification",result);return result;
 }
 public static object Apply(){
  Guard();VerifyGeometry();var r=PrefabUtility.LoadPrefabContents(Prefab);
  try{var before=Snapshot(r);Head(r).sharedMesh=AssetDatabase.LoadAssetAtPath<Mesh>(Target);var after=Snapshot(r);if(before.Any(p=>after[p.Key]!=p.Value))throw new Exception("Unexpected component changes");PrefabUtility.SaveAsPrefabAsset(r,Prefab);}finally{PrefabUtility.UnloadPrefabContents(r);}
  // Keep current placement, transforms and other unsaved scene edits. Only update
  // head renderers which still explicitly reference the previous FBX mesh.
  var updated=new List<object>();foreach(var h in UnityEngine.Object.FindObjectsByType<SkinnedMeshRenderer>(FindObjectsInactive.Include).Where(h=>h.name=="BAKED_head_lod0_mesh"&&h.gameObject.scene.isLoaded&&AssetDatabase.GetAssetPath(h.sharedMesh)=="Assets/_Sandbox/Characters/Ethan_V2/Ethan_V2_73_Baked.fbx")){
   Undo.RecordObject(h,"Use optimized Ethan V2 facial hair");h.sharedMesh=AssetDatabase.LoadAssetAtPath<Mesh>(Target);PrefabUtility.RecordPrefabInstancePropertyModifications(h);updated.Add(new{h.gameObject.scene.path,h.gameObject.scene.isDirty});
  }
  foreach(var p in JsonConvert.DeserializeObject<Dictionary<string,string>>(File.ReadAllText(Output+"/protected_hashes.json")))if(Hash(p.Key)!=p.Value)throw new Exception("Protected dependency changed: "+p.Key);
  var saved=AssetDatabase.LoadAssetAtPath<GameObject>(Prefab);if(Head(saved).sharedMesh!=AssetDatabase.LoadAssetAtPath<Mesh>(Target))throw new Exception("Saved mesh mismatch");var errors=saved.GetComponent<Sandbox.CharacterSystem.Character>().ValidateConfiguration();if(errors.Count>0)throw new Exception(string.Join(";",errors));
  Save("installation",new{passed=true,target=Target,configurationErrors=errors,sceneUpdates=updated,playing=EditorApplication.isPlaying});return VerifyGeometry();
 }
 public static object Render(){
  Guard();var original=Head(AssetDatabase.LoadAssetAtPath<GameObject>(Prefab));var source=AssetDatabase.LoadAllAssetsAtPath("Assets/_Sandbox/Characters/Ethan_V2/Ethan_V2_73_Baked.fbx").OfType<Mesh>().Single(m=>m.name=="BAKED_head_lod0_mesh");var optimized=AssetDatabase.LoadAssetAtPath<Mesh>(Target);
  var scene=EditorSceneManager.NewPreviewScene();var meshes=new List<Mesh>();
  try{
   var go=new GameObject("Facial hair comparison");SceneManager.MoveGameObjectToScene(go,scene);go.layer=30;go.transform.SetPositionAndRotation(original.transform.position,original.transform.rotation);go.transform.localScale=original.transform.lossyScale;var filter=go.AddComponent<MeshFilter>();var renderer=go.AddComponent<MeshRenderer>();renderer.sharedMaterials=original.sharedMaterials;
   var verts=source.vertices;var ids=source.GetTriangles(1).Concat(source.GetTriangles(2)).Distinct().ToArray();var area=new Bounds(original.transform.TransformPoint(verts[ids[0]]),Vector3.zero);foreach(int i in ids)area.Encapsulate(original.transform.TransformPoint(verts[i]));
   var cg=new GameObject("Comparison camera");SceneManager.MoveGameObjectToScene(cg,scene);var camera=cg.AddComponent<Camera>();camera.scene=scene;camera.cullingMask=1<<30;camera.clearFlags=CameraClearFlags.SolidColor;camera.backgroundColor=new Color(.12f,.14f,.17f);camera.orthographic=true;camera.orthographicSize=Mathf.Max(area.extents.y*1.6f,area.extents.x*.75f);camera.nearClipPlane=.01f;camera.farClipPlane=2;camera.transform.position=area.center+Vector3.forward*.5f;camera.transform.LookAt(area.center);
   var lg=new GameObject("Comparison key light");SceneManager.MoveGameObjectToScene(lg,scene);var light=lg.AddComponent<Light>();light.type=LightType.Directional;light.intensity=1.3f;light.cullingMask=1<<30;lg.transform.rotation=camera.transform.rotation*Quaternion.Euler(20,-25,0);
   Directory.CreateDirectory(Output+"/Previews");
   foreach(string pose in new[]{"Neutral","eyeBlinkLeft","eyeBlinkRight","browInnerUp"})foreach(var pair in new[]{(name:"Original",mesh:source),(name:"Optimized",mesh:optimized)}){
    var m=new Mesh{indexFormat=UnityEngine.Rendering.IndexFormat.UInt32};meshes.Add(m);var p=pair.mesh.vertices;var n=pair.mesh.normals;var tangent=pair.mesh.tangents;
    if(pose!="Neutral"){int s=pair.mesh.GetBlendShapeIndex(pose);var dp=new Vector3[p.Length];var dn=new Vector3[p.Length];var dt=new Vector3[p.Length];pair.mesh.GetBlendShapeFrameVertices(s,0,dp,dn,dt);for(int i=0;i<p.Length;i++){p[i]+=dp[i];n[i]=(n[i]+dn[i]).normalized;tangent[i]+=new Vector4(dt[i].x,dt[i].y,dt[i].z,0);}}
    m.vertices=p;m.normals=n;m.tangents=tangent;var uv=new List<Vector4>();pair.mesh.GetUVs(0,uv);m.SetUVs(0,uv);m.subMeshCount=3;for(int s=0;s<3;s++)m.SetTriangles(pair.mesh.GetTriangles(s),s);filter.sharedMesh=m;
    var rt=RenderTexture.GetTemporary(1024,512,24);try{camera.targetTexture=rt;camera.Render();var prior=RenderTexture.active;RenderTexture.active=rt;var texture=new Texture2D(1024,512,TextureFormat.RGB24,false);texture.ReadPixels(new Rect(0,0,1024,512),0,0);texture.Apply();RenderTexture.active=prior;File.WriteAllBytes(Output+"/Previews/"+pose+"_"+pair.name+".png",texture.EncodeToPNG());UnityEngine.Object.DestroyImmediate(texture);}finally{camera.targetTexture=null;RenderTexture.ReleaseTemporary(rt);}
   }
   return new{images=8,poses=4};
  }finally{foreach(var m in meshes)UnityEngine.Object.DestroyImmediate(m);EditorSceneManager.ClosePreviewScene(scene);}
 }
 public static object DiscardDraft(){Guard();const string draft="Assets/_Sandbox/Characters/Ethan_V2/Meshes/EthanV2_Head_FacialHair8.asset";if(AssetDatabase.GetDependencies(Prefab,true).Contains(draft))throw new Exception("Draft still in use");return AssetDatabase.DeleteAsset(draft);}
 public static object FinalCheck(){
  Guard();VerifyGeometry();var r=AssetDatabase.LoadAssetAtPath<GameObject>(Prefab);var mesh=Head(r).sharedMesh;
  var scene=UnityEngine.Object.FindObjectsByType<SkinnedMeshRenderer>(FindObjectsInactive.Include).Where(h=>h.name=="BAKED_head_lod0_mesh"&&h.gameObject.scene.isLoaded).Select(h=>new{h.gameObject.scene.path,h.gameObject.scene.isDirty,mesh=AssetDatabase.GetAssetPath(h.sharedMesh)}).ToArray();
  var result=new{headVertices=mesh.vertexCount,headTriangles=mesh.triangles.Length/3,headMeshMiB=UnityEngine.Profiling.Profiler.GetRuntimeMemorySizeLong(mesh)/1048576f,wholeCharacterVertices=r.GetComponentsInChildren<SkinnedMeshRenderer>(true).Sum(h=>h.sharedMesh.vertexCount),wholeCharacterTriangles=r.GetComponentsInChildren<SkinnedMeshRenderer>(true).Sum(h=>h.sharedMesh.triangles.Length/3),scenes=scene};Save("final_check",result);return result;
 }
}
